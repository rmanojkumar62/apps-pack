﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using Microsoft.SharePoint.WebControls;
using System.Globalization;

namespace Monsanto.AntwerpITRequisition
{
    [ToolboxData("<{0}:SPGridViewCustom runat=server></{0}:SPGridViewCustom>")]
    public class SPGridViewCustom : SPGridView, IPostBackEventHandler
    {
        protected override int CreateChildControls(System.Collections.IEnumerable dataSource, bool dataBinding)
        {
            int returnValue = base.CreateChildControls(dataSource, dataBinding);
            if (this.AllowFiltering && this.HeaderRow != null && !string.IsNullOrEmpty(this.SortExpression))
            {
                List<string> filterFields = new List<string>(this.FilterDataFields.Split(','));
                if (this.AllowGrouping) filterFields.Insert(0, string.Empty);
                for (int i = 0; i < this.HeaderRow.Cells.Count; i++)
                {
                    DataControlFieldHeaderCell cell = this.HeaderRow.Cells[i] as DataControlFieldHeaderCell;
                    if (cell != null)
                    {
                        Image sortImage = null;
                        foreach (Control c in cell.Controls)
                        {
                            sortImage = c as Image;
                            if (sortImage != null && sortImage.ImageUrl == this.SortDirectionImageUrl)
                                break;
                        }
                        if (i < filterFields.Count && filterFields[i].Trim() != string.Empty)
                        {
                            if (sortImage != null) cell.Controls.Remove(sortImage);
                            foreach (Control c in cell.Controls)
                            {
                                if (c is Microsoft.SharePoint.WebControls.Menu)
                                {
                                    Microsoft.SharePoint.WebControls.Menu menu = c as Microsoft.SharePoint.WebControls.Menu;
                                    if (this.SortExpression.Equals(this.Columns[i].SortExpression, StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        menu.RightImageUrl = this.SortDirectionImageUrl;
                                        menu.ImageTextSpacing = new Unit("2px", CultureInfo.InvariantCulture);
                                    }
                                    else if (menu.RightImageUrl == this.SortDirectionImageUrl)
                                    {
                                        menu.RightImageUrl = null;
                                        menu.ImageTextSpacing = Unit.Empty;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (this.SortExpression.Equals(this.Columns[i].SortExpression, StringComparison.InvariantCultureIgnoreCase))
                            {
                                if (sortImage == null)
                                {
                                    sortImage = new Image();
                                    sortImage.ImageUrl = this.SortDirectionImageUrl;
                                    sortImage.Style[HtmlTextWriterStyle.MarginLeft] = "2px";
                                    cell.Controls.Add(sortImage);
                                }
                            }
                            else if (sortImage != null)
                                cell.Controls.Remove(sortImage);
                        }
                    }
                }
            }
            return returnValue;
        }
    }
}
