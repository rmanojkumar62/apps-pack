﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net.Mail;
using Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition;
using Microsoft.SharePoint;
using System.Net;
using System.Reflection;

namespace Monsanto.AntwerpITRequisition
{
    public class MailCreator
    {
        private static List<ITRequisition> itrequisitions;
        private static ControlBase control { get; set; }

        public static void SendMail(string requisitionnumber, List<ITRequisition> itreqs, ControlBase ctrl)
        {
            MemoryStream memoryStreamOfFile = null;
            itrequisitions = itreqs;
            control = ctrl;
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(control.ApplicationEmail);
                string currentuseremail=SPContext.Current.Web.CurrentUser.Email;
                if (!currentuseremail.Equals(control.UsersToNotify.Split(Constants.Char_Splitter)[0]) && !currentuseremail.Equals(control.UsersToNotify.Split(Constants.Char_Splitter)[1]))
                    mailMessage.To.Add(new MailAddress(SPContext.Current.Web.CurrentUser.Email));
                mailMessage.To.Add(new MailAddress(control.UsersToNotify.Split(Constants.Char_Splitter)[0]));
                mailMessage.CC.Add(new MailAddress(control.UsersToNotify.Split(Constants.Char_Splitter)[1]));
                mailMessage = SetMailData(mailMessage,requisitionnumber);
                WebClient webClient = new WebClient();
                webClient.Credentials = CredentialCache.DefaultNetworkCredentials;
                foreach (ITRequisition requisition in itrequisitions)
                {
                    foreach(KeyValuePair<string,string> offerte in requisition.Offertes)
                    {
                        Stream stream = new MemoryStream(webClient.DownloadData(offerte.Value));
                        Attachment attachment = new Attachment(stream, offerte.Key);
                        mailMessage.Attachments.Add(attachment);
                    }
                }
                SmtpClient smtpClient = new SmtpClient(control.OutboundSMTPServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) { ITRequisitionUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error sending error mail"); }
            finally
            {
                if (memoryStreamOfFile != null)
                    memoryStreamOfFile.Close();
            }
        }

        private static MailMessage SetMailData(MailMessage mailMessage,string requisitionnumber)
        {
            try
            {
                string content;
                LinkedResource objLinkedRes;
                mailMessage.IsBodyHtml = true;
                objLinkedRes = new LinkedResource(control.EmailHeaderImage, "image/png");
                objLinkedRes.ContentId = "fuzzydev-logo";
                content = "<html><head><style type='text/css'>body{font-family:arial,sans-serif;}.bordertable{border-bottom:1px dashed black;width:100%;}.leftcolumn{width:150px}</style></head><body><img src='cid:fuzzydev-logo' width='200' height='70'/>";
                if (itrequisitions.Count > 1)
                {
                    mailMessage.Subject = "New IT requisitions";
                    content += "<br/><br/><h1>New IT requisitions created</h1>New it requisitions were created<br/>by " + itrequisitions[0].Author + "<br/>"+
                        "on " + itrequisitions[0].Created.ToString(Constants.Config[Constants.DateFormat]) + "<br/><br/>" +
                        "<b>Requisition number:</b> " + requisitionnumber + "<br/><br/>";
                }
                else if (itrequisitions.Count ==1)
                {
                    mailMessage.Subject = "New IT requisition";
                    content += "<br/><br/><h1>New IT requisition created</h1>A new IT requisition was created<br/>by " + itrequisitions[0].Author + "<br/>"+
                        "on " + itrequisitions[0].Created.ToString(Constants.Config[Constants.DateFormat]) + "<br/><br/>" +
                        "<b>Requisition number:</b> " + requisitionnumber + "<br/><br/>";
                }
                int counter = 1;
                foreach (ITRequisition itreq in itrequisitions)
                {
                    if (!string.IsNullOrEmpty(SPContext.Current.Web.EnsureUser(itreq.ITContactLogin).Email))
                    {
                        MailAddress ma = new MailAddress(SPContext.Current.Web.EnsureUser(itreq.ITContactLogin).Email);
                        if (!mailMessage.CC.Select(c => c.Address).Contains(SPContext.Current.Web.EnsureUser(itreq.ITContactLogin).Email))
                            mailMessage.CC.Add(new MailAddress(SPContext.Current.Web.EnsureUser(itreq.ITContactLogin).Email));
                    }
                    if (itrequisitions.Count == 1)
                        content += "<b>IT requisition information:</b>";
                    else  
                        content += "<b>IT requisition "+counter+" information:</b>";
                    content+="<table><tr><td class='leftcolumn'>- Aantal: </td><td>" + itreq.Aantal + "</td></tr><tr><td class='leftcolumn'>- Unit price: </td><td>" + itreq.Price + "</td></tr><tr><td></td></tr>" +
                             "<tr><td class='leftcolumn'>- Customer: </td><td>" + itreq.CustomerName + "</td></tr><tr><td class='leftcolumn'>- Bestemming: </td><td>" + itreq.Bestemming + "</td></tr><tr><td class='leftcolumn'>- IT contact: </td><td>" + itreq.ITContactName + "</td></tr><tr><td class='leftcolumn'>- Workorder: </td><td>" + itreq.Workorder + "</td></tr>" +
                             "<tr><td class='leftcolumn'>- Created by: </td><td>" + itreq.Author + "</td></tr><tr><td></td></tr><tr><td class='leftcolumn'>- Item description: </td><td>" + itreq.ItemDescription + "</td></tr><tr><td class='leftcolumn'>- Vendor material ID: </td><td>" + itreq.VendorID + "</td></tr><tr><td class='leftcolumn'>- Item type: </td><td>" + itreq.ItemType + "</td></tr>" +
                             "<tr><td class='leftcolumn'>- Manufacturer: </td><td>" + itreq.Manufacturer + "</td></tr><tr><td class='leftcolumn'>- Supplier: </td><td>" + itreq.PreferredSupplier + "</td></tr><tr><td class='leftcolumn'>- Costcenter: </td><td>" + itreq.Costcenter + "</td></tr><tr><td class='leftcolumn'>- GL account: </td><td>" + itreq.GLAccount + "</td></tr>" +
                             "<tr><td class='leftcolumn'>- Last SAP req nr: </td><td>" + itreq.LastSAPReqNr + "</td></tr></table><br/><table class='bordertable'><tr><td></td></tr></table><br/>";
                    counter++;               
                }
                content += "<a href='"+string.Concat(control.WebpartPageUrl,Constants.Char_Question,Constants.QueryStringMode,Constants.Char_Equal,Convert.ToString(Mode.Overview))+"'>Go to the list to view the requisitions above</a><br/><br/>*** This is a system generated email, please do not reply! ***</body></html>";
                AlternateView objHTLMAltView = AlternateView.CreateAlternateViewFromString(content, new System.Net.Mime.ContentType("text/html"));
                objHTLMAltView.LinkedResources.Add(objLinkedRes);
                mailMessage.AlternateViews.Add(objHTLMAltView);
            }
            catch (Exception ex) { ITRequisitionUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error setting mail data"); }
            return mailMessage;
        }

        public static void SendErrorMail(string exceptionmessage, string stacktrace, string innerexception, ControlBase ctrl)
        {
            control = ctrl;
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(control.ApplicationEmail);
                mailMessage.To.Add(new MailAddress(control.SharePointServicesEmail));
                mailMessage.Subject = "Error occurred in IT requisitioning app";
                mailMessage.Body = exceptionmessage + "\n\n" + stacktrace + "\n\n" + innerexception;
                SmtpClient smtpClient = new SmtpClient(control.OutboundSMTPServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex){ITRequisitionUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error sending error mail");}
        }
    }
}
