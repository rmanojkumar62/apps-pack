﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.AntwerpITRequisition
{
    public class Constants
    {
        public static readonly string QueryStringMode = "MODE";
        public static readonly string QueryStringReloadConfig = "RELOADCONFIG";
        public static readonly char Char_Question = '?';
        public static readonly char Char_Equal = '=';
        public static readonly char Char_Underscore = '_';
        public static readonly char Char_Splitter = '*';
        public static readonly char Char_Backslash = '\\';
        public static readonly string ConfigList = "Configuration";
        public static readonly string Key = "Title";
        public static readonly string Value = "Value";

        public static readonly string OverviewControl = "OverviewControl.ascx";
        public static readonly string CatalogControl = "CatalogControl.ascx";
        public static readonly string ITRequisitionForm = "ITRequisitionForm.ascx";
        public static readonly string itctrl = "itctrl";
        public static readonly string ITRequisitionGroup = "ITRequisition";
        
        public static readonly string ViewstateITRequistions = "ViewstateITRequistions";
        public static readonly string ViewstateITRequistionsCheckboxes = "ViewstateITRequistionsCheckboxes";
        public static readonly string ViewstateUpdateStatus = "ViewstateUpdateStatus";
        
        public static readonly string DateFormat = "DateFormat";
        public static readonly string DateTimeFormat = "DateTimeFormat";
        public static readonly string DateTimeFormatNumber = "DateTimeFormatNumber";
        public static readonly string ITRequisitionList = "ITRequisitionList";
        public static readonly string CostcentersList = "CostcentersList";
        public static readonly string CatalogusList = "CatalogusList";

        public static readonly string CatalogID = "ID";
        public static readonly string ItemDescription = "ItemDescription";
        public static readonly string VendorItemID = "VendorItemID";
        public static readonly string Comment = "Comment";
        public static readonly string ItemType = "ItemType";
        public static readonly string Manufacturer = "Manufacturer";
        public static readonly string Price = "Price";
        public static readonly string PreferredSupplier = "PreferredSupplier";
        public static readonly string Costcenter = "Costcenter";
        public static readonly string GLAccount = "GLAccount";
        public static readonly string LastSAPReqNr = "LastSAPReqNr";

        public static readonly string ID = "ID";
        public static readonly string Title = "Title";
        public static readonly string RequisitionNumber = "RequisitionNumber";
        public static readonly string Aantal = "Aantal";
        public static readonly string Bestemming = "Bestemming";
        public static readonly string Workorder = "Workorder";
        public static readonly string Customer = "Customer";
        public static readonly string Status = "Status";
        public static readonly string ITContact = "ITContact";
        public static readonly string TotalPrice = "TotalPrice";
        public static readonly string CostcenterProject = "Costcenter/Project";
        public static readonly string CostcenterCompany = "CostcenterCompany";
        public static readonly string CostcenterDescription = "CostcenterDescription";
        public static readonly string Created = "Created";
        public static readonly string CreatedBy = "Author";
        public static readonly string Modified = "Modified";
        public static readonly string ModifiedBy = "Editor";
        public static readonly string CatalogItemID = "CatalogItemID";

        public static readonly string ExceptionHeader = "ITRequisition Antwerp Exception";
        public static readonly string Error_CheckAdminPermission = "Error_CheckAdminPermission";
        public static readonly string Error_CheckUserAuthorized = "Error_CheckUserAuthorized";
        public static readonly string Error_GetListItemByID = "Error_GetListItemByID";
        public static readonly string Error_GetCostcenters = "Error_GetCostcenters";
        public static readonly string Error_GetUserField = "Error_GetUserField";
        public static readonly string Error_GetConfigValues = "Error_GetConfigValues";
        public static readonly string Error_GetRequisitionControl = "Error_GetRequisitionControl";
        public static readonly string Error_SaveForms = "Error_SaveForms";
        public static readonly string Error_DeleteItem = "Error_DeleteItem";

        public static readonly string Query_Requisition = "Query_Requisition";
        public static readonly string Query_Catalog = "Query_Catalog";
        public static readonly string Query_Costcenters = "Query_Costcenters";
        public static readonly string Query_GLAccount = "Query_GLAccount";

        public static Dictionary<string, string> _Config;
        public static Dictionary<string, string> Config
        {
            get
            {
                if (_Config == null)
                    _Config = ITRequisitionUtilities.GetConfigValues();
                return _Config;
            }
        }
        private Constants() { }
    }
}
