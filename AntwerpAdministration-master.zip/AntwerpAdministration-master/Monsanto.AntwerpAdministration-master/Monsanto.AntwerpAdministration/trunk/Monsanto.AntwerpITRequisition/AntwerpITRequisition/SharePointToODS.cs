﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Microsoft.SharePoint;

namespace Monsanto.AntwerpITRequisition
{
    public class RequisitionToSharePoint
    {
        private string SortExpression;

        public RequisitionToSharePoint(string SortExpression)
        {
            this.SortExpression = SortExpression;
        }
        public DataTable Select(string SortExpression)
        {
            SPQuery q = new SPQuery();
            q.Query = @Constants.Config[Constants.Query_Requisition];
            SPList list = SPContext.Current.Web.Lists[Constants.Config[Constants.ITRequisitionList]];
            SPListItemCollection items = list.GetItems(q);
            DataTable dataSource = items.GetDataTable();
            if (SortExpression.ToLowerInvariant().EndsWith("desc desc"))
                SortExpression = SortExpression.Substring(0, SortExpression.Length - 5);

            //need to handle the actual sorting of the data
            if (!string.IsNullOrEmpty(SortExpression))
            {
                DataView view = new DataView(dataSource);
                view.Sort = SortExpression;
                DataTable newTable = view.ToTable();
                dataSource.Clear();
                dataSource = newTable;
            }
            return dataSource;
        }

        public void Update(Dictionary<string, string> data){}

        public void Delete(Dictionary<string, string> data){}
    }

    public class CatalogToSharePoint
    {
        public DataTable Select()
        {
            SPQuery q = new SPQuery();
            q.Query =  @Constants.Config[Constants.Query_Catalog];
            SPList list = SPContext.Current.Web.Lists[Constants.Config[Constants.CatalogusList]];
            SPListItemCollection items = list.GetItems(q);
            return items.GetDataTable();
        }
    }
}
