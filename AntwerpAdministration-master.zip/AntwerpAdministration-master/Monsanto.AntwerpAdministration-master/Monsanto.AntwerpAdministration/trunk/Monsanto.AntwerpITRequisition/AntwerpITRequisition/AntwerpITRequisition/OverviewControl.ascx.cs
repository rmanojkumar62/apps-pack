﻿using System;
using Microsoft.SharePoint.Linq;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Drawing;
using Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition;
using System.Data;
using System.Collections.Generic;
using System.Collections;
using Monsanto.AntwerpITRequisition.AntwerpITRequisitionWebpart;
using System.Reflection;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition
{
    public partial class OverviewControl : ControlBase, IPostBackEventHandler
    {
        private char[] _sep = { ',' };
        private string[] _ssep = { "AND" };

        string FilterExpression
        {
            get
            {
                if (ViewState["FilterExpression"] == null)
                    ViewState["FilterExpression"] = "";
                return (string)ViewState["FilterExpression"];
            }
            set
            {
                string thisFilterExpression = "(" + value.ToString() + ")";
                List<string> fullFilterExpression = new List<string>();
                if (ViewState["FilterExpression"] != null)
                {
                    string[] fullFilterExp = ViewState["FilterExpression"].ToString().Split(_ssep, StringSplitOptions.RemoveEmptyEntries);
                    fullFilterExpression.AddRange(fullFilterExp);
                    int index = fullFilterExpression.FindIndex(s => s.Contains(thisFilterExpression));
                    if (index == -1)
                        fullFilterExpression.Add(thisFilterExpression);
                }
                else
                {
                    fullFilterExpression.Add(thisFilterExpression);
                }
                string filterExp = string.Empty;
                fullFilterExpression.ForEach(s => filterExp += s + " AND ");
                filterExp = filterExp.Remove(filterExp.LastIndexOf(" AND "));
                if (!filterExp.EndsWith("))") && filterExp.Contains("AND"))
                    filterExp = "(" + filterExp + ")";
                ViewState["FilterExpression"] = filterExp;
            }
        }

        string SortExpression
        {
            get
            {
                if (ViewState["SortExpression"] == null)
                    ViewState["SortExpression"] = "";
                return (string)ViewState["SortExpression"];
            }
            set
            {
                string[] thisSE = value.ToString().Split(' ');
                string thisSortExpression = thisSE[0];
                List<string> fullSortExpression = new List<string>();
                if (ViewState["SortExpression"] != null)
                {
                    string[] fullSortExp = ViewState["SortExpression"].ToString().Split(_sep);
                    fullSortExpression.AddRange(fullSortExp);
                    int index = fullSortExpression.FindIndex(s => s.Contains(thisSortExpression));
                    if (index >= 0)
                    {
                        string s = string.Empty;
                        if (value.ToString().Contains("DESC"))
                        { s = value.ToString(); }
                        else
                        {
                            s = fullSortExpression[index];
                            if (s.Contains("ASC"))
                                s = s.Replace("ASC", "DESC");
                            else
                                s = s.Replace("DESC", "ASC");
                        }
                        fullSortExpression[index] = s;
                    }
                    else
                    {
                        if (value.ToString().Contains("DESC"))
                            fullSortExpression.Add(value.ToString());
                        else
                            fullSortExpression.Add(thisSortExpression + " ASC");
                    }
                }
                else
                {
                    if (value.ToString().Contains("DESC"))
                        fullSortExpression.Add(value.ToString());
                    else
                        fullSortExpression.Add(thisSortExpression + " ASC");
                }
                string sortExp = string.Empty;
                fullSortExpression.ForEach(s => sortExp += s);
                sortExp = sortExp.Replace(" ASC", " ASC,");
                sortExp = sortExp.Replace(" DESC", " DESC,");
                ViewState["SortExpression"] = sortExp.Remove(sortExp.LastIndexOf(','));
            }
        }

        public void RaisePostBackEvent(string eventArgument) 
        {
            string[] events = eventArgument.Split(',');
            ODSRequisition.FilterExpression = FilterExpression;
            gridITRequisition.DataBind();
            HIDDENRequisitionNumber.Value = events[1];
            SetUpdateOverviewViewState(false);
            btnSaveAll.Visible = false;
            btnCancel.Visible = false;
            if (pnlRequisitionInfo.Controls.Count > 5)
            {
                for (int i = pnlRequisitionInfo.Controls.Count - 1; i >= 5; i--)
                    pnlRequisitionInfo.Controls.RemoveAt(i);
            }
            switch (events[0].Trim()) 
            {
                case "VIEW":
                    Menu_DisplayItem(events[1],events[2],false);
                    break;
                case "UPDATE":
                    Menu_UpdateItem(events[1], events[2], events[3], false);
                    break;
                case "DELETE":
                    Menu_DeleteItem(events[1], events[2], false);
                    break;
                case "VIEWALL":
                    Menu_DisplayItem(events[1], events[2], true);
                    break;
                case "UPDATEALL":
                    Menu_UpdateItem(events[1], events[2], events[3], true);
                    break;
                case "DELETEALL":
                    Menu_DeleteItem(events[1], events[2], true);
                    break;
            }
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "backtotop();", true);
        }

        private void Menu_DisplayItem(string requisitionnumber, string itemID, bool multipleitems)
        {
            try
            {
                HIDDENMultipleItems.Value = multipleitems.ToString();
                SPListItemCollection collection = null;
                int itemcounter = 0;
                if (!multipleitems)
                    collection = ITRequisitionUtilities.GetSPListItemCollectionByRequisitionNumber(requisitionnumber,itemID, Constants.Config[Constants.ITRequisitionList]);
                else
                    collection = ITRequisitionUtilities.GetSPListItemCollectionByRequisitionNumber(requisitionnumber, Constants.Config[Constants.ITRequisitionList]);
                foreach (SPListItem item in collection)
                {
                    ITRequisition itreq = new ITRequisition();
                    itreq.Aantal = Convert.ToInt32(item[Constants.Aantal]);
                    SPUser customer = ITRequisitionUtilities.GetSharePointUserField(Convert.ToString(item[Constants.Customer]), (SPFieldUser)item.Fields.GetField(Constants.Customer));
                    itreq.CustomerLogin = customer.LoginName;
                    itreq.CustomerName = customer.Name;
                    itreq.Bestemming = Convert.ToString(item[Constants.Bestemming]);
                    SPUser contact = ITRequisitionUtilities.GetSharePointUserField(Convert.ToString(item[Constants.ITContact]), (SPFieldUser)item.Fields.GetField(Constants.ITContact));
                    itreq.ITContactLogin = contact.LoginName;
                    itreq.ITContactName = contact.Name;
                    itreq.Workorder = Convert.ToString(item[Constants.Workorder]);
                    itreq.Costcenter = Convert.ToString(item[Constants.Costcenter]);
                    itreq.GLAccount = Convert.ToString(item[Constants.GLAccount]);
                    itreq.ItemDescription = Convert.ToString(item[Constants.ItemDescription]);
                    itreq.VendorID = Convert.ToString(item[Constants.VendorItemID]);
                    itreq.ItemType = Convert.ToString(item[Constants.ItemType]);
                    itreq.Manufacturer = Convert.ToString(item[Constants.Manufacturer]);
                    itreq.Price = Convert.ToString(item[Constants.Price]);
                    itreq.PreferredSupplier = Convert.ToString(item[Constants.PreferredSupplier]);
                    itreq.LastSAPReqNr = Convert.ToString(item[Constants.LastSAPReqNr]);
                    itreq.CatalogItemID = Convert.ToString(item[Constants.CatalogItemID]);
                    pnlRequisitionInfo.Visible = true;
                    ITRequisitionForm newControl = (ITRequisitionForm)LoadControl(Constants.ITRequisitionForm);
                    pnlRequisitionInfo.Controls.Add(ITRequisitionUtilities.GetITRequisitionControl(this, newControl, itreq, itemcounter, true, CatalogListUrl));
                    Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + newControl.sppCustomerIcon.ClientID + "');", true);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + newControl.sppContactIcon.ClientID + "');", true);
                    itemcounter++;
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }
        
        private void Menu_UpdateItem(string requisitionnumber, string itemID, string catalogItemID, bool multipleitems)
        {
            try
            {
                List<int> itemIDs = GetFormsViewState();
                HIDDENMultipleItems.Value = multipleitems.ToString();
                SPListItemCollection collection = null;
                int itemcounter = 0;
                if (!multipleitems)
                    collection = ITRequisitionUtilities.GetSPListItemCollectionByRequisitionNumber(requisitionnumber, itemID, Constants.Config[Constants.ITRequisitionList]);
                else
                    collection = ITRequisitionUtilities.GetSPListItemCollectionByRequisitionNumber(requisitionnumber, Constants.Config[Constants.ITRequisitionList]);
                foreach (SPListItem item in collection)
                {
                    itemIDs.Add(item.ID);
                    ITRequisition itreq = new ITRequisition();
                    itreq.Aantal = Convert.ToInt32(item[Constants.Aantal]);
                    SPUser customer = ITRequisitionUtilities.GetSharePointUserField(Convert.ToString(item[Constants.Customer]), (SPFieldUser)item.Fields.GetField(Constants.Customer));
                    itreq.CustomerLogin = customer.LoginName;
                    itreq.CustomerName = customer.Name;
                    itreq.Bestemming = Convert.ToString(item[Constants.Bestemming]);
                    SPUser contact = ITRequisitionUtilities.GetSharePointUserField(Convert.ToString(item[Constants.ITContact]), (SPFieldUser)item.Fields.GetField(Constants.ITContact));
                    itreq.ITContactLogin = contact.LoginName;
                    itreq.ITContactName = contact.Name;
                    itreq.Workorder = Convert.ToString(item[Constants.Workorder]);
                    itreq.Costcenter = Convert.ToString(item[Constants.Costcenter]);
                    itreq.GLAccount = Convert.ToString(item[Constants.GLAccount]);
                    itreq.ItemDescription = Convert.ToString(item[Constants.ItemDescription]);
                    itreq.VendorID = Convert.ToString(item[Constants.VendorItemID]);
                    itreq.ItemType = Convert.ToString(item[Constants.ItemType]);
                    itreq.Manufacturer = Convert.ToString(item[Constants.Manufacturer]);
                    itreq.Price = Convert.ToString(item[Constants.Price]);
                    itreq.PreferredSupplier = Convert.ToString(item[Constants.PreferredSupplier]);
                    itreq.LastSAPReqNr = Convert.ToString(item[Constants.LastSAPReqNr]);
                    itreq.CatalogItemID = Convert.ToString(item[Constants.CatalogItemID]);
                    itreq.Status = Convert.ToString(item[Constants.Status]);
                    pnlRequisitionInfo.Visible = true;
                    ITRequisitionForm newControl = (ITRequisitionForm)LoadControl(Constants.ITRequisitionForm);
                    newControl.statusrow.Visible=true;
                    newControl.dropStatus.SelectedValue = itreq.Status;
                    newControl.lblLastSAP2.Visible=false;
                    newControl.txtLastSAP2.Visible=true;
                    newControl.txtLastSAP2.Text = itreq.LastSAPReqNr;
                    newControl.itemID.Value = item.ID.ToString();
                    newControl.catalogID.Value = Convert.ToString(item[Constants.CatalogItemID]);
                    pnlRequisitionInfo.Controls.Add(ITRequisitionUtilities.GetITRequisitionControl(this, newControl, itreq, itemcounter, true, CatalogListUrl));
                    Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + newControl.sppCustomerIcon.ClientID + "');", true);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + newControl.sppContactIcon.ClientID + "');", true);
                    itemcounter++;
                }
                SetFormsViewState(itemIDs);
            }
            catch (SPException ex) { ITRequisitionUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Error_DeleteItem + " (reqID:" + requisitionnumber + ",current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            btnSaveAll.Visible = true;
            btnCancel.Visible = true;
            SetUpdateOverviewViewState(true);
        }

        private void Menu_DeleteItem(string requisitionnumber, string itemID, bool multipleitems)
        {
            try
            {
                HIDDENMultipleItems.Value = multipleitems.ToString();
                SPListItemCollection collection = null;
                if (!multipleitems)
                    collection = ITRequisitionUtilities.GetSPListItemCollectionByRequisitionNumber(requisitionnumber, itemID, Constants.Config[Constants.ITRequisitionList]);
                else
                    collection = ITRequisitionUtilities.GetSPListItemCollectionByRequisitionNumber(requisitionnumber, Constants.Config[Constants.ITRequisitionList]);
                foreach (SPListItem item in collection)
                    SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.ITRequisitionList]).Items.GetItemById(Convert.ToInt32(item.ID)).Recycle();
            }
            catch (SPException ex) { ITRequisitionUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Error_DeleteItem + " (reqID:" + requisitionnumber + ",current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            Refresh();
        }

        protected override void LoadViewState(object savedState)
        {
            base.LoadViewState(savedState);
            if (Context.Request.Form["__EVENTARGUMENT"] != null && Context.Request.Form["__EVENTARGUMENT"].Contains("__ClearFilter__"))
                ViewState.Remove("FilterExpression");
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (ITRequisitionUtilities.HasAdminPermission() || ITRequisitionUtilities.IsUserAuthorized("Antwerp IT Members") || ITRequisitionUtilities.IsUserAuthorized("Antwerp Admin Members"))
            {
                menuitemtemplate_Update.Visible = true;
                menuitemtemplate_Delete.Visible = true;
                menuitemtemplate_UpdateAll.Visible = true;
                menuitemtemplate_DeleteAll.Visible = true;
            }
            else
            {
                menuitemtemplate_Update.Visible = false;
                menuitemtemplate_Delete.Visible = false;
                menuitemtemplate_UpdateAll.Visible = false;
                menuitemtemplate_DeleteAll.Visible = false;
            }
            if (!IsPostBack)
                ResetViewStateObjects();
            else
                if(GetUpdateOverviewViewState())
                    ReloadExistingPanels(GetFormsViewState());
        }

        private void ResetViewStateObjects()
        {
            SetFormsViewState(new List<int>());
            SetUpdateOverviewViewState(false);
        }

        private void ReloadExistingPanels(List<int> itreqs)
        {
            int counter = 0;
            foreach (int itreqID in itreqs)
            {
                AddNewFormToPanel(counter, itreqID);
                counter++;
            }
        }

        private void AddNewFormToPanel(int itrequisitionformscount, int itreqID)
        {
            try
            {
                SPListItem item = ITRequisitionUtilities.GetSPListItemByID(itreqID.ToString(), Constants.Config[Constants.ITRequisitionList]);
                ITRequisition itreq = new ITRequisition();
                itreq.Aantal = Convert.ToInt32(item[Constants.Aantal]);
                SPUser customer = ITRequisitionUtilities.GetSharePointUserField(Convert.ToString(item[Constants.Customer]), (SPFieldUser)item.Fields.GetField(Constants.Customer));
                itreq.CustomerLogin = customer.LoginName;
                itreq.CustomerName = customer.Name;
                itreq.Bestemming = Convert.ToString(item[Constants.Bestemming]);
                SPUser contact = ITRequisitionUtilities.GetSharePointUserField(Convert.ToString(item[Constants.ITContact]), (SPFieldUser)item.Fields.GetField(Constants.ITContact));
                itreq.ITContactLogin = contact.LoginName;
                itreq.ITContactName = contact.Name;
                itreq.Workorder = Convert.ToString(item[Constants.Workorder]);
                itreq.Costcenter = Convert.ToString(item[Constants.Costcenter]);
                itreq.GLAccount = Convert.ToString(item[Constants.GLAccount]);
                itreq.ItemDescription = Convert.ToString(item[Constants.ItemDescription]);
                itreq.VendorID = Convert.ToString(item[Constants.VendorItemID]);
                itreq.ItemType = Convert.ToString(item[Constants.ItemType]);
                itreq.Manufacturer = Convert.ToString(item[Constants.Manufacturer]);
                itreq.Price = Convert.ToString(item[Constants.Price]);
                itreq.PreferredSupplier = Convert.ToString(item[Constants.PreferredSupplier]);
                itreq.LastSAPReqNr = Convert.ToString(item[Constants.LastSAPReqNr]);
                itreq.CatalogItemID = Convert.ToString(item[Constants.CatalogItemID]);
                itreq.Status = Convert.ToString(item[Constants.Status]);
                pnlRequisitionInfo.Visible = true;
                ITRequisitionForm newControl = (ITRequisitionForm)LoadControl(Constants.ITRequisitionForm);
                newControl.statusrow.Visible = true;
                newControl.dropStatus.SelectedValue = itreq.Status;
                newControl.lblLastSAP2.Visible = false;
                newControl.txtLastSAP2.Visible = true;
                newControl.txtLastSAP2.Text = itreq.LastSAPReqNr;
                newControl.itemID.Value = Convert.ToString(item.ID);
                newControl.catalogID.Value = Convert.ToString(item[Constants.CatalogItemID]);
                pnlRequisitionInfo.Controls.Add(ITRequisitionUtilities.GetITRequisitionControl(this, newControl, itreq, itrequisitionformscount, true, CatalogListUrl));
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + newControl.sppCustomerIcon.ClientID + "');", true);
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + newControl.sppContactIcon.ClientID + "');", true);
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            try
            {
                BindPaging();
                ODSRequisition.TypeName = this.GetType().AssemblyQualifiedName;
                ODSRequisition.FilterExpression = FilterExpression;
                ODSRequisition.Updating += new ObjectDataSourceMethodEventHandler(ODSRequisition_Updating);
                ODSRequisition.Deleting += new ObjectDataSourceMethodEventHandler(ODSRequisition_Deleting);
            }
            catch (Exception ex) { }
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (!Page.IsPostBack)
                gridITRequisition.DataBind();
            BuildFilterView(ODSRequisition.FilterExpression);
        }

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        private void BindPaging()
        {
            gridITRequisition.PagerTemplate = null;
            gridITRequisition.PageIndexChanging += new GridViewPageEventHandler(gridITRequisition_PageIndexChanging);
        }
        
        private void ODSRequisition_Updating(object sender, ObjectDataSourceMethodEventArgs e)
        {
            Dictionary<string, string> dic = GetParameters(e);
            e.InputParameters.Clear();
            e.InputParameters.Add("data", dic);
        }

        private void ODSRequisition_Deleting(object sender, ObjectDataSourceMethodEventArgs e)
        {
            try
            {
                if (ITRequisitionUtilities.HasAdminPermission())
                {
                    Dictionary<string, string> dic = GetParameters(e);
                    e.InputParameters.Clear();
                    e.InputParameters.Add("data", dic);
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        public void Refresh()
        {
            pnlRequisitionInfo.Visible = false;
            gridITRequisition.SelectedIndex = -1;
            gridITRequisition.DataBind();
        }

        private Dictionary<string, string> GetParameters(ObjectDataSourceMethodEventArgs e)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            foreach (DictionaryEntry entry in e.InputParameters)
            {
                string value = entry.Value == null ? null : entry.Value.ToString();
                data.Add(entry.Key.ToString(), value);
            }
            return data;
        }

        protected void gridITRequisition_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                gridITRequisition.Columns[0].Visible = false;
                if (sender == null || e.Row.RowType != DataControlRowType.Header)
                {
                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        ((Microsoft.SharePoint.WebControls.Menu)e.Row.Cells[1].Controls[0]).MenuFormat = Microsoft.SharePoint.WebControls.MenuFormat.ArrowAlwaysVisible;
                        ((Microsoft.SharePoint.WebControls.Menu)e.Row.Cells[1].Controls[0]).Text = "Actions";
                    }
                    return; 
                }
                for (int i = 0; i < gridITRequisition.Columns.Count; i++)
                {
                    DataControlField field = gridITRequisition.Columns[i];
                    if (FilterExpression.Contains(field.SortExpression) && !string.IsNullOrEmpty(FilterExpression))
                    {
                        if (e.Row.Cells[i].Controls.Count > 0)
                        {
                            PlaceHolder panel = HeaderImages(field, "/_layouts/images/filter.gif");
                            e.Row.Cells[i].Controls[0].Controls.Add(panel);
                        }
                    }
                    else if (SortExpression.Contains(field.SortExpression))
                    {
                        if (e.Row.Cells[i].Controls.Count > 0)
                        {
                            string url = SortImage(field);
                            PlaceHolder panel = HeaderImages(field, url);
                            e.Row.Cells[i].Controls[0].Controls.Add(panel);
                        }
                    }
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { /*ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty);*/ }
        }

        protected void gridITRequisition_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sDir = e.SortDirection.ToString();
            sDir = sDir == "Descending" ? " DESC" : "";
            SortExpression = e.SortExpression + sDir;
            e.SortExpression = SortExpression;
            if (!string.IsNullOrEmpty(FilterExpression))
                ODSRequisition.FilterExpression = FilterExpression;
        }

        protected void gridITRequisition_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridITRequisition.PageIndex = e.NewPageIndex;
        }

        protected void btnMenu_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.Path);
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl.Replace(Convert.ToString(Mode.Overview), Convert.ToString(Mode.Requisition)), false);
        }

        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            if (ViewState.Keys.Cast<string>().ToList().Contains("FilterExpression"))
            {
                ViewState.Remove("FilterExpression");
                ODSRequisition.FilterExpression = string.Empty;
                gridITRequisition.DataBind();
            }
        }

        protected void btnSaveAll_Click(object sender, EventArgs e)
        {
            try
            {
                ODSRequisition.FilterExpression = FilterExpression;
                gridITRequisition.DataBind();
                ControlCollection ctrls = pnlRequisitionInfo.Controls;
                for (int i = 0; i < ctrls.Count; i++)
                {
                    if (ctrls[i].Controls.Count > 0 && ctrls[i].ID.Contains(Constants.itctrl + Constants.Char_Underscore))
                    {
                        ITRequisitionForm form = (ITRequisitionForm)ctrls[i];
                        string reqID = form.itemID.Value;
                        string catalogID = form.catalogID.Value;
                        SPListItem requisitionitem = ITRequisitionUtilities.GetSPListItemByID(reqID, Constants.Config[Constants.ITRequisitionList]);
                        requisitionitem[Constants.LastSAPReqNr] = form.txtLastSAP2.Text;
                        requisitionitem[Constants.Status] = form.dropStatus.SelectedValue;
                        requisitionitem.Update();
                        SPListItem catalogitem = ITRequisitionUtilities.GetSPListItemByID(catalogID, Constants.Config[Constants.CatalogusList]);
                        catalogitem[Constants.LastSAPReqNr] = form.txtLastSAP2.Text;
                        catalogitem.Update();
                        gridITRequisition.DataBind();
                    }
                }
                btnSaveAll.Visible = false;
                btnCancel.Visible = false;
                ResetViewStateObjects();
                Refresh();
            }
            catch (Exception ex) { }
        }

        protected void btnCancelAll_Click(object sender, EventArgs e)
        {
            try
            {
                ODSRequisition.FilterExpression = FilterExpression;
                gridITRequisition.DataBind();
                btnSaveAll.Visible = false;
                btnCancel.Visible = false;
                ResetViewStateObjects();
                Refresh();
            }
            catch (Exception ex) { }
        }

        public DataTable Select(string SortExpression)
        {
            SPQuery q = new SPQuery();
            q.Query = @Constants.Config[Constants.Query_Requisition];
            SPList list = SPContext.Current.Web.Lists[Constants.Config[Constants.ITRequisitionList]];
            SPListItemCollection items = list.GetItems(q);
            DataTable dataSource = items.GetDataTable();
            if (SortExpression.ToLowerInvariant().EndsWith("desc desc"))
                SortExpression = SortExpression.Substring(0, SortExpression.Length - 5);
            if (!string.IsNullOrEmpty(SortExpression))
            {
                DataView view = new DataView(dataSource);
                view.Sort = SortExpression;
                DataTable newTable = view.ToTable();
                dataSource.Clear();
                dataSource = newTable;
            }
            return dataSource; 
        }

        public void Update(Dictionary<string, string> data) { }

        public void Delete(Dictionary<string, string> data) { }

        private string SortImage(DataControlField field)
        {
            string url = string.Empty;
            string[] fullSortExp = SortExpression.Split(_sep);
            List<string> fullSortExpression = new List<string>();
            fullSortExpression.AddRange(fullSortExp);
            int index = fullSortExpression.FindIndex(s => s.Contains(field.SortExpression));
            if (index >= 0)
            {
                string s = fullSortExpression[index];
                if (s.Contains("ASC"))
                { url = "_layouts/images/sortup.gif"; }
                else
                { url = "_layouts/images/sortdown.gif"; }
            }
            return url;
        }

        private PlaceHolder HeaderImages(DataControlField field, string imageUrl)
        {
            System.Web.UI.WebControls.Image filterIcon = new System.Web.UI.WebControls.Image();
            filterIcon.ImageUrl = imageUrl;
            filterIcon.Style[HtmlTextWriterStyle.MarginLeft] = "2px";
            Literal headerText = new Literal();
            headerText.Text = field.HeaderText;
            PlaceHolder panel = new PlaceHolder();
            panel.Controls.Add(headerText);
            if (FilterExpression.Contains(field.SortExpression) && SortExpression.Contains(field.SortExpression)) 
            {
                string url = SortImage(field);
                System.Web.UI.WebControls.Image sortIcon = new System.Web.UI.WebControls.Image();
                sortIcon.ImageUrl = url;
                sortIcon.Style[HtmlTextWriterStyle.MarginLeft] = "1px";
                panel.Controls.Add(sortIcon);
                filterIcon.Style[HtmlTextWriterStyle.MarginLeft] = "1px";
            }
            panel.Controls.Add(filterIcon);
            return panel;
        }

        void BuildFilterView(string filterExp)
        {
            string lastExp = filterExp;
            if (lastExp.Contains("AND"))
            {
                if (lastExp.Length < lastExp.LastIndexOf("AND") + 4)
                    lastExp = lastExp.Substring(lastExp.LastIndexOf("AND") + 4);
                else
                    lastExp = string.Empty;
            }
            if (!string.IsNullOrEmpty(lastExp))
                FilterExpression = lastExp;
            if (!string.IsNullOrEmpty(FilterExpression))
                ODSRequisition.FilterExpression = FilterExpression;
        }
    }
}