﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint;
using System.Reflection;

namespace Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition
{
    public class ControlBase : UserControl
    {
        #region PROPERTIES
        public string AppName { get; set; }
        public string OutboundSMTPServer { get; set; }
        public string ApplicationEmail { get; set; }
        public string SharePointServicesEmail { get; set; }
        public string UsersToNotify { get; set; }
        public string SiteRootUrl { get; set; }
        public string WebpartPageUrl { get; set; }
        public string StyleLibraryPath { get; set; }
        public string ImagesPath { get; set; }
        public string EmailHeaderImage { get { return Server.MapPath("~/_layouts/AntwerpITRequisition/images/monsantoHeader.png"); } }
        public string CatalogListUrl { get; set; }
        public string CostcentersListUrl { get; set; }
        public string UserProfileImageUrl { get; set; }
        public string CatalogEditorsGroup { get; set; }
        #endregion

        #region VIRTUAL METHODS
        protected virtual void ResetRequiredFields() { }
        public virtual void DisablePanel() { }
        protected virtual bool CheckRequiredFields() { return false; }
        protected virtual void PageRefresh() { }
        protected virtual void LoadITRequisition(Mode mode) { }
        #endregion

        #region VIEWSTATE OBJECTS
        public void SetUpdateOverviewViewState(bool update)
        {
            ViewState["ViewStateUpdateOverview"] = update;
        }
        public bool GetUpdateOverviewViewState()
        {
            return (bool)ViewState["ViewStateUpdateOverview"];
        }
        public void SetFormsViewState(List<int> forms)
        {
            ViewState[Constants.ViewstateITRequistions] = forms;
        }
        public List<int> GetFormsViewState()
        {
            if (((List<int>)ViewState[Constants.ViewstateITRequistions]) == null)
                return new List<int>();
            else
                return (List<int>)ViewState[Constants.ViewstateITRequistions];
        }
        public void SetITRequisitionsViewState(Dictionary<int, ITRequisition> forms)
        {
            ViewState[Constants.ViewstateITRequistions] = forms;
        }

        public Dictionary<int, ITRequisition> GetITRequisitionsViewState()
        {
            if (((Dictionary<int, ITRequisition>)ViewState[Constants.ViewstateITRequistions]) == null)
                return new Dictionary<int, ITRequisition>();
            else
                return (Dictionary<int, ITRequisition>)ViewState[Constants.ViewstateITRequistions];
        }

        public void SetITRequisitionsCheckboxViewState(Dictionary<int, bool> forms)
        {
            ViewState[Constants.ViewstateITRequistionsCheckboxes] = forms;
        }

        public Dictionary<int, bool> GetITRequisitionsCheckboxViewState()
        {
            if (((Dictionary<int, bool>)ViewState[Constants.ViewstateITRequistionsCheckboxes]) == null)
                return new Dictionary<int, bool>();
            else
                return (Dictionary<int, bool>)ViewState[Constants.ViewstateITRequistionsCheckboxes];
        }

        public void SetUpdateViewState(bool wrongvalue)
        {
            ViewState[Constants.ViewstateUpdateStatus] = wrongvalue;
        }

        public bool GetUpdateViewState()
        {
            return (bool)ViewState[Constants.ViewstateUpdateStatus];
        }
        #endregion

        protected override void OnLoad(EventArgs e)
        {
            try
            {
                base.OnLoad(e);
                if (!IsPostBack)
                {
                    if (Request.QueryString.Count == 0)
                        LoadITRequisition(Mode.Empty);
                    else if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringReloadConfig])&&ITRequisitionUtilities.HasAdminPermission())
                        Constants._Config = null;
                    else if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringMode]))
                        LoadITRequisition(ITRequisitionUtilities.GetMode(Request.QueryString[Constants.QueryStringMode]));
                    else
                        LoadITRequisition(Mode.Empty);
                }
                else
                    PageRefresh();
            }
            catch (Exception ex) { }
        }

        public void LoadControl(AntwerpITRequisitionWebpart.AntwerpITRequisitionWebpart webpart)
        {
            AppName = webpart.AppName;
            OutboundSMTPServer = webpart.OutboundSMTPserver;
            ApplicationEmail = webpart.EmailApp;
            SharePointServicesEmail = webpart.SharePointServicesTeamEmail;
            UsersToNotify = webpart.UsersToNotify;
            SiteRootUrl = webpart.SiteRootUrl;
            WebpartPageUrl = webpart.WebpartPageUrl;
            StyleLibraryPath = webpart.StyleLibraryPath;
            ImagesPath = webpart.StyleLibraryPath + "images/";
            CatalogListUrl = webpart.CatalogListUrl;
            CostcentersListUrl = webpart.CostcentersListUrl;
            UserProfileImageUrl = webpart.UserProfileImageUrl;
            CatalogEditorsGroup = webpart.CatalogEditorsGroup;
        }

        protected void Confirmation(string requisitionnumber, List<ITRequisition> itreqs)
        {
            try
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), string.Concat("confirmation('');"), true);
                MailCreator.SendMail(requisitionnumber,itreqs, this);
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void ThrowError(ErrorType errortype, string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "error('" + errortype + "','" + ITRequisitionUtilities.FormatErrorMessageForUI(message) + "');", true);
        }

        protected void ThrowError(ErrorType errortype, Exception ex)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, ex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(ex.Message);
            MailCreator.SendErrorMail(ex.Message, ex.StackTrace, (ex.InnerException == null) ? string.Empty : ex.InnerException.Message, this);
            if (ex.Message.IndexOf(Constants.Char_Splitter) != -1)
                ThrowError(errortype, ex.Message.Substring(0, ex.Message.IndexOf(Constants.Char_Splitter)));
        }

        protected void ThrowError(ErrorType errortype, ITRequisitionException pex)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, pex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(pex.Message);
            MailCreator.SendErrorMail(pex.Message, pex.StackTrace, (pex.InnerException == null) ? string.Empty : pex.InnerException.Message, this);
            if (!string.IsNullOrEmpty(pex.FriendlyMessage))
                ThrowError(errortype, pex.FriendlyMessage);
        }

        protected void ThrowError(ErrorType errortype, Exception ex, string classname, string method, string friendlymessage)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, ex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(ex.Message);
            MailCreator.SendErrorMail(ex.Message, ex.StackTrace, (ex.InnerException == null) ? string.Empty : ex.InnerException.Message, this);
            if (!string.IsNullOrEmpty(friendlymessage))
                ThrowError(errortype, friendlymessage);
        }
    }
}