﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using Microsoft.SharePoint;
using Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition;
using System.Collections.Generic;
using System.Drawing;
using Microsoft.SharePoint.WebControls;
using System.Net;
using System.Collections;
using System.Reflection;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition
{
    public partial class CatalogControl : ControlBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected override void CreateChildControls()
        {
            ODSCatalog.TypeName = typeof(CatalogToSharePoint).AssemblyQualifiedName;
            ODSCatalog.ObjectCreating += new ObjectDataSourceObjectEventHandler(ODSCatalog_ObjectCreating);
        }

        private Dictionary<string, string> GetParameters(ObjectDataSourceMethodEventArgs e)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            foreach (DictionaryEntry entry in e.InputParameters)
            {
                string value = entry.Value == null ? null : entry.Value.ToString();
                data.Add(entry.Key.ToString(), value);
            }
            return data;
        }

        private void ODSCatalog_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
        {
            e.ObjectInstance = new CatalogToSharePoint();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                ResetViewStateObjects();
            else
            {
                ReloadExistingPanels(GetITRequisitionsViewState());
                CheckDisableDeleteButton();
            }
        }

        private void ResetViewStateObjects()
        {
            SetITRequisitionsCheckboxViewState(new Dictionary<int, bool>());
            SetITRequisitionsViewState(new Dictionary<int, ITRequisition>());
        }

        private void ReloadExistingPanels(Dictionary<int, ITRequisition> itreqs)
        {
            int counter = 0;
            foreach (ITRequisition itreq in itreqs.Values)
            {
                AddNewFormToPanel(counter, itreq);
                counter++;
            }
        }
        
        public void Refresh()
        {
            gridCatalogItems.DataBind();
        }

        protected void btnMenu_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.Path);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<int, bool> checkboxes = GetITRequisitionsCheckboxViewState();
                List<int> keys = new List<int>(checkboxes.Keys);
                foreach (int index in keys)
                    checkboxes[index] = true;
                SetITRequisitionsCheckboxViewState(checkboxes);
                Dictionary<int, ITRequisition> itreqs = GetFormData();
                SetITRequisitionsViewState(itreqs);
                btnBack.Visible = false;
                btnSave.Visible = false;
                btnNext.Visible = true;
                pnlITRequisitionControl.Visible = false;
                pnlCatalogControl.Visible = true;
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<int, ITRequisition> itreqs;
                itreqs = GetITRequisitionsViewState();
                CheckChangedCheckboxes(GetITRequisitionsCheckboxViewState(), itreqs);
                if (GenerateAccordion())
                {
                    pnlCatalogControl.Visible = false;
                    btnBack.Visible = true;
                    btnSave.Visible = true;
                    btnNext.Visible = false;
                    pnlITRequisitionControl.Visible = true;
                    CheckDisableDeleteButton();
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Dictionary<int, ITRequisition> itreqs;
                ResetRequiredFields();
                if (CheckRequiredFields())
                {
                    ThrowError(ErrorType.FIELDS, string.Empty);
                    return;
                }
                itreqs = GetFormData();
                List<ITRequisition> itrequisitions = new List<ITRequisition>();
                string requisitiondate = DateTime.Now.AddHours(7).ToString(Constants.Config[Constants.DateFormat]);
                string requisitionnumber = DateTime.Now.AddHours(7).ToString(Constants.Config[Constants.DateTimeFormatNumber]);
                itrequisitions = ITRequisitionUtilities.SaveForms(requisitiondate, requisitionnumber, itreqs);
                ResetViewStateObjects();
                btnBack.Enabled = false;
                btnSave.Enabled = false;
                Confirmation(requisitionnumber, itrequisitions);
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        private bool GenerateAccordion()
        {
            try
            {
                Dictionary<int, bool> checkboxes = GetITRequisitionsCheckboxViewState();
                if (checkboxes.Count == 0)
                {
                    ThrowError(ErrorType.FIELDS,"Please select at least 1 item to proceed!");
                    return false;
                }
                else
                {
                    Dictionary<int, ITRequisition> itreqs = GetITRequisitionsViewState();
                    foreach (KeyValuePair<int, bool> kvp in checkboxes)
                    {
                        if (kvp.Value == false)
                        {
                            string itemID = ((HiddenField)gridCatalogItems.Rows[kvp.Key].FindControl("HIDDENCatalogItemID")).Value;
                            SPListItem item = ITRequisitionUtilities.GetSPListItemByID(itemID,Constants.Config[Constants.CatalogusList]);
                            ITRequisition requisition = new ITRequisition();
                            requisition.CatalogItemID = Convert.ToString(item[Constants.ID]);
                            requisition.ItemDescription = Convert.ToString(item[Constants.ItemDescription]);
                            requisition.VendorID = Convert.ToString(item[Constants.VendorItemID]);
                            requisition.ItemType = Convert.ToString(item[Constants.ItemType]);
                            requisition.Manufacturer = Convert.ToString(item[Constants.Manufacturer]);
                            requisition.Price = Convert.ToString(item[Constants.Price]);
                            requisition.PreferredSupplier = Convert.ToString(item[Constants.PreferredSupplier]);
                            requisition.Costcenter = Convert.ToString(item[Constants.Costcenter]).Substring(Convert.ToString(item[Constants.Costcenter]).IndexOf('#') + 1);
                            requisition.GLAccount = Convert.ToString(item[Constants.GLAccount]);
                            requisition.LastSAPReqNr = Convert.ToString(item[Constants.LastSAPReqNr]);
                            Dictionary<string, string> attachmentlist = new Dictionary<string, string>();
                            foreach (string attachment in item.Attachments)
                                attachmentlist.Add(attachment,string.Concat(CatalogListUrl,"Attachments/", item.ID, "/", attachment));
                            requisition.Offertes = attachmentlist;
                            AddNewFormToPanel(itreqs.Count, requisition);
                            itreqs.Add(kvp.Key, requisition);
                        }
                    }
                    SetITRequisitionsViewState(itreqs);
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
            return true;
        }

        private Dictionary<int, ITRequisition> GetFormData()
        {
            Dictionary<int, ITRequisition> dic = GetITRequisitionsViewState();
            try
            {
                ControlCollection ctrls = ITRequisitionUtilities.FindChildControl(pnlITRequisitionControl, "pnlForms").Controls;
                List<int> keyslist = new List<int>(dic.Keys);
                List<ITRequisition> reqs = new List<ITRequisition>(dic.Values);
                for (int i = 0; i < ctrls.Count; i++)
                {
                    if (ctrls[i].Controls.Count > 0 && ctrls[i].ID.Contains(Constants.itctrl + Constants.Char_Underscore))
                    {
                        ITRequisitionForm form = (ITRequisitionForm)ctrls[i];
                        ITRequisition req = reqs[i];
                        req.Aantal = string.IsNullOrEmpty(form.txtAantal.Text) ? 0 : Convert.ToInt16(form.txtAantal.Text);
                        req.CustomerName = form.sppCustomerText.Value;
                        req.CustomerLogin = form.sppCustomerID.Value;
                        req.Bestemming = form.txtBestemming.Text;
                        req.ITContactName = form.sppContactText.Value;
                        req.ITContactLogin = form.sppContactID.Value;
                        req.Workorder = form.txtWorkorder.Text;
                        if (!form.dropCostcenter.SelectedValue.Equals("Other"))
                            req.Costcenter = form.dropCostcenter.SelectedValue;
                        else
                            req.Costcenter = form.txtCostcenter.Text;
                        if (!form.dropGLAccount.SelectedValue.Equals("Other"))
                            req.GLAccount = form.dropGLAccount.SelectedValue;
                        else
                            req.GLAccount = form.txtGLAccount.Text;
                        dic[keyslist[i]] = req;
                        if (!string.IsNullOrEmpty(form.sppCustomerID.Value))
                            form.sppCustomerIcon.Src = string.Concat(UserProfileImageUrl.Split(Constants.Char_Splitter)[0], form.sppCustomerID.Value.Replace("_p", "").Replace(Constants.Char_Backslash, Constants.Char_Underscore), UserProfileImageUrl.Split(Constants.Char_Splitter)[1]);
                        if (!string.IsNullOrEmpty(form.sppContactID.Value))
                            form.sppContactIcon.Src = string.Concat(UserProfileImageUrl.Split(Constants.Char_Splitter)[0], form.sppContactID.Value.Replace("_p", "").Replace(Constants.Char_Backslash, Constants.Char_Underscore), UserProfileImageUrl.Split(Constants.Char_Splitter)[1]);
                        Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + form.sppCustomerIcon.ClientID + "');", true);
                        Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "checkimageurl('" + form.sppContactIcon.ClientID + "');", true);
                    }
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
            return dic;
        }

        private void AddNewFormToPanel(int itrequisitionformscount, ITRequisition itreq)
        {
            try
            {
                ITRequisitionForm newControl = (ITRequisitionForm)LoadControl(Constants.ITRequisitionForm);
                pnlForms.Controls.Add(ITRequisitionUtilities.GetITRequisitionControl(this, newControl, itreq, itrequisitionformscount, false,CatalogListUrl));
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        public void CheckDisableDeleteButton()
        {
            try
            {
                ITRequisitionForm frm = (ITRequisitionForm)ITRequisitionUtilities.FindChildControl(pnlForms, Constants.itctrl + Constants.Char_Underscore + "0");
                if (frm != null)
                {
                    if (GetITRequisitionsCheckboxViewState().Keys.Count == 1)
                    {
                        frm.btnDelete.Enabled = false;
                        frm.btnDelete.ImageUrl = ImagesPath + "deletegray.gif";
                    }
                    else
                    {
                        frm.btnDelete.Enabled = true;
                        frm.btnDelete.ImageUrl = ImagesPath + "delete.gif";
                    }
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected override void ResetRequiredFields()
        {
            try
            {
                foreach (Control ctrl in pnlForms.Controls)
                {
                    if (ctrl.Controls.Count > 0 && ctrl.ID.IndexOf(Constants.itctrl) != -1)
                    {
                        ITRequisitionForm frm = (ITRequisitionForm)ctrl;
                        frm.lblAantal.ForeColor = Color.Empty;
                        frm.lblCustomer.ForeColor = Color.Empty;
                        frm.lblBestemming.ForeColor = Color.Empty;
                        frm.lblContact.ForeColor = Color.Empty;
                        frm.lblCostcenter.ForeColor = Color.Empty;
                    }
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected override bool CheckRequiredFields()
        {
            bool check = false;
            foreach (Control ctrl in pnlForms.Controls)
            {
                if (ctrl.Controls.Count > 0 && ctrl.ID.IndexOf(Constants.itctrl) != -1)
                {
                    ITRequisitionForm frm = (ITRequisitionForm)ctrl;
                    int result;
                    if (string.IsNullOrEmpty(frm.txtAantal.Text) || !Int32.TryParse(frm.txtAantal.Text, out result))
                    {
                        frm.lblAantal.ForeColor = Color.Red;
                        check = true;
                    }
                    if (string.IsNullOrEmpty(frm.sppCustomerID.Value))
                    {
                        frm.lblCustomer.ForeColor = Color.Red;
                        check = true;
                    }
                    if (string.IsNullOrEmpty(frm.txtBestemming.Text))
                    {
                        frm.lblBestemming.ForeColor = Color.Red;
                        check = true;
                    }
                    if (string.IsNullOrEmpty(frm.sppContactID.Value))
                    {
                        frm.lblContact.ForeColor = Color.Red;
                        check = true;
                    }
                    if (frm.dropCostcenter.SelectedIndex <= 0)
                    {
                        frm.lblCostcenter.ForeColor = Color.Red;
                        check = true;
                    }
                    else if (frm.dropCostcenter.SelectedValue.Equals("Other") && string.IsNullOrEmpty(frm.txtCostcenter.Text))
                    {
                        frm.lblCostcenter.ForeColor = Color.Red;
                        check = true;
                    }
                }
            }
            return check;
        }

        private void CheckChangedCheckboxes(Dictionary<int, bool> checkedstatedic, Dictionary<int, ITRequisition> itreqs)
        {
            try
            {
                foreach (GridViewRow row in gridCatalogItems.Rows)
                {
                    if (((CheckBox)row.FindControl("chkBxCatalogItem")).Checked)
                    {
                        if (!checkedstatedic.ContainsKey(row.RowIndex))
                            checkedstatedic.Add(row.RowIndex, false);
                    }
                    else
                    {
                        if (checkedstatedic.ContainsKey(row.RowIndex))
                        {
                            checkedstatedic.Remove(row.RowIndex);
                            itreqs.Remove(row.RowIndex);
                        }
                    }
                }
                SetITRequisitionsCheckboxViewState(checkedstatedic);
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }
        
        public void UncheckDeletedItems(int rowindex)
        {
            try
            {
                GridViewRow row = gridCatalogItems.Rows[rowindex];
                ((CheckBox)row.FindControl("chkBxCatalogItem")).Checked = false;
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }
    }
}