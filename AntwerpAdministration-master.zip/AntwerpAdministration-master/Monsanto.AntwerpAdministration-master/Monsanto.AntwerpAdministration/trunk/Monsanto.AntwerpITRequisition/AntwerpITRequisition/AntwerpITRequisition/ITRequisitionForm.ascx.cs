﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Monsanto.AntwerpITRequisition.AntwerpITRequisitionWebpart;
using System.Collections.Generic;
using System.Reflection;

namespace Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition
{
    public partial class ITRequisitionForm : ControlBase
    {
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string formID = ((ITRequisitionForm)ITRequisitionUtilities.FindParentControl((ImageButton)sender, typeof(ITRequisitionForm))).ID;
                int index = Int32.Parse(formID.Substring(formID.IndexOf(Constants.Char_Underscore) + 1));
                Control pnlForms = (Control)((ImageButton)sender).Parent.Parent.Parent;
                CatalogControl aitrwpuc = (CatalogControl)ITRequisitionUtilities.FindParentControl(this, typeof(CatalogControl));
                Dictionary<int, bool> checkboxes = aitrwpuc.GetITRequisitionsCheckboxViewState();
                int rowindex = checkboxes.Keys.ElementAt(index);
                checkboxes.Remove(rowindex);
                aitrwpuc.SetITRequisitionsCheckboxViewState(checkboxes);
                Dictionary<int, ITRequisition> itrequisitions = aitrwpuc.GetITRequisitionsViewState();
                rowindex = itrequisitions.Keys.ElementAt(index);
                itrequisitions.Remove(rowindex);
                aitrwpuc.SetITRequisitionsViewState(itrequisitions);
                aitrwpuc.UncheckDeletedItems(rowindex);
                aitrwpuc.CheckDisableDeleteButton();
                pnlForms.Controls.RemoveAt(index);
                if (pnlForms.Controls.Count > 0)
                {
                    for (int j = 0; j < pnlForms.Controls.Count; j++)
                    {
                        if (pnlForms.Controls[j].ID != null && pnlForms.Controls[j].ID.IndexOf(Constants.Char_Underscore) != -1)
                        {
                            int contindex = Int32.Parse(pnlForms.Controls[j].ID.Substring(pnlForms.Controls[j].ID.IndexOf(Constants.Char_Underscore) + 1));
                            if (contindex > index)
                            {
                                pnlForms.Controls[j].ID = String.Format(Constants.itctrl + Constants.Char_Underscore + "{0}", index);
                                Label legend = (Label)pnlForms.Controls[j].FindControl("lblITRequisitionFormLegend");
                                legend.Text = "Item " + (index + 1);
                                index++;
                            }
                        }
                    }
                }
            }
            catch (ITRequisitionException iex) { ThrowError(ErrorType.RUNTIME, iex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void dropCostcenter_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropCostcenter.SelectedValue.Equals("Other"))
            {
                this.txtCostcenter.Text = string.Empty;
                this.txtCostcenter.Visible = true;
            }
            else
            {
                this.txtCostcenter.Visible = false;
                ITRequisitionUtilities.GetGLAccounts(dropGLAccount, dropCostcenter.SelectedValue);
                this.txtGLAccount.Visible = false;
            }
        }

        protected void dropGLAccount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropGLAccount.SelectedValue.Equals("Other"))
            {
                this.txtGLAccount.Text = string.Empty;
                this.txtGLAccount.Visible = true;
            }
            else
                this.txtGLAccount.Visible = false;
        }
    }
}