﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.AntwerpITRequisition
{
    [Serializable]
    public class ITRequisition
    {
        public int ID { get; set; }
        public int Aantal { get; set; }
        public string CustomerName { get; set; }
        public string CustomerLogin { get; set; }
        public string Bestemming { get; set; }
        public string ITContactName { get; set; }
        public string ITContactLogin { get; set; }
        public string Workorder { get; set; }
        
        public string Costcenter { get; set; }
        public string CostcenterCompany { get; set; }
        public string CostcenterDescription { get; set; }
        public string GLAccount { get; set; }

        public string ItemDescription { get; set; }
        public string VendorID { get; set; }
        public string ItemType { get; set; }
        public string Manufacturer { get; set; }
        public string Price { get; set; }
        public string PreferredSupplier { get; set; }
        public string LastSAPReqNr { get; set; }
        public string CatalogItemID { get; set; }

        public double TotalPrice { get; set; }
        public DateTime Created { get; set; }
        public string Author { get; set; }
        public DateTime Modified { get; set; }
        public string Editor { get; set; }
        public string Status { get; set; }
        public Dictionary<string,string> Offertes { get; set; }
    }
}
