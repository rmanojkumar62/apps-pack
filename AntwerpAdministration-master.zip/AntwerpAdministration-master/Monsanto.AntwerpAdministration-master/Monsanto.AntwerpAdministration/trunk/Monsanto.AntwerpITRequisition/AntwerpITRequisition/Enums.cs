﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.AntwerpITRequisition
{
    public enum Mode
    {
        Empty,
        Overview,
        Requisition
    }
    public enum Status
    {
        Empty,
        Initiated,
        SAPOrdered,
        Delivered,
        Canceled
    }
    public enum ErrorType
    {
        FIELDS,
        RUNTIME
    }
}
