﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.AntwerpITRequisition.AntwerpITRequisitionWebpart
{
    [ToolboxItemAttribute(false)]
    public class AntwerpITRequisitionWebpart : WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/AntwerpITRequisition/AntwerpITRequisitionWebpart/AntwerpITRequisitionWebpartUserControl.ascx";
        private string appname = "Antwerp IT Requisitions";
        private string outboundSMTPserver = "mail.monsanto.com";
        private string emailapp = "itrequisitionsAntwerp@monsanto.com";
        private string sharepointservicesteamemail = "sharepoint.services.antwerp@monsanto.com";
        private string userstonotify = "jill.schauwvlieghe@monsanto.com*jurgen.claes@monsanto.com";
        private string siterooturl = "http://stlwspidvmdev39:9000/enterprise/antwerpadministration/";
        private string webpartpageurl = "http://stlwspidvmdev39:9000/enterprise/antwerpadministration/ITRequisition/default.aspx";
        private string stylelibrarypath = "/enterprise/antwerpadministration/Style Library/Antwerp Administration Design/";
        private string cataloglisturl = "http://stlwspidvmdev39:9000/enterprise/antwerpadministration/ITRequisition/Lists/Catalogus/";
        private string costcenterslisturl = "http://stlwspidvmdev39:9000/enterprise/antwerpadministration/ITRequisition/Lists/Costcenters/";
        private string userprofileimageurl = "http://mysites.monsanto.com/User%20Photos/Profile%20Pictures/" + Constants.Char_Splitter + "_LThumb.JPG";
        private string catalogeditorsgroup = "Catalog Editors";
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Catalog Editors Group"),
        WebDescription("Set Catalog Editors Group.")]
        public string CatalogEditorsGroup
        {
            get { return catalogeditorsgroup; }
            set { catalogeditorsgroup = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Application name"),
        WebDescription("Set application name.")]
        public string AppName
        {
            get { return appname; }
            set { appname = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Outbound SMTP server"),
        WebDescription("Set outbound SMTP server.")]
        public string OutboundSMTPserver
        {
            get { return outboundSMTPserver; }
            set { outboundSMTPserver = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Email application"),
        WebDescription("Set email of application.")]
        public string EmailApp
        {
            get { return emailapp; }
            set { emailapp = value; }
        }

        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("SharePoint Services team email"),
        WebDescription("Set SHarePoint services team email.")]
        public string SharePointServicesTeamEmail
        {
            get { return sharepointservicesteamemail; }
            set { sharepointservicesteamemail = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Users to notify"),
        WebDescription("Set users to notify.")]
        public string UsersToNotify
        {
            get { return userstonotify; }
            set { userstonotify = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Webpart page url"),
        WebDescription("Set webpart page url.")]
        public string WebpartPageUrl
        {
            get { return webpartpageurl; }
            set { webpartpageurl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Site root url"),
        WebDescription("Set site root url.")]
        public string SiteRootUrl
        {
            get { return siterooturl; }
            set { siterooturl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Path style library"),
        WebDescription("Set path for style library.")]
        public string StyleLibraryPath
        {
            get { return stylelibrarypath; }
            set { stylelibrarypath = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Catalog list Url"),
        WebDescription("Set catalog list url.")]
        public string CatalogListUrl
        {
            get { return cataloglisturl; }
            set { cataloglisturl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Costcenters List Url"),
        WebDescription("Set costcenters list url.")]
        public string CostcentersListUrl
        {
            get { return costcenterslisturl; }
            set { costcenterslisturl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Userprofile image url"),
        WebDescription("Set userprofile image url.")]
        public string UserProfileImageUrl
        {
            get { return userprofileimageurl; }
            set { userprofileimageurl = value; }
        }
        protected override void CreateChildControls()
        {
            Control control = Page.LoadControl(_ascxPath);
            if (control != null)
            {
                ((AntwerpITRequisitionWebpartUserControl)control).Webpart = this;
            }
            Controls.Add(control);
        }
    }
}
