﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition;
using Microsoft.SharePoint;
using System.Data;
using System.Drawing;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.AntwerpITRequisition.AntwerpITRequisitionWebpart
{
    public partial class AntwerpITRequisitionWebpartUserControl : ControlBase
    {
        public AntwerpITRequisitionWebpart Webpart { get; set; }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringMode]))
            {
                if (Request.QueryString[Constants.QueryStringMode].Equals(Convert.ToString(Mode.Overview)))
                    LoadOverviewControl();
                else if (Request.QueryString[Constants.QueryStringMode].Equals(Convert.ToString(Mode.Requisition)))
                    LoadRequisitionControl();
            }
            ((ControlBase)this).LoadControl(Webpart);
        }

        private void LoadOverviewControl()
        {
            OverviewControl newControl = (OverviewControl)LoadControl("../"+Constants.OverviewControl);
            ((ControlBase)newControl).LoadControl(Webpart);
            pnlRequisitionsOverview.Controls.Add(newControl);
        }

        private void LoadRequisitionControl()
        {
            CatalogControl newControl = (CatalogControl)LoadControl("../"+Constants.CatalogControl);
            ((ControlBase)newControl).LoadControl(Webpart);
            pnlCatalogOverview.Controls.Add(newControl);
        }

        private void DisableMenu()
        {
            pnlRequisitionMenu.Visible = false;
            pnlRequistionContent.Visible = true;
            pnlCatalog.Visible = false;
            pnlCostcenters.Visible = false;
        }

        private void EnableMenu()
        {
            pnlRequisitionMenu.Visible = true;
            pnlRequistionContent.Visible = false;
            pnlCatalog.Visible = (ITRequisitionUtilities.HasAdminPermission() || ITRequisitionUtilities.IsUserAuthorized(CatalogEditorsGroup));
            pnlCostcenters.Visible = (ITRequisitionUtilities.HasAdminPermission());
        }

        protected override void LoadITRequisition(Mode mode)
        {
            switch (mode)
            {
                case Mode.Overview:
                    LoadOverview();
                    DisableMenu();
                    break;
                case Mode.Requisition:
                    LoadRequisition();
                    DisableMenu();
                    break;
                case Mode.Empty:
                    EnableMenu();
                    break;
            }
        }

        private void LoadOverview()
        {
            pnlRequisitionsOverview.Visible = true;
            pnlCatalogOverview.Controls.Clear();
        }

        private void LoadRequisition()
        {
            pnlCatalogOverview.Visible = true;
            pnlRequisitionsOverview.Controls.Clear();
        }

        protected void btnRequisitions_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(Request.Path, Constants.Char_Question, Constants.QueryStringMode,Constants.Char_Equal, Convert.ToString(Mode.Overview)), false);
        }
        
        protected void btnNewRequisition_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(Request.Path,Constants.Char_Question, Constants.QueryStringMode,Constants.Char_Equal, Convert.ToString(Mode.Requisition)), false);
        }
        
        protected void btnCatalog_Click(object sender, EventArgs e)
        {
            Response.Redirect(Webpart.CatalogListUrl,false);
        }
        
        protected void btnCostcenters_Click(object sender, EventArgs e)
        {
            Response.Redirect(Webpart.CostcentersListUrl, false);
        }
    }
}