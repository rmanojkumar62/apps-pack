﻿function ASPGridView_FilterPreMenuOpen(gridViewClientId, templateClientId, menuClientId, dataFieldName, e) {
         var gridView = document.getElementById(gridViewClientId);
         var callbackEventReference = gridView.getAttribute("callbackEventReference");
         var callbackArgumentPrefix = gridView.getAttribute("callbackArgumentPrefix");
         var postbackEventReference = gridView.getAttribute("postbackEventReference");
         var filterFieldName = gridView.getAttribute("filterFieldName");
         var filterFieldValue = gridView.getAttribute("filterFieldValue");
      
         var filterCurrentlyOn = false;
        if ((filterFieldName != null) &&
            (filterFieldName.length > 0) &&
            (filterFieldName.match(dataFieldName) != null)) 
        {
            filterCurrentlyOn = true;
        }
     
        var menuTemplate = document.getElementById(templateClientId);
        var menuLink = document.getElementById(menuClientId);
        if ((menuLink.getAttribute("suppressBubbleIfPostback") != null) &&
            (e != null) && (e.srcElement != null) && 
            (e.srcElement.href != null) &&
            (e.srcElement.href.substr(0, MMU_postbackPrefix.length) == MMU_postbackPrefix)) 
        {
            event.cancelBubble = true;
            return;
        }
       SPGridView_FixupFilterValuesFromMenuTemplate(menuTemplate, filterCurrentlyOn);
        var menuItem = CAMOpt(menuTemplate, L_Loading_Text, "null");
        menuItem.setAttribute("isFilterItem", "true");
        menuItem.setAttribute("enabled", "false");
       SPGridView_CallbackContext = new Object();
        SPGridView_CallbackContext.gridViewClientId = gridViewClientId;
        SPGridView_CallbackContext.templateClientId = templateClientId;
        SPGridView_CallbackContext.menuClientId = menuClientId;
        SPGridView_CallbackContext.dataFieldName = dataFieldName;
        callbackEventReference = callbackEventReference.replace(/__CALLBACKARGUMENT__/g, dataFieldName);
        callbackEventReference = callbackEventReference.replace(/__CALLBACKCONTEXT__/g, gridViewClientId + ";" + templateClientId + ";" + menuClientId + ";" + dataFieldName);
        eval(callbackEventReference);
    }
     
    function Array_Contains(a, obj) {
        for(var i = 0; i < a.length; i++) {
            if(a[i] === obj) {
                return true;
            }
        }
        return false;
    }
     
    function ASPGridView_IsNullOrUndefined(val) {
        return (val == null || typeof(val) == 'undefined');
    }
     
    function ASPGridView_IsValueInFilter(fieldName, fieldVal, filterExpression) {
        if (ASPGridView_IsNullOrUndefined(fieldName) || ASPGridView_IsNullOrUndefined(fieldVal) ||
            ASPGridView_IsNullOrUndefined(filterExpression)) {
            return false;
        }
     
        fieldName = fieldName.toLowerCase();
        fieldVal = fieldVal.toLowerCase();
        filterExpression = filterExpression.toLowerCase();
     
        var case1 = '[' + fieldName + "] = '" + fieldVal + "'";
        var case2 = '[' + fieldName + "] like '%" + fieldVal + "%'";
        return (filterExpression.indexOf(case1) != -1 || filterExpression.indexOf(case2) != -1);
    }
     
    function ASPGridView_FilterCallbackHandler(result, context) {
        var values = context.split(';');
        if (values.length != 4) { alert("ERROR: ASPGridView_FilterCallbackHandler() - values.length !=4"); return; }
        var gridViewClientId = values[0];
        var templateClientId = values[1];
        var menuClientId = values[2];
        var dataFieldName = values[3];
        var gridView = document.getElementById(gridViewClientId);
        if (gridView == null) { alert("ERROR: ASPGridView_FilterCallbackHandler() - gridView==null"); return; }
        var menuTemplate = document.getElementById(templateClientId);
        if (menuTemplate == null) { alert("ERROR: ASPGridView_FilterCallbackHandler() - menuTemplate==null"); return; }
        var menu = document.getElementById(menuClientId);
        if (menu == null) { alert("ERROR: ASPGridView_FilterCallbackHandler() - menu==null"); return; }
        var postbackEventReference = gridView.getAttribute("postbackEventReference");
        if ((postbackEventReference == null) || (postbackEventReference.length <= 0)) { alert("ERROR: ASPGridView_FilterCallbackHandler() - postbackEventReference is null or empty"); return; }
        var filterFieldName = gridView.getAttribute("filterFieldName");
        var filterFieldValue = gridView.getAttribute("filterFieldValue");
        var filterExpression = gridView.getAttribute("filterExpression");
        
        var filterCurrentlyOn = false;
        if ((filterFieldName != null) &&
            (filterFieldName.length > 0) &&
            (filterFieldName.match(dataFieldName) != null)) {
            filterCurrentlyOn = true;
        }
     
        SPGridView_FixupFilterValuesFromMenuTemplate(menuTemplate, filterCurrentlyOn);
        values = result.split(';');
     
        // collect unique values
        var uniqueValues = new Array();
       for (var valueIndex = 0; valueIndex < values.length; valueIndex++) {
           var value = unescape(values[valueIndex]);
           if (typeof (value) != 'undefined' && value != null) {
               var multipleValues = value.split(','); // the same as used for joining TaxonomyFieldTypeMulti
               if (typeof (multipleValues) != 'undefined' && multipleValues != null && multipleValues.length > 0) {
                   for (var multiValueIndex = 0; multiValueIndex < multipleValues.length; multiValueIndex++) {
                       var v = multipleValues[multiValueIndex];
                       if (!Array_Contains(uniqueValues, v)) {
                           uniqueValues.push(v);
                       }
                   }
               }
           }
       }
    
       // create menu items only for unique values
       for (var valueIndex = 0; valueIndex < uniqueValues.length; valueIndex++) {
           var value = unescape(uniqueValues[valueIndex]);
           var script = postbackEventReference.replace(/__POSTBACKARGUMENT__/g, dataFieldName + ";" + value.replace(/\\/g, "\\\\").replace(/\'/g, "\\'").replace(/%/g, "%25").replace(/;/g, "%3b"));
           var newMenuItem = CAMOpt(menuTemplate, value, script);
           newMenuItem.setAttribute("isFilterItem", "true");
           if (value == filterFieldValue || ASPGridView_IsValueInFilter(dataFieldName, value, filterExpression)) {
               newMenuItem.setAttribute("checked", "true");
           }
       }
       HideMenu(menuTemplate);
       MMU_Open(menuTemplate, menu);
   }
