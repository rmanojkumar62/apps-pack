﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Monsanto.AntwerpITRequisition
{
    [Serializable()]
    public class ITRequisitionException : Exception
    {
        public ITRequisitionException() : base() { }
        public ITRequisitionException(string message) : base(message) { }
        public ITRequisitionException(string message, Exception e) : base(message, e) { }
        protected ITRequisitionException(SerializationInfo info, StreamingContext context) : base(info, context) { }
        public string Class { get; set; }
        public string Method { get; set; }
        public string CurrentUser { get; set; }
        public string FriendlyMessage { get; set; }
    }
}
