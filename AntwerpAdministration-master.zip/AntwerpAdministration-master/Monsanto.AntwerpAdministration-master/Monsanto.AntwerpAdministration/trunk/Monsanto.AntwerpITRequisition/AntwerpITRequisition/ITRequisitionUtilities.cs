﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using System.Web.UI;
using Monsanto.AntwerpITRequisition.CONTROLTEMPLATES.AntwerpITRequisition;
using System.Net;
using System.Reflection;

namespace Monsanto.AntwerpITRequisition
{
    public class ITRequisitionUtilities
    {
        public static SPListItem GetSPListItemByID(string id,string listname)
        {
            try
            {
                return SPContext.Current.Web.Lists.TryGetList(listname).GetItemById(Convert.ToInt32(id));
            }
            catch (Exception ex){ ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetListItemByID] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return null;
        }

        public static SPListItemCollection GetSPListItemCollectionByRequisitionNumber(string requisitionnumber, string itemID,string listname)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = "<Where><And><Eq><FieldRef Name='ID'/><Value Type='Counter'>" + itemID + "</Value></Eq><Eq><FieldRef Name='RequisitionNumber'/><Value Type='Text'>" + requisitionnumber + "</Value></Eq></And></Where>";
                    return web.Lists.TryGetList(listname).GetItems(query);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetCostcenters] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return null;
        }

        public static SPListItemCollection GetSPListItemCollectionByRequisitionNumber(string requisitionnumber, string listname)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = "<Where><Eq><FieldRef Name='RequisitionNumber'/><Value Type='Text'>" + requisitionnumber + "</Value></Eq></Where>";
                    return web.Lists.TryGetList(listname).GetItems(query);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetCostcenters] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return null;
        }

        public static DropDownList GetCostcenters(DropDownList dropCostcenters)
        {
            dropCostcenters.Items.Clear();
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = Constants.Config[Constants.Query_Costcenters];
                    SPListItemCollection listitems = web.Lists.TryGetList(Constants.Config[Constants.CostcentersList]).GetItems(query);
                    dropCostcenters.Items.Add("--- Select costcenter/project ---");
                    foreach (SPListItem item in listitems)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(item[Constants.Costcenter])))
                        {
                            string costcenter = Convert.ToString(item[Constants.Costcenter]).Substring(Convert.ToString(item[Constants.Costcenter]).IndexOf('#') + 1);
                            ListItem listitem = new ListItem(costcenter, costcenter);
                            if (!dropCostcenters.Items.Contains(listitem))
                                dropCostcenters.Items.Add(listitem);
                        }
                    }
                    dropCostcenters.Items.Add("Other");
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetCostcenters] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return dropCostcenters;
        }

        public static DropDownList GetGLAccounts(DropDownList dropGLAccount,string costcenter)
        {
            dropGLAccount.Items.Clear();
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = Constants.Config[Constants.Query_GLAccount].Replace("[COSTCENTER]",costcenter);
                    SPListItemCollection listitems = web.Lists.TryGetList(Constants.Config[Constants.CostcentersList]).GetItems(query);
                    dropGLAccount.Items.Add("--- Select GL account ---");
                    foreach (SPListItem item in listitems)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(item[Constants.GLAccount])))
                        {
                            string glaccount = Convert.ToString(item[Constants.GLAccount]);
                            ListItem listitem = new ListItem(glaccount, glaccount);
                            if (!dropGLAccount.Items.Contains(listitem))
                                dropGLAccount.Items.Add(listitem);
                        }
                    }
                    dropGLAccount.Items.Add("Other");
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetCostcenters] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return dropGLAccount;
        }

        public static SPUser GetSharePointUserField(string userstring, SPFieldUser field)
        {
            try
            {
                if (!string.IsNullOrEmpty(userstring))
                    return ((SPFieldUserValue)field.GetFieldValue(userstring)).User;
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetUserField] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return null;
        }

        public static string FormatErrorMessageForUI(string message)
        {
            return message.Replace('\'', ' ').Replace('(', '[').Replace(')', ']');
        }

        public static Control FindChildControl(Control rootControl, string controlID)
        {
            if (rootControl.ID == controlID) return rootControl;
            foreach (Control controlToSearch in rootControl.Controls)
            {
                Control controlToReturn = FindChildControl(controlToSearch, controlID);
                if (controlToReturn != null) return controlToReturn;
            }
            return null;
        }

        public static Control FindParentControl(Control control, Type typeparent)
        {
            Control ctrlParent = control;
            while ((ctrlParent = ctrlParent.Parent) != null)
            {
                if (ctrlParent.GetType().BaseType == typeparent)
                    return ctrlParent;
            }
            return null;
        }

        public static ITRequisitionForm GetITRequisitionControl(ControlBase control, ITRequisitionForm itrequisitionControl, ITRequisition itrequisition, int count, bool overviewrequisition, string CatalogListUrl)
        {
            try
            {
                itrequisitionControl.ID = String.Format(Constants.itctrl + Constants.Char_Underscore + "{0}", count);
                if (overviewrequisition)
                {
                    HideControls(itrequisitionControl, overviewrequisition);
                    itrequisitionControl.lblAantal2.Text = (itrequisition.Aantal > 0) ? itrequisition.Aantal.ToString() : string.Empty;
                    itrequisitionControl.lblBestemming2.Text = itrequisition.Bestemming;
                    itrequisitionControl.lblWorkorder2.Text = itrequisition.Workorder;
                    itrequisitionControl.lblCostcenter2.Text = itrequisition.Costcenter;
                    itrequisitionControl.lblGLAccount2.Text = itrequisition.GLAccount;
                    itrequisitionControl.sppCustomerIcon.Src = string.Concat(control.UserProfileImageUrl.Split(Constants.Char_Splitter)[0], itrequisition.CustomerLogin.Replace("_p", "").Replace(Constants.Char_Backslash, Constants.Char_Underscore), control.UserProfileImageUrl.Split(Constants.Char_Splitter)[1]);
                    itrequisitionControl.sppContactIcon.Src = string.Concat(control.UserProfileImageUrl.Split(Constants.Char_Splitter)[0], itrequisition.ITContactLogin.Replace("_p", "").Replace(Constants.Char_Backslash, Constants.Char_Underscore), control.UserProfileImageUrl.Split(Constants.Char_Splitter)[1]);
                    SPListItem item = ITRequisitionUtilities.GetSPListItemByID(itrequisition.CatalogItemID, Constants.Config[Constants.CatalogusList]);
                    Dictionary<string, string> attachmentlist = new Dictionary<string, string>();
                    foreach (string attachment in item.Attachments)
                        attachmentlist.Add(attachment, string.Concat(CatalogListUrl, "Attachments/", item.ID, "/", attachment));
                    itrequisition.Offertes = attachmentlist;
                }
                else
                {
                    Label legend = (Label)itrequisitionControl.FindControl("lblITRequisitionFormLegend");
                    legend.Text = "Item " + (count + 1);
                    itrequisitionControl.txtAantal.Text = (itrequisition.Aantal > 0) ? itrequisition.Aantal.ToString() : string.Empty;
                    itrequisitionControl.txtBestemming.Text = itrequisition.Bestemming;
                    itrequisitionControl.txtWorkorder.Text = itrequisition.Workorder;
                    ITRequisitionUtilities.GetCostcenters(itrequisitionControl.dropCostcenter);
                    bool isOtherCostcenter = true;
                    bool isOtherGLAccount = true;
                    foreach (ListItem item in itrequisitionControl.dropCostcenter.Items)
                    {
                        if (item.Value.Contains(itrequisition.Costcenter))
                        {
                            itrequisitionControl.dropCostcenter.SelectedValue = item.Value;
                            isOtherCostcenter = false;
                            break;
                        }
                    }
                    if (isOtherCostcenter)
                    {
                        itrequisitionControl.txtCostcenter.Text = itrequisition.Costcenter;
                        itrequisitionControl.txtCostcenter.Visible = true;
                        itrequisitionControl.dropCostcenter.SelectedValue = "Other";
                    }
                    ITRequisitionUtilities.GetGLAccounts(itrequisitionControl.dropGLAccount,itrequisition.Costcenter);
                    foreach (ListItem item in itrequisitionControl.dropGLAccount.Items)
                    {
                        if (item.Value.Contains(itrequisition.GLAccount))
                        {
                            itrequisitionControl.dropGLAccount.SelectedValue = item.Value;
                            isOtherGLAccount = false;
                            break;
                        }
                    }
                    if (isOtherGLAccount)
                    {
                        itrequisitionControl.txtGLAccount.Text = itrequisition.GLAccount;
                        itrequisitionControl.txtGLAccount.Visible = true;
                        itrequisitionControl.dropGLAccount.SelectedValue = "Other";
                    }
                }
                itrequisitionControl.sppCustomerText.Value = itrequisition.CustomerName;
                itrequisitionControl.sppCustomerID.Value = itrequisition.CustomerLogin;
                itrequisitionControl.sppContactText.Value = itrequisition.ITContactName;
                itrequisitionControl.sppContactID.Value = itrequisition.ITContactLogin;
                itrequisitionControl.lblItemDescription2.Text = itrequisition.ItemDescription;
                itrequisitionControl.lblVendorID2.Text = itrequisition.VendorID;
                itrequisitionControl.lblItemType2.Text = itrequisition.ItemType;
                itrequisitionControl.lblManufacturer2.Text = itrequisition.Manufacturer;
                itrequisitionControl.lblPrice2.Text = itrequisition.Price;
                itrequisitionControl.lblSupplier2.Text = itrequisition.PreferredSupplier;
                itrequisitionControl.lblLastSAP2.Text = itrequisition.LastSAPReqNr;
                GetOffertes(itrequisitionControl, itrequisition);
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetRequisitionControl] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return itrequisitionControl;
        }

        private static void GetOffertes(ITRequisitionForm itrequisitionControl, ITRequisition itrequisition)
        {
            Label lbl;
            if (itrequisition.Offertes != null)
            {
                if (itrequisition.Offertes.Count > 0)
                {
                    foreach (KeyValuePair<string, string> attachment in itrequisition.Offertes)
                    {
                        lbl = new Label();
                        lbl.Text = "<a href='" + attachment.Value + "' target='_blank'>" + attachment.Key + "</a>";
                        itrequisitionControl.pnlAttachments.Controls.Add(lbl);
                    }
                }
                else
                {
                    lbl = new Label();
                    lbl.Text = "No attachments";
                    itrequisitionControl.pnlAttachments.Controls.Add(lbl);
                }
            }
            else
            {
                lbl = new Label();
                lbl.Text = "No attachments";
                itrequisitionControl.pnlAttachments.Controls.Add(lbl);
            }
        }

        private static void HideControls(ITRequisitionForm itrequisitionControl, bool overviewrequisition)
        {
            if (overviewrequisition)
            {
                itrequisitionControl.pnlHeader.Visible = false;
                itrequisitionControl.txtAantal.Visible = false;
                itrequisitionControl.sppCustomerText.Attributes.Add("readonly", "readonly");
                itrequisitionControl.txtBestemming.Visible = false;
                itrequisitionControl.sppContactText.Attributes.Add("readonly", "readonly");
                itrequisitionControl.txtWorkorder.Visible = false;
                itrequisitionControl.dropCostcenter.Visible = false;
                itrequisitionControl.txtCostcenter.Visible = false;
                itrequisitionControl.dropGLAccount.Visible = false;
                itrequisitionControl.txtGLAccount.Visible = false;
                itrequisitionControl.lblAantal2.Visible = true;
                itrequisitionControl.lblBestemming2.Visible = true;
                itrequisitionControl.lblWorkorder2.Visible = true;
                itrequisitionControl.lblCostcenter2.Visible = true;
                itrequisitionControl.lblGLAccount2.Visible = true;
            }
        }

        public static List<ITRequisition> SaveForms(string requisitiondate,string requisitionnumber,Dictionary<int, ITRequisition> itreqs)
        {
            List<ITRequisition> itrequisitions = new List<ITRequisition>();
            try
            {
                foreach (ITRequisition itrequisition in itreqs.Values)
                {
                    SPListItem itrequisitionItem = null;
                    SPWeb web = SPContext.Current.Web;
                    SPList list = web.Lists[Constants.Config[Constants.ITRequisitionList]];
                    itrequisitionItem = list.Items.Add();
                    itrequisitionItem.Update();
                    itrequisition.TotalPrice = Convert.ToDouble(itrequisition.Price) * itrequisition.Aantal;
                    itrequisition.Created = DateTime.Now.AddHours(7);
                    itrequisition.Author = SPContext.Current.Web.CurrentUser.Name;
                    itrequisitionItem[Constants.Title] = "IT requisition " + requisitiondate;
                    itrequisitionItem[Constants.RequisitionNumber] = requisitionnumber;
                    itrequisitionItem[Constants.Status] = Convert.ToString(Status.Initiated);
                    itrequisitionItem[Constants.Aantal] = Convert.ToDouble(itrequisition.Aantal);
                    if (!string.IsNullOrEmpty(itrequisition.CustomerName))
                        SetUser(SPContext.Current.Web.EnsureUser(itrequisition.CustomerLogin).ID, itrequisition.CustomerName, Constants.Customer, itrequisitionItem);
                    itrequisitionItem[Constants.Bestemming] = itrequisition.Bestemming;
                    if (!string.IsNullOrEmpty(itrequisition.CustomerName))
                        SetUser(SPContext.Current.Web.EnsureUser(itrequisition.ITContactLogin).ID, itrequisition.ITContactName, Constants.ITContact, itrequisitionItem);
                    itrequisitionItem[Constants.Workorder] = itrequisition.Workorder;
                    itrequisitionItem.Update();
                    itrequisitionItem[Constants.ItemDescription] = itrequisition.ItemDescription;
                    itrequisitionItem[Constants.VendorItemID] = itrequisition.VendorID;
                    itrequisitionItem[Constants.ItemType] = itrequisition.ItemType;
                    itrequisitionItem[Constants.Manufacturer] = itrequisition.Manufacturer;
                    itrequisitionItem[Constants.Price] = Math.Round(Convert.ToDouble(itrequisition.Price), 2);
                    itrequisitionItem[Constants.PreferredSupplier] = itrequisition.PreferredSupplier;
                    itrequisitionItem[Constants.Costcenter] = itrequisition.Costcenter;
                    itrequisitionItem[Constants.GLAccount] = itrequisition.GLAccount;
                    itrequisitionItem[Constants.LastSAPReqNr] = itrequisition.LastSAPReqNr;
                    itrequisitionItem[Constants.TotalPrice] = Math.Round(itrequisition.TotalPrice, 2);
                    itrequisitionItem[Constants.CatalogItemID] = itrequisition.CatalogItemID;
                    itrequisitionItem.Update();
                    itrequisitions.Add(itrequisition);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_SaveForms] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return itrequisitions;
        }

        private static void SetUser(int ID, string username, string field, SPListItem requisition)
        {
            requisition[field] = new SPFieldUserValue(requisition.Web, ID, username);
        }

        public static bool HasAdminPermission()
        {
            try
            {
                return SPContext.Current.Web.UserIsWebAdmin || SPContext.Current.Web.UserIsSiteAdmin || SPContext.Current.Web.DoesUserHavePermissions(SPBasePermissions.FullMask);
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_CheckAdminPermission] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return false;
        }

        public static bool IsUserAuthorized(string groupName)
        {
            try
            {
                SPSite site = SPContext.Current.Site;
                using (SPWeb web = site.OpenWeb())
                {
                    SPUser currentUser = web.CurrentUser;
                    SPGroupCollection userGroups = currentUser.Groups;
                    foreach (SPGroup group in userGroups)
                    {
                        if (group.Name.Contains(groupName))
                            return true;
                    }
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_CheckUserAuthorized] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return false;
        }

        public static Mode GetMode(string mode)
        {
            if (mode.Equals(Convert.ToString(Mode.Overview)))
                return Mode.Overview;
            else if(mode.Equals(Convert.ToString(Mode.Requisition)))
                return Mode.Requisition;
            else
                return Mode.Empty;
        }

        public static Dictionary<string, string> GetConfigValues()
        {
            Dictionary<string, string> configValues = new Dictionary<string, string>();
            try
            {
                SPList config = SPContext.Current.Web.Lists.TryGetList(Constants.ConfigList);
                foreach (SPListItem item in config.GetItems())
                    configValues.Add(Convert.ToString(item[Constants.Key]), Convert.ToString(item[Constants.Value]));
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetConfigValues] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return configValues;
        }

        public static void ThrowError(Exception ex, string classstring, string methodstring, string friendlymessage)
        {
            ITRequisitionException iex = new ITRequisitionException(String.Format(Constants.ExceptionHeader + " – {0} * {1} – {2} - {3} - {4}", "Class: " + classstring + "  Method: " + methodstring + "  User: " + SPContext.Current.Web.CurrentUser.Name + "  Friendlymessage: " + friendlymessage, ex, ex.Message, ex.StackTrace, (ex.InnerException == null) ? string.Empty : ex.InnerException.Message), ex);
            iex.Class = classstring; iex.Method = methodstring; iex.CurrentUser = SPContext.Current.Web.CurrentUser.Name; iex.FriendlyMessage = friendlymessage;
            throw iex;
        }
    }
}