﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Data;

namespace Monsanto.TaxiAntwerp
{
    public class RequestToSharePoint
    {
        public DataTable Select()
        {
            SPQuery q = new SPQuery();
            q.Query = Constants.Config[Constants.TaxiRequest_Query];
            SPList list = SPContext.Current.Web.Lists[Constants.Config[Constants.TaxiRequestList]];
            SPListItemCollection items = list.GetItems(q);
            return items.GetDataTable();
        }
    }
}
