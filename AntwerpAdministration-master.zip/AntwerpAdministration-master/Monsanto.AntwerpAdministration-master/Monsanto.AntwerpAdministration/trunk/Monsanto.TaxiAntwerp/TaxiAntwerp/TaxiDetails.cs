﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.TaxiAntwerp
{
    [Serializable]
    public class TaxiDetails
    {
        public DateTime RequestDate { get; set; }
        public int CreatorID { get; set; }
        public string CreatorName { get; set; }
        public string CreatorLogin { get; set; }
        public int CommissionedByID { get; set; }
        public string CommissionedByName { get; set; }
        public string CommissionedByLogin { get; set; }
        public DateTime TravelDate { get; set; }
        public List<Traveller> Travellers { get; set; }
        public string TravellerOverview { get; set; }
        public bool MultipleTravellers { get; set; }
        public string DepartureHour { get; set; }
        public string DepartureCity { get; set; }
        public string DepartureAddress { get; set; }
        public string DestinationCity { get; set; }
        public string DestinationAddress { get; set; }
        public List<Stopover> Stopovers { get; set; }
        public string Department { get; set; }
        public string CostCenter { get; set; }
        public string Comment { get; set; }
        public string BonNumber { get; set; }
    }
    [Serializable]
    public class Traveller
    {
        public int ID { get; set; }
        public string Login { get; set; }
        public string Name { get; set; }
        public bool NotMonsanto { get; set; }
        public Traveller(string Name, bool NotMonsanto)
        {
            this.Name = Name;
            this.NotMonsanto = NotMonsanto;
        }
        public Traveller(string Name, string Login, bool NotMonsanto)
        {
            this.Name = Name;
            this.Login = Login;
            this.NotMonsanto = NotMonsanto;
        }
        public Traveller(int ID, string Name, bool NotMonsanto)
        {
            this.ID = ID;
            this.Name = Name;
            this.NotMonsanto = NotMonsanto;
        }
        public Traveller(int ID, string Name, string Login, bool NotMonsanto)
        {
            this.ID = ID;
            this.Name = Name;
            this.Login = Login;
            this.NotMonsanto = NotMonsanto;
        }
        public override string ToString()
        {
            if (string.IsNullOrEmpty(Login))
                return string.Concat(ID, Constants.Char_DelimiterValues, Name, Constants.Char_DelimiterValues, NotMonsanto, Constants.Char_DelimiterItems);
            else
                return string.Concat(ID, Constants.Char_DelimiterValues, Name, Constants.Char_DelimiterValues, Login, Constants.Char_DelimiterValues, NotMonsanto, Constants.Char_DelimiterItems);
        }
    }
    [Serializable]
    public class Stopover
    {
        public int ID { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public Stopover(string Address, string City)
        {
            this.Address = Address;
            this.City = City;
        }
        public Stopover(int ID, string Address, string City)
        {
            this.ID = ID;
            this.Address = Address;
            this.City = City;
        }
        public string ToStringDisplay()
        {
            return string.Concat(Address, Constants.ItemSplitter, City);
        }
        public override string ToString()
        {
            return string.Concat(Address, Constants.Char_DelimiterValues, City, Constants.Char_DelimiterItems);
        }
    }
}