﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.TaxiAntwerp
{
    public class Constants
    {
        #region GENERAL CONSTANTS
        public static readonly string ConfigList = "Configuration";
        public static readonly string Key = "Title";
        public static readonly string Value = "Value";
        public static readonly string OverviewControl = "OverviewControl.ascx";
        public static readonly string RequestControl = "RequestControl.ascx";
        public static readonly string TaxiFormControl = "TaxiForm.ascx";
        public static readonly string PreviewControl = "PreviewControl.ascx";
        public static readonly string Taxictrl = "taxictrl";
        public static readonly string TaxiFormTitle = "Travel";
        public static readonly string ItemSplitter = " - ";
        public static readonly string Char_DelimiterValues = "##";
        public static readonly string Char_DelimiterItems = "||";
        public static readonly char Char_Question = '?';
        public static readonly char Char_Equal = '=';
        public static readonly char Char_Underscore = '_';
        public static readonly char Char_Backslash = '\\';
        public static readonly char Char_Star = '*';
        public static readonly char Char_Circumflex = '^';
        public static readonly char Char_Comma = ',';
        public static readonly char Char_Ampersand = '&';
        public static readonly char Char_Equals = '=';
        public static readonly string String_Whitespace = " ";
        public static readonly string ResetIndex = "-1";
        public static readonly string BonNumber = "BonNumber";
        #endregion

        #region QUERYSTRING PARAMETERS
        public static readonly string QueryStringMode = "MODE";
        public static readonly string QuerystringRequestMode = "REQUESTMODE";
        public static readonly string QuerystringRequestID = "REQUESTID";
        public static readonly string QuerystringStopoverListID = "STOPOVERLISTID";
        public static readonly string QuerystringStopoverHiddenID = "STOPVERHIDDENID";
        public static readonly string QueryStringPrintIDs = "PRINTIDS";
        public static readonly string QueryStringIsFax = "ISFAXPDF";
        public static readonly string QueryStringReloadConfig = "RELOADCONFIG";
        #endregion

        #region VIEWSTATE PARAMETERS
        public static readonly string ViewStateTravellerList = "ViewStateTravellerList";
        public static readonly string ViewStateStopoverList = "ViewStateStopoverList";
        public static readonly string ViewStateTaxiDetailsList = "ViewStateTaxiDetailsList";
        public static readonly string ViewStateFormCount = "ViewStateFormCount";
        public static readonly string ViewStateRequestIDList = "ViewStateRequestIDList";
        #endregion

        #region CONFIGURATION LIST PARAMETERS
        #region TAXI REQUEST PARAMETERS
        public static readonly string ID = "ID";
        public static readonly string Title = "Title";
        public static readonly string Devision = "Devision";
        public static readonly string RequestDate = "RequestDate";
        public static readonly string Creator = "Creator";
        public static readonly string Commissioner = "Commissioner";
        public static readonly string TravelDate = "TravelDate";
        public static readonly string Traveller = "Traveller";
        public static readonly string TravellerNM = "TravellerNM";
        public static readonly string TravellerM = "TravellerM";
        public static readonly string TravellerList = "TravellerList";
        public static readonly string NotMonsantoEmployee = "NotMonsantoEmployee";
        public static readonly string MultipleTravellers = "MultipleTravellers";
        public static readonly string DepartureHour = "DepartureHour";
        public static readonly string DepartureCity = "DepartureCity";
        public static readonly string DepartureAddress = "DepartureAddress";
        public static readonly string DestinationCity = "DestinationCity";
        public static readonly string DestinationAddress = "DestinationAddress";
        public static readonly string Stopovers = "Stopovers";
        public static readonly string Department = "Department";
        public static readonly string Costcenter = "Costcenter";
        public static readonly string Comments = "Comments";
        public static readonly string CostCenter_SelectString = "CostCenter_SelectString";
        public static readonly string CostCenter_Query = "CostCenter_Query";
        public static readonly string TaxiRequest_Query = "TaxiRequest_Query";
        #endregion

        #region PDF PARAMETERS
        public static readonly string PDF_Title = "PDF_Title";
        public static readonly string PDF_HeaderName = "PDF_HeaderName";
        public static readonly string PDF_HeaderAddress = "PDF_HeaderAddress";
        public static readonly string PDF_HeaderLocation = "PDF_HeaderLocation";
        public static readonly string PDF_HeaderCountry = "PDF_HeaderCountry";
        public static readonly string PDF_HeaderTel = "PDF_HeaderTel";
        public static readonly string PDF_HeaderFax = "PDF_HeaderFax";
        public static readonly string PDF_HeaderTitle = "PDF_HeaderTitle";
        public static readonly string PDF_BodyDate = "PDF_BodyDate";
        public static readonly string PDF_BodyFrom = "PDF_BodyFrom";
        public static readonly string PDF_BodySubtitle = "PDF_BodySubtitle";
        public static readonly string PDF_BodyTravelDate = "PDF_BodyTravelDate";
        public static readonly string PDF_BodyTraveller = "PDF_BodyTraveller";
        public static readonly string PDF_BodyDepartureHour = "PDF_BodyDepartureHour";
        public static readonly string PDF_BodyDepartureAddress = "PDF_BodyDepartureAddress";
        public static readonly string PDF_BodyDepartureCity = "PDF_BodyDepartureCity";
        public static readonly string PDF_BodyDestinationAddress = "PDF_BodyDestinationAddress";
        public static readonly string PDF_BodyDestinationCity = "PDF_BodyDestinationCity";
        public static readonly string PDF_BodyStopovers = "PDF_BodyStopovers";
        public static readonly string PDF_BodyDepartment = "PDF_BodyDepartment";
        public static readonly string PDF_BodyCostCenter = "PDF_BodyCostCenter";
        public static readonly string PDF_BodyComments = "PDF_BodyComments";
        public static readonly string PDF_Footer1 = "PDF_Footer1";
        public static readonly string PDF_Footer2 = "PDF_Footer2";
        public static readonly string PDF_Footer3 = "PDF_Footer3";
        public static readonly string PDF_Footer4 = "PDF_Footer4";
        public static readonly string PDF_FaxTitle = "PDF_FaxTitle";
        public static readonly string PDF_BonTitle = "PDF_BonTitle";
        public static readonly string PDF_BodyTravellers = "PDF_BodyTravellers";
        public static readonly string PDF_Small_Vertrek = "PDF_Small_Vertrek";
        public static readonly string PDF_Small_Aankomst = "PDF_Small_Aankomst";
        public static readonly string PDF_Small_Stopover = "PDF_Small_Stopover";
        public static readonly string PDF_Small_Stopovers = "PDF_Small_Stopovers";
        public static readonly string PDF_Small_Info = "PDF_Small_Info";
        #endregion

        #region EXCEPTION - ERROR MESSAGES
        public static readonly string ExceptionHeader = "Taxi antwerp Exception";
        public static readonly string Error_GetItemByID = "Error_GetItemByID";
        public static readonly string Error_GetConfigValues = "Error_GetConfigValues";
        public static readonly string Error_GetMaxBonNr = "Error_GetMaxBonNr";
        public static readonly string Error_GetCostcenters = "Error_GetCostcenters";
        public static readonly string Error_GetCostcenterLookup = "Error_GetCostcenterLookup";
        public static readonly string Error_EnsureUser = "Error_EnsureUser";
        public static readonly string Error_EnsureUsers = "Error_EnsureUsers";
        public static readonly string Error_GetUserField = "Error_GetUserField";
        public static readonly string Error_GetMultiUserField = "Error_GetMultiUserField";
        public static readonly string Error_SetControlsReadonly = "Error_SetControlsReadonly";
        public static readonly string Error_HasAdminPermission = "Error_HasAdminPermission";
        public static readonly string Error_CreatePDF = "Error_CreatePDF";
        public static readonly string Error_CreatePages = "Error_CreatePages";
        public static readonly string Error_DeleteItem = "Error deleting request";
        #endregion

        #region OTHER PARAMETERS
        public static readonly string DateFormat = "DateFormat";
        public static readonly string DateFormatLong = "DateFormatLong";
        public static readonly string TaxiRequestList = "TaxiRequestList";
        public static readonly string CostCenters = "CostCenters";
        public static readonly string UserProfileImageURLPrefix = "UserProfileImageURLPrefix";
        public static readonly string UserProfileImageURLPostfix = "UserProfileImageURLPostfix";
        public static readonly string CloseNew = "CloseNew";
        public static readonly string CloseDisplay = "CloseDisplay";
        public static readonly string CloseEdit = "CloseEdit";
        public static readonly string NoCostcenter = "NoCostcenter";
        public static readonly string Query_CostcenterLookup = "Query_CostcenterLookup";
        public static readonly string Query_MaxBonNr = "Query_MaxBonNr";
        public static readonly string EmailTemplate = "EmailTemplate";
        #endregion
        #endregion

        public static Dictionary<string, string> _Config;
        public static Dictionary<string, string> Config
        {
            get
            {
                if (_Config == null)
                    _Config = TaxiAntwerpUtilities.GetConfigValues();
                return _Config;
            }
        }
        private Constants() { }
    }
}
