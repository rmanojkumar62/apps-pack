﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.TaxiAntwerp
{
    public enum RequestMode
    {
        Empty,
        NEW,
        DISP,
        EDIT,
        OVERVIEW
    }
    public enum ErrorType
    {
        FIELDS,
        RUNTIME
    }
}
