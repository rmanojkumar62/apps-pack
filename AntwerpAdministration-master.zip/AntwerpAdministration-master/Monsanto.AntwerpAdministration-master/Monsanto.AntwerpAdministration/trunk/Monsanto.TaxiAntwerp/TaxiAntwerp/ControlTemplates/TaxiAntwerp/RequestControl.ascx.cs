﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Drawing;
using Microsoft.SharePoint;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;
using System.Reflection;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public partial class RequestControl : ControlBase
    {
        private List<TaxiDetails> taxidetailslist;

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                for (int i = 0; i < GetViewStateFormCount(); i++)
                    AddNewFormToPanel(i, true);
                sppCreatorText.Value = TaxiAntwerpUtilities.EnsureUser(sppCreatorID.Value).Name;
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "setCreator();", true);
            }
        }

        #region LOAD REQUEST
        public override void LoadTaxiRequest(RequestMode requestmode)
        {
            try
            {
                switch (requestmode)
                {
                    case RequestMode.NEW:
                        SetViewStateFormCount(0);
                        AddNewFormToPanel(GetViewStateFormCount(), false);
                        SetViewStateFormCount(GetViewStateFormCount()+1);
                        LoadCurrentCreator();
                        btnAdd.Visible = true;
                        btnSave.Visible = true;
                        btnClose.OnClientClick = "if (!confirm('" + Constants.Config[Constants.CloseNew] + "')) return false;";
                        break;
                    case RequestMode.DISP:
                        LoadRequest(requestmode);
                        btnEdit.Visible = true;
                        btnPDFFax.Visible = true;
                        btnPDFBon.Visible = true;
                        btnClose.OnClientClick = "if (!confirm('" + Constants.Config[Constants.CloseDisplay] + "')) return false;";
                        SetTaxiFormReadOnly();
                        break;
                    case RequestMode.EDIT:
                        LoadRequest(requestmode);
                        LoadCurrentCreator();
                        btnSave.Visible = true;
                        btnClose.OnClientClick = "if (!confirm('" + Constants.Config[Constants.CloseEdit] + "')) return false;";
                        break;
                }
                CheckDisableDeleteButton();
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        private void LoadRequest(RequestMode requestmode)
        {
            string[] IDs = Request.QueryString[Constants.QuerystringRequestID].Split(Constants.Char_Star);
            int taxiformcount = GetViewStateFormCount();
            foreach (string ID in IDs)
            {
                AddNewFormToPanel(taxiformcount, false);
                SPListItem request = SPContext.Current.Web.Lists[Constants.Config[Constants.TaxiRequestList]].GetItemById(Convert.ToInt32(ID));
                TaxiForm taxiform = (TaxiForm)pnlForms.Controls[pnlForms.Controls.Count - 1];
                taxiform = TaxiAntwerpUtilities.SetTaxiForm(taxiform, taxiformcount);
                if (requestmode.Equals(RequestMode.DISP))
                {
                    RequestDate.SelectedDate = Convert.ToDateTime(request[Constants.Config[Constants.RequestDate]]);
                    string creator = TaxiAntwerpUtilities.GetSharePointUserField(Convert.ToString(request[Constants.Config[Constants.Creator]]), (SPFieldUser)request.Fields.GetField(Constants.Config[Constants.Creator]), false);
                    if (!string.IsNullOrEmpty(creator))
                    {
                        SPUser user = SPContext.Current.Web.EnsureUser(creator);
                        UpdateCreator(user);
                    }
                    taxiform.TravelDate.Enabled = false;
                }
                LoadCommissioned(taxiform,request);
                taxiform.TravelDate.SelectedDate = Convert.ToDateTime(request[Constants.Config[Constants.TravelDate]]);
                taxiform.SetTravellerList(TaxiAntwerpUtilities.GetTravellersFromListItem(request));
                taxiform.txtDepartureHour.Text = Convert.ToString(request[Constants.Config[Constants.DepartureHour]]);
                taxiform.txtDepartureCity.Text = Convert.ToString(request[Constants.Config[Constants.DepartureCity]]);
                taxiform.txtDepartureAddress.Text = Convert.ToString(request[Constants.Config[Constants.DepartureAddress]]);
                taxiform.txtDestinationCity.Text = Convert.ToString(request[Constants.Config[Constants.DestinationCity]]);
                taxiform.txtDestinationAddress.Text = Convert.ToString(request[Constants.Config[Constants.DestinationAddress]]);
                LoadStopovers(taxiform, request);
                taxiform.txtDepartment.Text = Convert.ToString(request[Constants.Config[Constants.Department]]);
                taxiform.dropCostCenter.SelectedValue = new SPFieldLookupValue(Convert.ToString(request[Constants.Config[Constants.Costcenter]])).LookupValue;
                taxiform.txtComments.Text = Convert.ToString(request[Constants.Config[Constants.Comments]]);
                pnlForms.Controls.Add(taxiform);
                List<TaxiDetails> taxidetailsList = GetTaxiDetailsList();
                taxidetailsList.ElementAt(taxiformcount).Travellers=taxiform.GetTravellerList();
                taxidetailsList.ElementAt(taxiformcount).Stopovers=taxiform.GetStopoverList();
                SetTaxiDetailsList(taxidetailsList);
                SetViewStateFormCount(++taxiformcount);
            }
            if(requestmode.Equals(RequestMode.DISP))
                ((Button)TaxiAntwerpUtilities.FindChildControl(pnlForms, "btnCopy")).Visible = false;
        }

        private void LoadCurrentCreator()
        {
            RequestDate.SelectedDate = DateTime.Now;
            SPUser user = SPContext.Current.Web.CurrentUser;
            UpdateCreator(SPContext.Current.Web.CurrentUser);
        }

        private void LoadCommissioned(TaxiForm taxiform, SPListItem request)
        {
            string userlogin = TaxiAntwerpUtilities.GetSharePointUserField(Convert.ToString(request[Constants.Config[Constants.Commissioner]]), (SPFieldUser)request.Fields.GetField(Constants.Config[Constants.Commissioner]), false);
            if (!string.IsNullOrEmpty(userlogin))
            {
                SPUser user = SPContext.Current.Web.EnsureUser(userlogin);
                taxiform.HIDDENCommisioned.Value = user.LoginName;
                taxiform.UpdateCommisioned(taxiform, user);
            }
        }
        
        private void LoadStopovers(TaxiForm taxiform, SPListItem request)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(request[Constants.Config[Constants.Stopovers]])))
            {
                string[] stopovers = Convert.ToString(request[Constants.Config[Constants.Stopovers]]).Split(new string[]{Constants.Char_DelimiterItems},StringSplitOptions.RemoveEmptyEntries);
                List<Stopover> stopoverList = new List<Stopover>();
                for (int i = 0; i < stopovers.Length; i++)
                    stopoverList.Add(new Stopover(i, stopovers[i].Split(new string[] { Constants.Char_DelimiterValues }, StringSplitOptions.RemoveEmptyEntries)[0], stopovers[i].Split(new string[] { Constants.Char_DelimiterValues }, StringSplitOptions.RemoveEmptyEntries)[1]));
                taxiform.SetStopoverList(stopoverList);
            }
        }
        #endregion

        #region GET FORM DATA
        private List<TaxiDetails> GetFormData(ControlCollection ctrls)
        {
            List<TaxiDetails> taxidetailslist = new List<TaxiDetails>();
            try
            {
                foreach (Control ctrl in ctrls)
                {
                    if (ctrl.Controls.Count > 0 && ctrl.ID.Contains(string.Concat(Constants.Taxictrl, Constants.Char_Underscore)))
                    {
                        TaxiForm form = (TaxiForm)ctrl;
                        TaxiDetails taxidetails = new TaxiDetails();
                        taxidetails.RequestDate = RequestDate.SelectedDate;
                        if (!string.IsNullOrEmpty(sppCreatorID.Value))
                        {
                            SPUser creator = TaxiAntwerpUtilities.EnsureUser(Convert.ToString(sppCreatorID.Value));
                            taxidetails.CreatorID = creator.ID;
                            taxidetails.CreatorName = creator.Name;
                            taxidetails.CreatorLogin = creator.LoginName;
                        }
                        taxidetails = GetCommissioned(form, taxidetails);
                        taxidetails.TravelDate = form.TravelDate.SelectedDate;
                        List<Traveller> travellers = form.GetTravellerList();
                        taxidetails.Travellers = travellers;
                        taxidetails.TravellerOverview = travellers[0].Name;
                        taxidetails.MultipleTravellers=(travellers.Count > 1) ? true : false;
                        taxidetails.DepartureHour = form.txtDepartureHour.Text;
                        taxidetails.DepartureCity = form.txtDepartureCity.Text;
                        taxidetails.DepartureAddress = form.txtDepartureAddress.Text;
                        taxidetails.DestinationCity = form.txtDestinationCity.Text;
                        taxidetails.DestinationAddress = form.txtDestinationAddress.Text;
                        taxidetails.Stopovers = form.GetStopoverList();
                        taxidetails.Department = form.txtDepartment.Text;
                        taxidetails.CostCenter = (form.dropCostCenter.SelectedIndex < 1) ? Constants.Config[Constants.NoCostcenter] : form.dropCostCenter.SelectedValue;
                        taxidetails.Comment = form.txtComments.Text;
                        taxidetailslist.Add(taxidetails);
                    }
                }
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
            return taxidetailslist;
        }

        private TaxiDetails GetCommissioned(TaxiForm form, TaxiDetails taxidetails)
        {
            if (!string.IsNullOrEmpty(form.HIDDENCommisioned.Value))
            {
                SPUser comm = TaxiAntwerpUtilities.EnsureUser(Convert.ToString(form.HIDDENCommisioned.Value));
                taxidetails.CommissionedByID = comm.ID;
                taxidetails.CommissionedByName = comm.Name;
                taxidetails.CommissionedByLogin = comm.LoginName;
            }
            return taxidetails;
        }

        #endregion

        #region SAVE REQUEST
        private void SaveNewTaxiRequest(List<TaxiDetails> taxidetailslist)
        {
            string IDs = SaveForms(taxidetailslist);
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "openPDFtab('" + IDs + "',false);", true);
        }

        private void SaveCopyExistingTaxiRequest(List<TaxiDetails> taxidetailslist)
        {
            string IDs = SaveForms(taxidetailslist);
            //IDs = string.Concat(Request.QueryString[Constants.QuerystringRequestID], Constants.Char_Star,IDs);
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "openPDFtab('" + IDs + "',false);", true);
        }
        
        private string SaveForms(List<TaxiDetails> taxidetailslist)
        {
            string IDs = string.Empty;
            try
            {
                foreach (TaxiDetails taxidetails in taxidetailslist)
                {
                    SPList list = SPContext.Current.Web.Lists[Constants.Config[Constants.TaxiRequestList]];
                    SPListItem request = list.Items.Add();
                    request.Update();
                    IDs += string.Concat(request.ID, Constants.Char_Star);
                    UpdatTaxiRequest(request,taxidetails);
                }
            }
            catch (TaxiAntwerpException tex) { ThrowError(ErrorType.RUNTIME, tex); }
            return IDs.TrimEnd(new char[]{Constants.Char_Star});
        }

        private void UpdatTaxiRequest(SPListItem request, TaxiDetails taxidetails)
        {
            request[Constants.BonNumber] = GetBonNumber();
            request[Constants.Config[Constants.Title]] = Convert.ToString(request.ID);
            request[Constants.Config[Constants.RequestDate]] = taxidetails.RequestDate;
            if (!string.IsNullOrEmpty(taxidetails.CreatorName))
                TaxiAntwerpUtilities.SetUser(taxidetails.CreatorID, taxidetails.CreatorName, Constants.Creator, request);
            if (!string.IsNullOrEmpty(taxidetails.CommissionedByName))
                TaxiAntwerpUtilities.SetUser(taxidetails.CommissionedByID, taxidetails.CommissionedByName, Constants.Config[Constants.Commissioner], request);
            request[Constants.Config[Constants.TravelDate]] = taxidetails.TravelDate;
            request[Constants.Config[Constants.Traveller]] = taxidetails.TravellerOverview;
            string travellerlist = string.Empty;
            foreach (Traveller traveller in taxidetails.Travellers)
                travellerlist += traveller.ToString();
            request[Constants.TravellerList] = travellerlist;
            request[Constants.Config[Constants.MultipleTravellers]] = taxidetails.MultipleTravellers;
            request[Constants.Config[Constants.DepartureHour]] = taxidetails.DepartureHour;
            request[Constants.Config[Constants.DepartureCity]] = taxidetails.DepartureCity;
            request[Constants.Config[Constants.DepartureAddress]] = taxidetails.DepartureAddress;
            request[Constants.Config[Constants.DestinationCity]] = taxidetails.DestinationCity;
            request[Constants.Config[Constants.DestinationAddress]] = taxidetails.DestinationAddress;
            string stopovers = string.Empty;
            foreach (Stopover stopover in taxidetails.Stopovers)
                stopovers += stopover.ToString();
            request[Constants.Config[Constants.Stopovers]] = stopovers.Trim(Constants.Char_DelimiterItems.ToCharArray());
            request[Constants.Config[Constants.Department]] = taxidetails.Department;
            request[Constants.Config[Constants.Costcenter]] = TaxiAntwerpUtilities.GetCostCenterLookup(Constants.Config[Constants.CostCenters], request.Fields.GetField(Constants.Config[Constants.Costcenter]) as SPFieldLookup, taxidetails.CostCenter);
            request[Constants.Config[Constants.Comments]] = taxidetails.Comment;
            request.Update();
        }
        #endregion

        #region BUTTON EVENTS
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            ControlCollection ctrls = this.FindControl("pnlForms").Controls;
            GetNewFormData(ctrls);
            AddNewFormToPanel(GetViewStateFormCount(), false);
            SetViewStateFormCount(GetViewStateFormCount()+1);
            CheckDisableDeleteButton();
        }

        private void GetNewFormData(ControlCollection ctrls)
        {
            try
            {
                foreach (Control ctrl in ctrls)
                {
                    if (ctrl.Controls.Count > 0 && ctrl.ID.Contains(string.Concat(Constants.Taxictrl, Constants.Char_Underscore)))
                    {
                        TaxiForm form = (TaxiForm)ctrl;
                        TaxiDetails taxidetails = new TaxiDetails();
                        GetCommissioned(form, taxidetails);
                    }
                }
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl.Replace(Convert.ToString(RequestMode.DISP), Convert.ToString(RequestMode.EDIT)), false);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            ControlCollection ctrls = this.FindControl("pnlForms").Controls;
            ResetRequiredFields();
            if (CheckRequiredFields())
            {
                ThrowError(ErrorType.FIELDS, "One or more fields are not filled in correctly.");
                return;
            }
            taxidetailslist = GetFormData(ctrls);
            if (taxidetailslist.Count > 0)
                FillPreview(taxidetailslist);
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            if (Request.QueryString[Constants.QuerystringRequestMode].Equals(Convert.ToString(RequestMode.EDIT)))
                Response.Redirect(Request.RawUrl.Replace(Convert.ToString(RequestMode.EDIT), Convert.ToString(RequestMode.DISP)), false);
            else
                Response.Redirect(Request.Path, false);
        }

        protected void btnPDFFax_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "openPDFtab('" + Request.QueryString[Constants.QuerystringRequestID] + "',true);", true);
        }

        protected void btnPDFBon_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "openPDFtab('" + Request.QueryString[Constants.QuerystringRequestID] + "',false);", true);
        }

        protected void btnSavePreview_Click(object sender, EventArgs e)
        {
            ControlCollection ctrls = this.FindControl("pnlForms").Controls;
            taxidetailslist = GetFormData(ctrls);
            if (taxidetailslist.Count > 0)
            {
                if (Request.QueryString[Constants.QuerystringRequestMode].Equals(Convert.ToString(RequestMode.NEW)))
                    SaveNewTaxiRequest(taxidetailslist);
                else
                {
                    if (taxidetailslist.Count > 0)
                    {
                        SaveCopyExistingTaxiRequest(taxidetailslist);
                    }
                }
                if(this.AutomaticFax)
                    CreateFax(taxidetailslist);
                CreateMail(taxidetailslist);
                ShowConfirmation();
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "confirmation();", true);
            }
        }
        
        protected void btnClosePreview_Click(object sender, EventArgs e)
        {
            ClosePreview();
        }
        
        protected void btnCloseConfirmation_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(Request.Path,Constants.Char_Question,Constants.QuerystringRequestMode,Constants.Char_Equal,"OVERVIEW"), false);
        }
        #endregion

        private void ClosePreview()
        {
            pnlPreviewWrapper.Visible = false;
            pnlTaxiControl.Visible = true;
            pnlConfirmation.Visible = false;
        }

        private void ShowConfirmation()
        {
            pnlPreviewWrapper.Visible = false;
            pnlTaxiControl.Visible = false;
            pnlConfirmation.Visible = true;
        }
        
        private void AddNewFormToPanel(int taxiformcount, bool isNew)
        {
            try
            {
                TaxiForm taxiform = (TaxiForm)LoadControl(Constants.TaxiFormControl);
                taxiform = TaxiAntwerpUtilities.SetTaxiForm(taxiform, taxiformcount);
                if (isNew)
                {
                    taxiform.SetTravellerList(GetTaxiDetailsList().ElementAt(taxiformcount).Travellers);
                    taxiform.SetStopoverList(GetTaxiDetailsList().ElementAt(taxiformcount).Stopovers);
                }
                pnlForms.Controls.Add(taxiform);
                if (!isNew)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), string.Concat("setSPPID(", taxiformcount, ");"), true);
                    List<TaxiDetails> taxidetailsList=null;
                    if(GetTaxiDetailsList()==null)
                        taxidetailsList = new List<TaxiDetails>();
                    else
                        taxidetailsList = GetTaxiDetailsList();
                    TaxiDetails taxidetails = new TaxiDetails();
                    taxidetails.Travellers = new List<Traveller>();
                    taxidetails.Stopovers = new List<Stopover>();
                    taxidetailsList.Add(taxidetails);
                    SetTaxiDetailsList(taxidetailsList);
                }
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        public void CheckDisableDeleteButton()
        {
            try
            {
                TaxiForm frm = (TaxiForm)TaxiAntwerpUtilities.FindChildControl(pnlForms, string.Concat(Constants.Taxictrl, Constants.Char_Underscore, 0));
                if (GetViewStateFormCount() == 1)
                {
                    frm.btnDelete.Enabled = false;
                    frm.btnDelete.CssClass= "frmActions btnDeleteGray";
                }
                else
                {
                    if (!Request.QueryString[Constants.QuerystringRequestMode].Equals(RequestMode.EDIT.ToString()))
                    {
                        frm.btnDelete.Enabled = true;
                        frm.btnDelete.CssClass = "frmActions btnDelete";
                    }
                }
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void ResetRequiredFields()
        {
            try
            {
                lblRequestDate.ForeColor = Color.Empty;
                lblCreator.ForeColor = Color.Empty;
                foreach (Control ctrl in pnlForms.Controls)
                {
                    if (ctrl.Controls.Count > 0 && ctrl.ID.IndexOf(Constants.Taxictrl) != -1)
                    {
                        TaxiForm frm = (TaxiForm)ctrl;
                        frm.lblTravelDate.ForeColor = Color.Empty;
                        frm.lblTraveller.ForeColor = Color.Empty;
                        frm.lblDepartureHour.ForeColor = Color.Empty;
                        frm.lblDepartureCity.ForeColor = Color.Empty;
                        frm.lblDepartureAddress.ForeColor = Color.Empty;
                        frm.lblDestinationCity.ForeColor = Color.Empty;
                        frm.lblDestinationAddress.ForeColor = Color.Empty;
                        frm.lblDepartment.ForeColor = Color.Empty;
                        frm.lblCostCenter.ForeColor = Color.Empty;
                    }
                }
            }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected bool CheckRequiredFields()
        {
            bool isNOK = false;
            if (RequestDate.IsDateEmpty)
            {
                lblRequestDate.ForeColor = Color.Red;
                isNOK = true;
            }
            if (string.IsNullOrEmpty(sppCreatorID.Value))
            {
                lblCreator.ForeColor = Color.Red;
                isNOK = true;
            }
            foreach (Control ctrl in pnlForms.Controls)
            {
                if (ctrl.Controls.Count > 0 && ctrl.ID.IndexOf(Constants.Taxictrl) != -1)
                {
                    TaxiForm frm = (TaxiForm)ctrl;
                    TaxiDetails taxidetails = new TaxiDetails();
                    GetCommissioned(frm, taxidetails);
                    isNOK=CheckRequiredFieldsForm(frm, isNOK);
                }
            }
            return isNOK;
        }

        private bool CheckRequiredFieldsForm(TaxiForm frm, bool isNOK)
        {
            if (frm.TravelDate.IsDateEmpty)
            {
                frm.lblTravelDate.ForeColor = Color.Red;
                isNOK = true;
            }
            isNOK=CheckRequiredTraveller(frm, isNOK);
            if (string.IsNullOrEmpty(frm.txtDepartureHour.Text))
            {
                frm.lblDepartureHour.ForeColor = Color.Red;
                isNOK = true;
            }
            if (string.IsNullOrEmpty(frm.txtDepartureCity.Text))
            {
                frm.lblDepartureCity.ForeColor = Color.Red;
                isNOK = true;
            }
            if (string.IsNullOrEmpty(frm.txtDepartureAddress.Text))
            {
                frm.lblDepartureAddress.ForeColor = Color.Red;
                isNOK = true;
            }
            if (string.IsNullOrEmpty(frm.txtDestinationCity.Text))
            {
                frm.lblDestinationCity.ForeColor = Color.Red;
                isNOK = true;
            }
            if (string.IsNullOrEmpty(frm.txtDestinationAddress.Text))
            {
                frm.lblDestinationAddress.ForeColor = Color.Red;
                isNOK = true;
            }
            if (string.IsNullOrEmpty(frm.txtDepartment.Text))
            {
                frm.lblDepartment.ForeColor = Color.Red;
                isNOK = true;
            }
            if (frm.dropCostCenter.SelectedIndex < 1)
            {
                frm.lblCostCenter.ForeColor = Color.Red;
                isNOK = true;
            }
            return isNOK;
        }

        private bool CheckRequiredTraveller(TaxiForm frm, bool isNOK)
        {
            if (frm.GetTravellerList().Count<=0)
            {
                frm.lblTraveller.ForeColor = Color.Red;
                isNOK = true;
            }
            return isNOK;
        }

        private void SetTaxiFormReadOnly()
        {
            try
            {
                sppCreatorText.Disabled = true;
                ((Button)TaxiAntwerpUtilities.FindChildControl(pnlForms, "btnSwitch")).Enabled = false;
                ((HtmlInputText)TaxiAntwerpUtilities.FindChildControl(pnlForms, "sppCommisionedText")).Disabled = true;
                ((TextBox)TaxiAntwerpUtilities.FindChildControl(pnlForms, "sppTravellerText")).Enabled = false;
                TaxiAntwerpUtilities.SetControlsReadOnly(this);
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        private int GetBonNumber()
        {
            int wpbonnr = this.LastBonNr;
            int bonnumber = 0;
            try
            {
                bonnumber = TaxiAntwerpUtilities.GetMaxBonNumber();
                if (bonnumber < wpbonnr)
                    bonnumber= wpbonnr;
                else if(bonnumber>=wpbonnr)
                    bonnumber= bonnumber+1;
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
            return bonnumber;
        }

        private void FillPreview(List<TaxiDetails> taxidetailslist)
        {
            try
            {
                int counter=0;
                foreach (TaxiDetails taxidetails in taxidetailslist)
                {
                    PreviewControl preview = (PreviewControl)LoadControl(Constants.PreviewControl);
                    preview.ID = String.Format("previewctrl_{0}", counter);
                    preview.LoadData(taxidetails);
                    pnlPreviews.Controls.Add(preview);
                    counter++;
                }
                pnlTaxiControl.Visible = false;
                pnlPreviewWrapper.Visible = true;
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
        }

        public void UpdateCreator(SPUser user)
        {
            sppCreatorID.Value = user.LoginName;
            sppCreatorText.Value = user.Name;
            sppCreatorIcon.Src = "http://mysites.monsanto.com/User%20Photos/Profile%20Pictures/" + sppCreatorID.Value.Replace('\\', '_') + "_LThumb.JPG";
            sppCreatorIcon.Attributes["onerror"] = "this.src='/enterprise/antwerpadministration/_layouts/images/blogabout96.PNG';";
        }
    }
}