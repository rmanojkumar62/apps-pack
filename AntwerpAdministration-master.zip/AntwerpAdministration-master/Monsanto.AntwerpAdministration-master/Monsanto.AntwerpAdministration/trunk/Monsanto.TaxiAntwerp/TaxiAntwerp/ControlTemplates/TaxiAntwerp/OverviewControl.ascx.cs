﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Linq;
using Microsoft.SharePoint;
using System.Collections;
using Microsoft.SharePoint.Utilities;
using System.Reflection;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public partial class OverviewControl : ControlBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected override void CreateChildControls()
        {
            BindPaging();
            ODSRequests.TypeName = typeof(RequestToSharePoint).AssemblyQualifiedName;
            ODSRequests.ObjectCreating += new ObjectDataSourceObjectEventHandler(ODSRequisition_ObjectCreating);
        }

        private Dictionary<string, string> GetParameters(ObjectDataSourceMethodEventArgs e)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            foreach (DictionaryEntry entry in e.InputParameters)
                data.Add(entry.Key.ToString(), (entry.Value == null) ? null : entry.Value.ToString());
            return data;
        }

        private void BindPaging()
        {
            gridRequests.PagerTemplate = null;
            gridRequests.PageIndexChanging += new GridViewPageEventHandler(gridRequests_PageIndexChanging);
        }

        private void ODSRequisition_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
        {
            e.ObjectInstance = new RequestToSharePoint();
        }

        protected void dropRequestCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            gridRequests.PageSize = Convert.ToInt32(dropRequestCount.SelectedValue);
        }

        protected void gridRequests_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridRequests.PageIndex = e.NewPageIndex;
        }

        protected void btnNew_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(Request.RawUrl.Replace(Request.QueryString[Constants.QuerystringRequestMode],Convert.ToString(RequestMode.NEW)), Constants.Char_Ampersand, Constants.QuerystringRequestID, Constants.Char_Equals, Constants.ResetIndex), false);
        }

        protected void btnPDFFax_Click(object sender, EventArgs e) 
        {
            try
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "openPDFtab('" + GetSelectedItemIDs() + "',true);", true);
            }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void btnPDFBon_Click(object sender, EventArgs e) 
        {
            try
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "openPDFtab('" + GetSelectedItemIDs() + "',false);", true);
            }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }
        
        private string GetSelectedItemIDs()
        {
            try
            {
                string IDs = string.Empty;
                foreach (GridViewRow row in gridRequests.Rows)
                {
                    if (((CheckBox)row.FindControl("chkBxRequest")).Checked)
                        IDs += string.Concat(Convert.ToInt32(((HiddenField)row.FindControl("HIDDENRequestID")).Value), Constants.Char_Star);
                }
                return IDs.TrimEnd(new char[] { Constants.Char_Star });
            }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
            return string.Empty;
        }
        
        protected void gridRequests_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "displayRequest":
                        Response.Redirect(Request.Path + String.Concat(Constants.Char_Question, Constants.QuerystringRequestMode, Constants.Char_Equals, RequestMode.DISP, Constants.Char_Ampersand, Constants.QuerystringRequestID, Constants.Char_Equals, e.CommandArgument), false);
                        break;
                    case "deleteRequest":
                        TaxiAntwerpUtilities.DeleteItem(Convert.ToInt32(e.CommandArgument));
                        Response.Redirect(Request.Path + String.Concat(Constants.Char_Question, Constants.QuerystringRequestMode, Constants.Char_Equals, RequestMode.OVERVIEW),false);
                        break;
                }
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }
    }
}
