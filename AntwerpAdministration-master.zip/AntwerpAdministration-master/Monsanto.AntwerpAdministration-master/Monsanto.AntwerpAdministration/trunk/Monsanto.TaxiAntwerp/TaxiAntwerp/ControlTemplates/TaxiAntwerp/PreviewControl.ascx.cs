﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public partial class PreviewControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblPDF_HeaderName.Text = Constants.Config[Constants.PDF_HeaderName];
            lblPDF_HeaderAddress.Text = Constants.Config[Constants.PDF_HeaderAddress];
            lblPDF_HeaderLocation.Text = Constants.Config[Constants.PDF_HeaderLocation];
            lblPDF_HeaderCountry.Text = Constants.Config[Constants.PDF_HeaderCountry];
            lblPDF_HeaderTel.Text = Constants.Config[Constants.PDF_HeaderTel];
            lblPDF_HeaderFax.Text = Constants.Config[Constants.PDF_HeaderFax];

            lblPDF_HeaderTitle.Text = Constants.Config[Constants.PDF_HeaderTitle];
            
            lblPDF_BodyFrom.Text = Constants.Config[Constants.PDF_BodyFrom];
            lblPDF_BodySubtitle.Text = Constants.Config[Constants.PDF_BodySubtitle];
            lblPDF_BodyTravelDate.Text = Constants.Config[Constants.PDF_BodyTravelDate];
            lblPDF_BodyTraveller.Text = Constants.Config[Constants.PDF_BodyTraveller];
            lblPDF_BodyDepartureHour.Text = Constants.Config[Constants.PDF_BodyDepartureHour];
            lblPDF_BodyDepartureAddress.Text = Constants.Config[Constants.PDF_BodyDepartureAddress];
            lblPDF_BodyDepartureCity.Text = Constants.Config[Constants.PDF_BodyDepartureCity];
            lblPDF_BodyDestinationAddress.Text = Constants.Config[Constants.PDF_BodyDestinationAddress];
            lblPDF_BodyDestinationCity.Text = Constants.Config[Constants.PDF_BodyDestinationCity];
            lblPDF_BodyStopovers.Text = Constants.Config[Constants.PDF_BodyStopovers];
            lblPDF_BodyDepartment.Text = Constants.Config[Constants.PDF_BodyDepartment];
            lblPDF_BodyCostCenter.Text = Constants.Config[Constants.PDF_BodyCostCenter];
            lblPDF_BodyComments.Text = Constants.Config[Constants.PDF_BodyComments];

            lblPDF_Footer1.Text = Constants.Config[Constants.PDF_Footer1];
            lblPDF_Footer2.Text = Constants.Config[Constants.PDF_Footer2];
            lblPDF_Footer3.Text = Constants.Config[Constants.PDF_Footer3];
            lblPDF_Footer4.Text = Constants.Config[Constants.PDF_Footer4];
        }

        public void LoadData(TaxiDetails taxidetails)
        {
            lblPDF_HeaderDate.Text = taxidetails.RequestDate.ToString(Constants.Config[Constants.DateFormat]);
            lblPDF_BodyFrom2.Text = taxidetails.CreatorName;
            lblPDF_BodyTravelDate2.Text = taxidetails.TravelDate.ToString(Constants.Config[Constants.DateFormatLong]);
            foreach(Traveller traveller in taxidetails.Travellers)
                lblPDF_BodyTraveller2.Text += traveller.Name+"<br/>";
            lblPDF_BodyDepartureHour2.Text = taxidetails.DepartureHour;
            lblPDF_BodyDepartureCity2.Text = taxidetails.DepartureCity;
            lblPDF_BodyDepartureAddress2.Text = taxidetails.DepartureAddress;
            lblPDF_BodyDestinationCity2.Text = taxidetails.DestinationCity;
            lblPDF_BodyDestinationAddress2.Text = taxidetails.DestinationAddress;
            foreach (Stopover stopover in taxidetails.Stopovers)
                lblPDF_BodyStopovers2.Text += stopover.ToStringDisplay() + "<br/>";
            lblPDF_BodyDepartment2.Text = taxidetails.Department;
            lblPDF_BodyCostCenter2.Text = taxidetails.CostCenter;
            lblPDF_BodyComments2.Text = taxidetails.Comment;
        }
    }
}
