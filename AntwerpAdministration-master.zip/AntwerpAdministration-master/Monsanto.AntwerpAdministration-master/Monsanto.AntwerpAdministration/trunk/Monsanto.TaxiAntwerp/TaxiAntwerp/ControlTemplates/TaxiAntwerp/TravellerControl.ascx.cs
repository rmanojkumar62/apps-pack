﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public partial class TravellerControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindTravellers();
        }

        private TaxiForm GetRequest()
        {
            return ((TaxiForm)TaxiAntwerpUtilities.FindParentControl(this, typeof(TaxiForm)));
        }

        private void BindTravellers()
        {
            TaxiForm request = GetRequest();
            List<Traveller> travellers = request.GetTravellerList();
            if (travellers == null)
                request.SetTravellerList(new List<Traveller>());
            gridTravellers.DataSource = travellers;
            gridTravellers.DataBind();
        }

        public void InsertTraveller(Traveller traveller)
        {
            TaxiForm request = GetRequest();
            List<Traveller> travellers = request.GetTravellerList();
            if (!CheckEmptyFields(traveller.Name, travellers))
            {
                traveller.ID = travellers.Count;
                travellers.Add(traveller);
                request.SetTravellerList(travellers);
            }
            BindTravellers();
        }

        protected void gridTravellers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.QuerystringRequestMode]))
                if (Request.QueryString[Constants.QuerystringRequestMode].Equals(Convert.ToString(RequestMode.DISP)))
                    if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                        e.Row.Cells[2].Visible = false;
        }

        protected void gridTravellers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            TaxiForm request = GetRequest();
            List<Traveller> travellers = request.GetTravellerList();
            travellers.RemoveAt(e.RowIndex);
            request.SetTravellerList(travellers);
            if (gridTravellers.EditIndex > -1)
                gridTravellers.EditIndex = -1;
            BindTravellers();
        }

        private bool CheckEmptyFields(string name, List<Traveller> travellers)
        {
            lblErrorMessage.Text = string.Empty;
            if (string.IsNullOrEmpty(name))
            {
                lblErrorMessage.Text = "Please enter a valid traveller!";
                return true;
            }
            if (travellers.Where(t => t.Name.Equals(name)).Count() > 0)
            {
                lblErrorMessage.Text = "Traveller already added, enter a different traveller!";
                return true;
            }
            return false;
        }
    }
}