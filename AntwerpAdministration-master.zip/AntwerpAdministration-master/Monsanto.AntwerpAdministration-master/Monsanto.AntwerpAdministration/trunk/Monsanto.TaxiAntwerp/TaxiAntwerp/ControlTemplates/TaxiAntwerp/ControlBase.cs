﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Monsanto.TaxiAntwerp.TaxiAntwerpWebpart;
using System.Web.UI.HtmlControls;
using System.Web;
using Microsoft.SharePoint.Utilities;
using System.Reflection;
using iTextSharp.text.pdf;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public class ControlBase : UserControl
    {
        #region PROPERTIES
        public int LastBonNr { get; set; }
        public string WebpartPageUrl { get; set; }
        public string FaxAddress { get; set; }
        public string ImagesPath { get; set; }
        public string ApplicationEmail { get; set; }
        public string OutboundSMTPServer { get; set; }
        public string SharePointServicesEmail { get; set; }
        public string EmailHeaderImage { get { return Server.MapPath("~/_layouts/TaxiAntwerp/images/Bayer1.png"); } }
        public string StyleLibrary { get { return "/Style Library/Antwerp Administration Design/images/"; } }
        public string CostcentersListUrl { get; set; }
        public bool AutomaticFax { get; set; }
        #endregion

        #region VIRTUAL METHODS
        protected virtual void ResetViewStateObjects() { }
        protected virtual void AccessDenied() { }
        protected virtual void EnableMaintenance() { }
        protected virtual void EnableMenu() { }
        protected virtual void DisableMenu() { }
        protected virtual void EnableOverview() { }
        protected virtual void EnableRequest() { }
        protected virtual void PageRefresh() { }
        public virtual void LoadTaxiRequest(RequestMode mode) { }
        #endregion
        
        #region VIEWSTATE OBJECTS
        public void SetTravellerList(List<Traveller> travellers)
        {
            ViewState[Constants.ViewStateTravellerList] = travellers;
        }
        public List<Traveller> GetTravellerList()
        {
            return (List<Traveller>)ViewState[Constants.ViewStateTravellerList];
        }
        public void SetStopoverList(List<Stopover> stopovers)
        {
            ViewState[Constants.ViewStateStopoverList] = stopovers;
        }
        public List<Stopover> GetStopoverList()
        {
            return (List<Stopover>)ViewState[Constants.ViewStateStopoverList];
        }
        public void SetTaxiDetailsList(List<TaxiDetails> taxidetails)
        {
            ViewState[Constants.ViewStateTaxiDetailsList] = taxidetails;
        }
        public List<TaxiDetails> GetTaxiDetailsList()
        {
            return (List<TaxiDetails>)ViewState[Constants.ViewStateTaxiDetailsList];
        }
        public void SetViewStateFormCount(int taxiformcount)
        {
            ViewState[Constants.ViewStateFormCount] = taxiformcount;
        }

        public int GetViewStateFormCount()
        {
            return Convert.ToInt32(ViewState[Constants.ViewStateFormCount]);
        }

        public void SetViewStateRequestIDList(List<int> requestIDList)
        {
            ViewState[Constants.ViewStateRequestIDList] = requestIDList;
        }

        public List<int> GetViewStateRequestIDList()
        {
            return (List<int>)ViewState[Constants.ViewStateRequestIDList];
        }
        #endregion

        protected override void OnLoad(EventArgs e)
        {
            try
            {
                base.OnLoad(e);
                if (!IsPostBack)
                {
                    ResetViewStateObjects();
                    if (Request.QueryString.Count == 0)
                        EnableMenu();
                    else if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringReloadConfig]) && TaxiAntwerpUtilities.HasAdminPermission())
                        Constants._Config = null;
                    else if (!string.IsNullOrEmpty(Request.QueryString[Constants.QuerystringRequestMode]))
                    {
                        DisableMenu();
                        if (string.IsNullOrEmpty(Request.QueryString[Constants.QuerystringRequestID]))
                            EnableOverview();
                        else
                        {
                            //if (TaxiAntwerpUtilities.HasAdminPermission())
                            //{
                            EnableRequest();
                            if (Request.QueryString[Constants.QuerystringRequestMode] == Convert.ToString(RequestMode.NEW))
                                LoadTaxiRequest(RequestMode.NEW);
                            else if (Request.QueryString[Constants.QuerystringRequestMode] == Convert.ToString(RequestMode.DISP))
                                LoadTaxiRequest(RequestMode.DISP);
                            else if (Request.QueryString[Constants.QuerystringRequestMode] == Convert.ToString(RequestMode.EDIT))
                                LoadTaxiRequest(RequestMode.EDIT);
                            //}
                            //else
                            //    EnableMaintenance();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, string.Concat(ex.Message, " ", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()));
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString(string.Concat(ex.Message, " ", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()));
            }
        }

        public void LoadControl(TaxiAntwerpWebpart.TaxiAntwerpWebpart webpart)
        {
            WebpartPageUrl = webpart.WebpartPageUrl;
            ImagesPath = webpart.StyleLibraryPath + "images/";
            FaxAddress = webpart.FaxAddress;
            ApplicationEmail = webpart.EmailApp;
            OutboundSMTPServer = webpart.OutboundSMTPserver;
            SharePointServicesEmail = webpart.SharePointServicesTeamEmail;
            LastBonNr = webpart.LastBonNr;
            CostcentersListUrl = webpart.CostcentersListUrl;
            AutomaticFax = webpart.AutomaticFax;
        }

        protected void CreateFax(List<TaxiDetails> taxidetailslist)
        {
            try
            {
                byte[] pdfdoc;
                PDFCreator creator = new PDFCreator();
                pdfdoc = creator.CreatePDF(taxidetailslist, Server.MapPath("~/_layouts/TaxiAntwerp/images/Bayer1.png"));
                MailCreator.SendFax(pdfdoc, this);
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }
        protected void CreateMail(List<TaxiDetails> taxidetailslist)
        {
            try
            {
                byte[] pdfdoc;
                PDFCreator creator = new PDFCreator();
                pdfdoc = creator.CreatePDF(taxidetailslist, Server.MapPath("~/_layouts/TaxiAntwerp/images/Bayer1.png"));
                MailCreator.SendMail(pdfdoc, this);
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void ThrowError(ErrorType errortype, string message)
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), "error('" + errortype + "','" + TaxiAntwerpUtilities.FormatErrorMessageForUI(message) + "');", true);
        }

        protected void ThrowError(ErrorType errortype, Exception ex)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, ex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(ex.Message);
            MailCreator.SendErrorMail(ex.Message, ex.StackTrace, (ex.InnerException == null) ? string.Empty : ex.InnerException.Message, this);
            if (ex.Message.IndexOf(Constants.Char_Star) != -1)
                ThrowError(errortype, ex.Message.Substring(0, ex.Message.IndexOf(Constants.Char_Star)));
        }

        protected void ThrowError(ErrorType errortype, TaxiAntwerpException pex)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, pex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(pex.Message);
            MailCreator.SendErrorMail(pex.Message, pex.StackTrace, (pex.InnerException == null) ? string.Empty : pex.InnerException.Message, this);
            if (!string.IsNullOrEmpty(pex.FriendlyMessage))
                ThrowError(errortype, pex.FriendlyMessage);
        }

        protected void ThrowError(ErrorType errortype, Exception ex, string classname, string method, string friendlymessage)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, ex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(ex.Message);
            MailCreator.SendErrorMail(ex.Message, ex.StackTrace, (ex.InnerException == null) ? string.Empty : ex.InnerException.Message, this);
            if (!string.IsNullOrEmpty(friendlymessage))
                ThrowError(errortype, friendlymessage);
        }
    }
}