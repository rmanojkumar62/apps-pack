﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public partial class StopoverControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BindStopovers();
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.QuerystringRequestMode]))
                if (Request.QueryString[Constants.QuerystringRequestMode].Equals(Convert.ToString(RequestMode.DISP)))
                {
                    Control row = TaxiAntwerpUtilities.FindChildControl(gridStopovers, "emptydata");
                    if (row != null)
                        ((TableRow)row).Visible = false;
                }
        }

        private TaxiForm GetRequest()
        {
            return ((TaxiForm)TaxiAntwerpUtilities.FindParentControl(this, typeof(TaxiForm)));
        }

        private void BindStopovers()
        {
            TaxiForm request = GetRequest();
            List<Stopover> stopovers = request.GetStopoverList();
            if (stopovers == null)
                request.SetStopoverList(new List<Stopover>());
            gridStopovers.DataSource = stopovers;
            gridStopovers.DataBind();
        }

        private void InsertRow(Stopover stopover)
        {
            TaxiForm request = GetRequest();
            List<Stopover> stopovers = request.GetStopoverList();
            if (!CheckEmptyFields(stopover.Address, stopover.City, stopovers))
            {
                stopover.ID = stopovers.Count;
                stopovers.Add(stopover);
                request.SetStopoverList(stopovers);
            }
            if (gridStopovers.EditIndex > -1)
                gridStopovers.EditIndex = -1;
            BindStopovers();
        }

        private void UpdateRow(Stopover stopover, int index, TaxiForm request, List<Stopover> stopovers)
        {
            stopovers[index] = stopover;
            request.SetStopoverList(stopovers);
        }

        protected void gridStopovers_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.QuerystringRequestMode]))
                if (Request.QueryString[Constants.QuerystringRequestMode].Equals(Convert.ToString(RequestMode.DISP)))
                {
                    gridStopovers.ShowFooter = false;
                    if (e.Row.RowType == DataControlRowType.DataRow || e.Row.RowType == DataControlRowType.Header)
                    {
                        e.Row.Cells[2].Visible = false;
                        e.Row.Cells[3].Visible = false;
                    }
                }
        }

        protected void gridStopovers_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            string address = string.Empty, city = string.Empty;
            if (e.CommandName.Equals("EmptyInsert"))
            {
                address = ((TextBox)TaxiAntwerpUtilities.FindChildControl(gridStopovers, "txtAddressEmpty")).Text;
                city = ((TextBox)TaxiAntwerpUtilities.FindChildControl(gridStopovers, "txtCityEmpty")).Text;
            }
            if (e.CommandName.Equals("Insert"))
            {
                address = ((TextBox)TaxiAntwerpUtilities.FindChildControl(gridStopovers, "txtAddress")).Text;
                city = ((TextBox)TaxiAntwerpUtilities.FindChildControl(gridStopovers, "txtCity")).Text;
            }
            if (e.CommandName.Equals("Insert") || e.CommandName.Equals("EmptyInsert"))
            {
                InsertRow(new Stopover(address, city));
            }
        }

        protected void gridStopovers_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gridStopovers.EditIndex = e.NewEditIndex;
            BindStopovers();
        }

        protected void gridStopovers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gridStopovers.EditIndex = -1;
            BindStopovers();
        }

        protected void gridStopovers_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gridStopovers.Rows[e.RowIndex];
            string address = ((TextBox)TaxiAntwerpUtilities.FindChildControl(gridStopovers, "txtAddressEdit")).Text;
            string city = ((TextBox)TaxiAntwerpUtilities.FindChildControl(gridStopovers, "txtCityEdit")).Text;
            TaxiForm request = GetRequest();
            List<Stopover> stopovers = request.GetStopoverList();
            if (!CheckEmptyFields(address, city, stopovers))
            {
                UpdateRow(new Stopover(address, city), e.RowIndex,request, stopovers);
                gridStopovers.EditIndex = -1;
            }
            BindStopovers();
        }

        protected void gridStopovers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            TaxiForm request = GetRequest();
            List<Stopover> stopovers = request.GetStopoverList();
            stopovers.RemoveAt(e.RowIndex);
            request.SetStopoverList(stopovers);
            if (gridStopovers.EditIndex > -1)
                gridStopovers.EditIndex = -1;
            BindStopovers();
        }

        private bool CheckEmptyFields(string address, string city, List<Stopover> stopovers)
        {
            lblErrorMessage.Text = string.Empty;
            if (string.IsNullOrEmpty(address) && string.IsNullOrEmpty(city))
            {
                lblErrorMessage.Text = "Please enter a valid stopover!";
                return true;
            }
            if (stopovers.Where(t => t.Address.Equals(address)&&t.City.Equals(city)).Count() > 0)
            {
                lblErrorMessage.Text = "Stopover already added, enter a different stopover!";
                return true;
            }
            return false;
        }
    }
}
