﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections;
using System.Reflection;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint;
using System.Drawing;
using System.Collections.Generic;
using Monsanto.TaxiAntwerp.TaxiAntwerpWebpart;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp
{
    public partial class TaxiForm : ControlBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }
        
        protected void Page_PreRender(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                if (!string.IsNullOrEmpty(HIDDENCommisioned.Value))
                {
                    SPUser user = TaxiAntwerpUtilities.EnsureUser(HIDDENCommisioned.Value);
                    UpdateCommisioned(this, user);
                }
                //UpdateHeader(this,true);
            }
        }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.QuerystringRequestMode]))
                if (Request.QueryString[Constants.QuerystringRequestMode].Equals(Convert.ToString(RequestMode.DISP)))
                {
                    HideControls();
                }
        }

        private void HideControls()
        {
            sppTravellerIcon.Visible = false;
            sppTravellerText.Visible = false;
            txtTraveller.Visible = false;
            checkNotMonsanto.Visible = false;
            lblnotMonsanto.Visible = false;
            btnAddTraveller.Visible = false;
            btnSwitch.Visible = false;
        }

        /*private void UpdateHeader(TaxiForm taxiform,bool check)
        {
            if (taxiform.TravelDate.SelectedDate > DateTime.MinValue && taxiform.GetTravellerList().Count > 0 && !string.IsNullOrEmpty(taxiform.txtDepartureCity.Text) && !string.IsNullOrEmpty(taxiform.txtDestinationCity.Text))
            {
                string output = string.Empty;
                string traveller = taxiform.GetTravellerList()[0].Name;
                string departurecity = taxiform.txtDepartureCity.Text;
                string destinationcity = taxiform.txtDestinationCity.Text;
                if (traveller.IndexOf("[") != -1)
                    traveller = traveller.Substring(0, traveller.IndexOf("[") - 1);
                if (traveller.Length > 30)
                    traveller = traveller.Substring(0, 30) + "...";
                if (departurecity.Length > 25)
                    departurecity = departurecity.Substring(0, 25) + "...";
                if (destinationcity.Length > 25)
                    destinationcity = destinationcity.Substring(0, 25) + "...";
                output = string.Concat(taxiform.TravelDate.SelectedDate.ToString(Constants.Config[Constants.DateFormat]), Constants.ItemSplitter, traveller, Constants.ItemSplitter, departurecity, " -> ", destinationcity);
                if (check && taxiform.lblTaxiFormLegend.Text.IndexOf("->") == -1||!check)
                    taxiform.lblTaxiFormLegend.Text = string.Concat(taxiform.lblTaxiFormLegend.Text, Constants.ItemSplitter, output);
                else
                    taxiform.lblTaxiFormLegend.Text = string.Concat(taxiform.lblTaxiFormLegend.Text.Substring(0, taxiform.lblTaxiFormLegend.Text.IndexOf('-') - 1), Constants.ItemSplitter, output);
            }
        }*/

        protected void btnCopy_Click(object sender, EventArgs e)
        {
            try
            {
                Control pnlForms = TaxiAntwerpUtilities.FindParentControl((Button)sender, typeof(WebControl));
                RequestControl requestControl = (RequestControl)TaxiAntwerpUtilities.FindParentControl(pnlForms, typeof(RequestControl));
                TaxiForm form = (TaxiForm)((((Button)sender).Parent).Parent).Parent;
                TaxiForm taxiform = (TaxiForm)LoadControl(Constants.TaxiFormControl);
                int taxiformcount = requestControl.GetViewStateFormCount();
                taxiform = TaxiAntwerpUtilities.SetTaxiForm(taxiform, taxiformcount);
                taxiform.TravelDate.SelectedDate = form.TravelDate.SelectedDate;
                taxiform.checkNotMonsanto.Checked = form.checkNotMonsanto.Checked;
                taxiform.txtDepartureHour.Text = form.txtDepartureHour.Text;
                taxiform.txtDepartureCity.Text = form.txtDepartureCity.Text;
                taxiform.txtDepartureAddress.Text = form.txtDepartureAddress.Text;
                taxiform.txtDestinationCity.Text = form.txtDestinationCity.Text;
                taxiform.txtDestinationAddress.Text = form.txtDestinationAddress.Text;
                taxiform.txtDepartment.Text = form.txtDepartment.Text;
                taxiform.dropCostCenter.SelectedIndex = form.dropCostCenter.SelectedIndex;
                taxiform.txtComments.Text = form.txtComments.Text;
                taxiform.SetStopoverList(form.GetStopoverList());
                taxiform.SetTravellerList(form.GetTravellerList());
                //UpdateHeader(taxiform,false);
                pnlForms.Controls.Add(taxiform);
                List<TaxiDetails> taxidetailsList=requestControl.GetTaxiDetailsList();
                taxidetailsList.ElementAt(taxiformcount-1).Travellers = form.GetTravellerList();
                taxidetailsList.ElementAt(taxiformcount-1).Stopovers = form.GetStopoverList();
                TaxiDetails details=new TaxiDetails();
                details.Travellers=form.GetTravellerList();
                details.Stopovers=form.GetStopoverList();
                taxidetailsList.Add(details);
                requestControl.SetTaxiDetailsList(taxidetailsList);
                requestControl.SetViewStateFormCount(++taxiformcount);
                if (!string.IsNullOrEmpty(form.HIDDENCommisioned.Value))
                {
                    SPUser user = TaxiAntwerpUtilities.EnsureUser(form.HIDDENCommisioned.Value);
                    taxiform.HIDDENCommisioned.Value=form.HIDDENCommisioned.Value;
                    UpdateCommisioned(form,user);
                    UpdateCommisioned(taxiform,user);
                }
                requestControl.CheckDisableDeleteButton();
                Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), string.Concat("setSPPID(", requestControl.GetViewStateFormCount(), ");"), true);
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void checkNotMonsanto_Changed(object sender, EventArgs e)
        {
            if (checkNotMonsanto.Checked)
            {
                sppTravellerIcon.Attributes["style"] = "display: none;";
                sppTravellerText.Attributes["style"] = "display: none;";
                txtTraveller.Visible = true;
            }
            else
            {
                sppTravellerIcon.Attributes["style"] = "display: inline;";
                sppTravellerText.Attributes["style"] = "display: inline;";
                txtTraveller.Visible = false;
            }
        }

        protected void btnSwitch_Click(object sender, EventArgs e)
        {
            string depCity = txtDepartureCity.Text;
            string depAddress = txtDepartureAddress.Text;
            string destCity = txtDestinationCity.Text;
            string destAddress = txtDestinationAddress.Text;
            txtDepartureCity.Text = destCity;
            txtDepartureAddress.Text = destAddress;
            txtDestinationCity.Text = depCity;
            txtDestinationAddress.Text = depAddress;
        }
        
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                Control pnlForms = TaxiAntwerpUtilities.FindParentControl((Button)sender, typeof(WebControl));
                RequestControl requestControl = (RequestControl)TaxiAntwerpUtilities.FindParentControl(pnlForms, typeof(RequestControl));
                string formID = ((Control)(((Button)sender).Parent).Parent).Parent.ID;
                int index = Int32.Parse(formID.Substring(formID.IndexOf(Constants.Char_Underscore) + 1));
                pnlForms.Controls.RemoveAt(index);
                if (pnlForms.Controls.Count > 0)
                {
                    for (int j = 0; j < pnlForms.Controls.Count; j++)
                    {
                        if (pnlForms.Controls[j].ID != null && pnlForms.Controls[j].ID.IndexOf(Constants.Char_Underscore) != -1)
                        {
                            int contindex = Int32.Parse(pnlForms.Controls[j].ID.Substring(pnlForms.Controls[j].ID.IndexOf(Constants.Char_Underscore) + 1));
                            if (contindex > index)
                            {
                                pnlForms.Controls[j].ID = string.Concat(Constants.Taxictrl,Constants.Char_Underscore,index);
                                Label legend = (Label)pnlForms.Controls[j].FindControl("lblTaxiFormLegend");
                                legend.Text = string.Concat(Constants.TaxiFormTitle," ",(index + 1));
                                index++;
                            }
                        }
                    }
                }
                List<TaxiDetails> taxidetailsList = requestControl.GetTaxiDetailsList();
                if(index<taxidetailsList.Count)
                    taxidetailsList.RemoveAt(index);
                requestControl.SetTaxiDetailsList(taxidetailsList);
                requestControl.SetViewStateFormCount(requestControl.GetViewStateFormCount() - 1);
                requestControl.CheckDisableDeleteButton();
            }
            catch (TaxiAntwerpException pex) { ThrowError(ErrorType.RUNTIME, pex); }
            catch (Exception ex) { ThrowError(ErrorType.RUNTIME, ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Empty); }
        }

        protected void taxiformupdatepanel_Unload(object sender, EventArgs e)
        {
            MethodInfo methodInfo = typeof(ScriptManager).GetMethods(BindingFlags.NonPublic | BindingFlags.Instance).Where(i => i.Name.Equals("System.Web.UI.IScriptManagerInternal.RegisterUpdatePanel")).First();
            methodInfo.Invoke(ScriptManager.GetCurrent(Page),new object[] { sender as UpdatePanel });
        }

        public void UpdateCommisioned(TaxiForm form,SPUser user)
        {
            form.sppCommisionedText.Value=user.Name;
            form.sppCommisionedIcon.Src="http://mysites.monsanto.com/User%20Photos/Profile%20Pictures/" + form.HIDDENCommisioned.Value.Replace('\\', '_') + "_LThumb.JPG";
            form.sppCommisionedIcon.Attributes["onerror"]="this.src='/enterprise/antwerpadministration/_layouts/images/blogabout96.PNG';";
        }

        protected void btnAddTraveller_Click(object sender, EventArgs e)
        {
            string traveller;
            string login;
            if (checkNotMonsanto.Checked)
            {
                traveller = txtTraveller.Text;
                login = string.Empty;
            }
            else
            {
                traveller = sppTravellerText.Text;
                login = HIDDENTraveller.Value;
            }
            ((TravellerControl)this.travellerCtrl).InsertTraveller(new Traveller(traveller, login, checkNotMonsanto.Checked));
            txtTraveller.Text = string.Empty;
            sppTravellerIcon.Src = "/enterprise/antwerpadministration/_layouts/images/blogabout96.PNG";
            sppTravellerText.Text = string.Empty;
            HIDDENTraveller.Value = string.Empty;
        }
    }
}