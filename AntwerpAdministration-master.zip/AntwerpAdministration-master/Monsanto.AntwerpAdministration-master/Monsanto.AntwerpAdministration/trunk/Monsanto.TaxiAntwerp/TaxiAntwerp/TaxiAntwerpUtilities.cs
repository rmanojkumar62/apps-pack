﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections;
using System.Web;
using System.Reflection;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.TaxiAntwerp
{
    public class TaxiAntwerpUtilities
    {
        public static void GetCostCenters(DropDownList dropdown)
        {
            try
            {
                dropdown.Items.Clear();
                dropdown.Items.Add(Constants.Config[Constants.CostCenter_SelectString]);
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    List<string> items = new List<string>();
                    SPQuery query = new SPQuery();
                    query.Query = @Constants.Config[Constants.CostCenter_Query];
                    SPListItemCollection listitems = web.Lists.TryGetList(Constants.Config[Constants.CostCenters]).GetItems(query);
                    foreach (SPListItem item in listitems)
                    {
                        if (!string.IsNullOrEmpty(Convert.ToString(item[Constants.Config[Constants.Title]])))
                        {
                            if (!items.Contains(item[Constants.Config[Constants.Title]].ToString()))
                            {
                                ListItem dropitem = new ListItem();
                                string devision = string.Empty;
                                if (!string.IsNullOrEmpty(Convert.ToString(item[Constants.Config[Constants.Devision]])))
                                    devision = Constants.ItemSplitter + Convert.ToString(item[Constants.Config[Constants.Devision]]);
                                if (Convert.ToString(item[Constants.Config[Constants.Title]]) != "Other")
                                {
                                    dropitem.Text = string.Concat(Convert.ToString(item[Constants.Config[Constants.Title]]), Constants.ItemSplitter, Convert.ToString(item[Constants.Config[Constants.Department]]), devision);
                                    dropitem.Value = Convert.ToString(item[Constants.Config[Constants.Title]]);
                                    dropdown.Items.Add(dropitem);
                                }
                                else
                                    dropdown.Items.Add(Convert.ToString(item[Constants.Config[Constants.Title]]));
                                items.Add(item[Constants.Config[Constants.Title]].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetCostcenters] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
        }

        public static SPFieldLookupValue GetCostCenterLookup(string listname, SPFieldLookup fieldmaintype, string costcenter)
        {
            try
            {
                string queryFormat = @Constants.Config[Constants.Query_CostcenterLookup];
                string queryText = string.Format(queryFormat, fieldmaintype.LookupField, costcenter);
                SPList lookupList = SPContext.Current.Web.Lists.TryGetList(listname);
                SPListItemCollection lookupItems = lookupList.GetItems(new SPQuery() { Query = queryText });
                if (lookupItems.Count > 0)
                {
                    int lookupId = Convert.ToInt32(lookupItems[0][SPBuiltInFieldId.ID]);
                    return new SPFieldLookupValue(lookupId, costcenter);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetCostcenterLookup] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return null;
        }

        public static SPUser EnsureUser(string loginname)
        {
            SPUser user = null;
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    user = web.EnsureUser(loginname);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_EnsureUser] + " (login: " + loginname + ", current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return user;
        }

        public static string GetSharePointUserField(string userstring, SPFieldUser field, bool check)
        {
            try
            {
                if (string.IsNullOrEmpty(userstring))
                    return string.Empty;
                SPFieldUserValue fieldValue = (SPFieldUserValue)field.GetFieldValue(userstring);
                if (check)
                    return fieldValue.User.Name;
                else
                    return fieldValue.User.LoginName;
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetUserField] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return string.Empty;
        }

        public static void SetUser(int ID, string username, string field, SPListItem request)
        {
            request[field] = new SPFieldUserValue(request.Web, ID, username);
        }

        public static string FormatErrorMessageForUI(string message)
        {
            return message.Replace('\'', ' ').Replace('(', '[').Replace(')', ']');
        }

        public static Control FindChildControl(Control rootControl, string controlID)
        {
            if (rootControl.ID == controlID) return rootControl;
            foreach (Control controlToSearch in rootControl.Controls)
            {
                Control controlToReturn = FindChildControl(controlToSearch, controlID);
                if (controlToReturn != null) return controlToReturn;
            }
            return null;
        }

        public static Control FindParentControl(Control control, Type typeparent)
        {
            Control ctrlParent = control;
            while ((ctrlParent = ctrlParent.Parent) != null)
            {
                if (ctrlParent.GetType().BaseType == typeparent)
                    return ctrlParent;
            }
            return null;
        }

        public static TaxiForm SetTaxiForm(TaxiForm taxiform, int taxiformcount)
        {
            taxiform.ID = String.Format("taxictrl_{0}", taxiformcount);
            GetCostCenters((DropDownList)taxiform.FindControl("dropCostCenter"));
            Label legend = (Label)taxiform.FindControl("lblTaxiFormLegend");
            legend.Text = "Travel " + (taxiformcount + 1);
            return taxiform;
        }

        public static void SetControlsReadOnly(Control parentControl)
        {
            try
            {
                foreach (Control control in parentControl.Controls)
                {
                    if (control.GetType().Equals(typeof(TextBox)))
                        ((TextBox)control).Enabled = false;
                    if (control.GetType().Equals(typeof(DateTimeControl)))
                        ((DateTimeControl)control).Enabled = false;
                    if (control.GetType().Equals(typeof(CheckBox)))
                        ((CheckBox)control).Enabled = false;
                    if (control.GetType().Equals(typeof(RadioButtonList)))
                        ((RadioButtonList)control).Enabled = false;
                    if (control.GetType().Equals(typeof(DropDownList)))
                        ((DropDownList)control).Enabled = false;
                    if (control.HasControls())
                        SetControlsReadOnly(control);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_SetControlsReadonly] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
        }

        public static TaxiDetails GetTaxiDetailByID(string ID)
        {
            TaxiDetails taxidetails = new TaxiDetails();
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPListItem request = web.Lists[Constants.Config[Constants.TaxiRequestList]].GetItemById(Convert.ToInt32(ID));
                    string creatorlogin = TaxiAntwerpUtilities.GetSharePointUserField(Convert.ToString(request[Constants.Config[Constants.Creator]]), (SPFieldUser)request.Fields.GetField(Constants.Config[Constants.Creator]), false);
                    if (!string.IsNullOrEmpty(creatorlogin))
                    {
                        SPUser creator = SPContext.Current.Web.EnsureUser(creatorlogin);
                        taxidetails.CreatorID = creator.ID;
                        taxidetails.CreatorName = creator.Name;
                        taxidetails.CreatorLogin = creator.LoginName;
                    }
                    string commissionedlogin = TaxiAntwerpUtilities.GetSharePointUserField(Convert.ToString(request[Constants.Config[Constants.Commissioner]]), (SPFieldUser)request.Fields.GetField(Constants.Config[Constants.Commissioner]), false);
                    if (!string.IsNullOrEmpty(commissionedlogin))
                    {
                        SPUser comm = SPContext.Current.Web.EnsureUser(commissionedlogin);
                        taxidetails.CommissionedByID = comm.ID;
                        taxidetails.CommissionedByName = comm.Name;
                        taxidetails.CommissionedByLogin = comm.LoginName;
                    }
                    taxidetails.Travellers = GetTravellersFromListItem(request);
                    taxidetails = GetTaxiDetailsData(request, taxidetails);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetItemByID] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return taxidetails;
        }

        public static List<Traveller> GetTravellersFromListItem(SPListItem request)
        {
            List<Traveller> travellers = new List<Traveller>();
            if (!string.IsNullOrEmpty(Convert.ToString(request[Constants.TravellerList])))
            {
                string[] travellerslist = Convert.ToString(request[Constants.TravellerList]).TrimEnd(Constants.Char_DelimiterItems.ToCharArray()).Split(new string[] { Constants.Char_DelimiterItems }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string traveller in travellerslist)
                {
                    string[] travellervalues = traveller.Split(new string[] { Constants.Char_DelimiterValues }, StringSplitOptions.RemoveEmptyEntries);
                    if (travellervalues.Length == 3)
                        travellers.Add(new Traveller(Convert.ToInt32(travellervalues[0]), travellervalues[1], Convert.ToBoolean(travellervalues[2])));
                    else
                        travellers.Add(new Traveller(Convert.ToInt32(travellervalues[0]), travellervalues[1], travellervalues[2], Convert.ToBoolean(travellervalues[3])));
                }
            }
            return travellers;
        }

        private static List<Stopover> GetStopovers(string stopoversstring)
        {
            List<Stopover> stopoverList = new List<Stopover>();
            if (!string.IsNullOrEmpty(stopoversstring))
            {
                string[] stopovers = stopoversstring.Split(new string[] { Constants.Char_DelimiterItems }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < stopovers.Length; i++)
                    stopoverList.Add(new Stopover(i, stopovers[i].Split(new string[] { Constants.Char_DelimiterValues }, StringSplitOptions.RemoveEmptyEntries)[0], stopovers[i].Split(new string[] { Constants.Char_DelimiterValues }, StringSplitOptions.RemoveEmptyEntries)[1]));
            }
            return stopoverList;
        }

        private static TaxiDetails GetTaxiDetailsData(SPListItem request, TaxiDetails taxidetails)
        {
            try
            {
                taxidetails.RequestDate = Convert.ToDateTime(request[Constants.Config[Constants.RequestDate]]);
                taxidetails.TravelDate = Convert.ToDateTime(request[Constants.Config[Constants.TravelDate]]);
                taxidetails.MultipleTravellers = Convert.ToBoolean(request[Constants.Config[Constants.MultipleTravellers]]);
                taxidetails.DepartureHour = Convert.ToString(request[Constants.Config[Constants.DepartureHour]]);
                taxidetails.DepartureCity = Convert.ToString(request[Constants.Config[Constants.DepartureCity]]);
                taxidetails.DepartureAddress = Convert.ToString(request[Constants.Config[Constants.DepartureAddress]]);
                taxidetails.DestinationCity = Convert.ToString(request[Constants.Config[Constants.DestinationCity]]);
                taxidetails.DestinationAddress = Convert.ToString(request[Constants.Config[Constants.DestinationAddress]]);
                taxidetails.Department = Convert.ToString(request[Constants.Config[Constants.Department]]);
                taxidetails.CostCenter = new SPFieldLookupValue(Convert.ToString(request[Constants.Config[Constants.Costcenter]])).LookupValue;
                taxidetails.Comment = Convert.ToString(request[Constants.Config[Constants.Comments]]);
                taxidetails.BonNumber = Convert.ToString(request[Constants.BonNumber]);
                taxidetails.Stopovers = GetStopovers(Convert.ToString(request[Constants.Config[Constants.Stopovers]]));
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetItemByID] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return taxidetails;
        }

        public static void DeleteItem(int id)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    web.Lists.TryGetList(Constants.Config[Constants.TaxiRequestList]).Items.GetItemById(id).Recycle();
                }
            }
            catch (SPException ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Error_DeleteItem + " (specID:" + id + ",current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
        }

        public static Dictionary<string, string> GetConfigValues()
        {
            Dictionary<string, string> configValues = new Dictionary<string, string>();
            try
            {
                SPList config = SPContext.Current.Web.Lists.TryGetList(Constants.ConfigList);
                foreach (SPListItem item in config.GetItems())
                    configValues.Add(Convert.ToString(item[Constants.Key]), Convert.ToString(item[Constants.Value]));
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetConfigValues] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return configValues;
        }

        public static int GetMaxBonNumber()
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = @Constants.Config[Constants.Query_MaxBonNr];
                    query.RowLimit = 1;
                    SPListItemCollection listitems = web.Lists.TryGetList(Constants.Config[Constants.TaxiRequestList]).GetItems(query);
                    if (listitems.Count > 0)
                        return Convert.ToInt32(listitems[0][Constants.BonNumber]);
                }
            }
            catch (Exception ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_GetMaxBonNr] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return 0;
        }

        public static bool HasAdminPermission()
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;
                return currentWeb.UserIsWebAdmin || currentWeb.UserIsSiteAdmin || currentWeb.DoesUserHavePermissions(SPBasePermissions.FullMask);
            }
            catch (SPException ex) { ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_HasAdminPermission] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return false;
        }

        public static void ThrowError(Exception ex, string classstring, string methodstring, string friendlymessage)
        {
            TaxiAntwerpException tex = new TaxiAntwerpException(String.Format(Constants.ExceptionHeader + " – {0} * {1} – {2} - {3} - {4}", "Class: " + classstring + "  Method: " + methodstring + "  User: " + SPContext.Current.Web.CurrentUser.Name + "  Friendlymessage: " + friendlymessage, ex, ex.Message, ex.StackTrace, (ex.InnerException == null) ? string.Empty : ex.InnerException.Message), ex);
            tex.Class = classstring; tex.Method = methodstring; tex.CurrentUser = SPContext.Current.Web.CurrentUser.Name; tex.FriendlyMessage = friendlymessage;
            throw tex;
        }
    }
}