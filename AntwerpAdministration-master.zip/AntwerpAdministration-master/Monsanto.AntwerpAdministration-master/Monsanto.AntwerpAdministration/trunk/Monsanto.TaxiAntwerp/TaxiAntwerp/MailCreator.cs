﻿using System;
using System.Collections.Generic;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.Net;
using System.Net.Mail;
using System.IO;
using Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp;
using System.Reflection;
namespace Monsanto.TaxiAntwerp
{
    public class MailCreator
    {
        private static TaxiDetails taxidetails { get; set; }
        private static ControlBase control { get; set; }

        public static void SendErrorMail(string exceptionmessage, string stacktrace, string innerexception, ControlBase ctrl)
        {
            control = ctrl;
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(control.ApplicationEmail);
                mailMessage.To.Add(new MailAddress(control.SharePointServicesEmail));
                mailMessage.Subject = "Error occurred in taxi antwerp app";
                mailMessage.Body = exceptionmessage + "\n\n" + stacktrace + "\n\n" + innerexception;
                SmtpClient smtpClient = new SmtpClient(control.OutboundSMTPServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error sending error mail"); }
        }

        public static void SendFax(byte[] pdfdoc, ControlBase ctrl)
        {
            MemoryStream memoryStreamOfFile = null;
            control = ctrl;
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(SPContext.Current.Web.CurrentUser.Email);
                mailMessage.To.Add(new MailAddress(control.FaxAddress));
                mailMessage.Subject = "Monsanto Taxi Request";
                string attachmentname = string.Concat("MonsantoTaxiRequest-", DateTime.Now.ToString(Constants.Config[Constants.DateFormat]), ".pdf");
                memoryStreamOfFile = new MemoryStream(pdfdoc);
                mailMessage.Attachments.Add(new System.Net.Mail.Attachment(memoryStreamOfFile, attachmentname));
                SmtpClient smtpClient = new SmtpClient(control.OutboundSMTPServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error creating fax (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            finally
            {
                if (memoryStreamOfFile != null)
                    memoryStreamOfFile.Close();
            }
        }

        public static void SendMail(byte[] pdfdoc, ControlBase ctrl)
        {
            MemoryStream memoryStreamOfFile = null;
            control = ctrl;
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(control.ApplicationEmail);
                mailMessage.To.Add(new MailAddress(SPContext.Current.Web.CurrentUser.Email));
                mailMessage.Subject = "Monsanto Taxi Request";
                mailMessage = SetMailData(mailMessage);
                string attachmentname = string.Concat("MonsantoTaxiRequest-", DateTime.Now.ToString(Constants.Config[Constants.DateFormat]), ".pdf");
                memoryStreamOfFile = new MemoryStream(pdfdoc);
                mailMessage.Attachments.Add(new System.Net.Mail.Attachment(memoryStreamOfFile, attachmentname));
                SmtpClient smtpClient = new SmtpClient(control.OutboundSMTPServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error creating mail (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            finally
            {
                if (memoryStreamOfFile != null)
                    memoryStreamOfFile.Close();
            }
        }

        private static MailMessage SetMailData(MailMessage mailMessage)
        {
            try
            {
                string content;
                mailMessage.IsBodyHtml = true;
                content = Constants.Config[Constants.EmailTemplate];
                AlternateView objHTLMAltView = AlternateView.CreateAlternateViewFromString(content, new System.Net.Mime.ContentType("text/html"));
                mailMessage.AlternateViews.Add(objHTLMAltView);
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error setting mail data (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return mailMessage;
        }
    }
}