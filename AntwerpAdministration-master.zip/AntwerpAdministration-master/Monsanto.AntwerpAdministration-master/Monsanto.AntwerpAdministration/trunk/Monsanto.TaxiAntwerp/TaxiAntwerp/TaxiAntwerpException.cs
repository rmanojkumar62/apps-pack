﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Monsanto.TaxiAntwerp
{
    [Serializable()]
    public class TaxiAntwerpException : Exception
    {
        public TaxiAntwerpException() : base() { }
        public TaxiAntwerpException(string message) : base(message) { }
        public TaxiAntwerpException(string message, Exception e) : base(message, e) { }
        protected TaxiAntwerpException(SerializationInfo info, StreamingContext context) : base(info, context) { }
        public string Class { get; set; }
        public string Method { get; set; }
        public string CurrentUser { get; set; }
        public string FriendlyMessage { get; set; }
    }
}