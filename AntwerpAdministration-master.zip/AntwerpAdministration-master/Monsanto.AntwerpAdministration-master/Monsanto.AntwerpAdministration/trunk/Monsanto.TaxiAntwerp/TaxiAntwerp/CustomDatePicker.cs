﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Monsanto.TaxiAntwerp
{
    [ToolboxData("<{0}:CustomDatePicker runat=server></{0}:CustomDatePicker>")]
    public class CustomDatePicker : Microsoft.SharePoint.WebControls.DateTimeControl
    {
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            TextBox tb = (TextBox)this.Controls[0];
            tb.Text = this.SelectedDate.ToString("dddd dd MMMM yyyy");
        }
        protected override void OnDateChanged(EventArgs e)
        {
            base.OnDateChanged(e);
            TextBox tb = (TextBox)this.Controls[0];
            tb.Text = this.SelectedDate.ToString("dddd dd MMMM yyyy");
        }
    }
}
