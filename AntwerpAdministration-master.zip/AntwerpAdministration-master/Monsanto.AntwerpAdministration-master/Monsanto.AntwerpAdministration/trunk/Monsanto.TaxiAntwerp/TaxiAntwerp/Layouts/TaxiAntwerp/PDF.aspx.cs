﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Reflection;
using System.Collections.Generic;

namespace Monsanto.TaxiAntwerp.Layouts.TaxiAntwerp
{
    public partial class PDF : LayoutsPageBase
    {
        protected void btnPDF_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringPrintIDs]) && !string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringIsFax]))
            {
                if (Convert.ToBoolean(Request.QueryString[Constants.QueryStringIsFax]))
                    CreatePDF(Request.QueryString[Constants.QueryStringPrintIDs]);
                else
                    CreateSmallPDF(Request.QueryString[Constants.QueryStringPrintIDs]);
            }
        }

        private void CreateSmallPDF(string IDs)
        {
            try
            {
                byte[] pdfdoc;
                PDFCreator creator = new PDFCreator();
                pdfdoc = creator.CreateSmallPDF(IDs);
                Response.Clear();
                PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
                isreadonly.SetValue(this.Request.QueryString, false, null);
                if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringPrintIDs]))
                    this.Request.QueryString.Remove(Constants.QueryStringPrintIDs);
                Response.AddHeader("Content-Length", pdfdoc.Length.ToString());
                Response.ContentType = "application/octet-stream";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + Constants.Config[Constants.PDF_BonTitle]);
                Response.BinaryWrite(pdfdoc);
                Response.Flush();
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, string.Concat(ex.Message, " ", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()));
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString(string.Concat(ex.Message, " ", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()));
            }
        }

        private void CreatePDF(string ID)
        {
            try
            {
                byte[] pdfdoc;
                PDFCreator creator = new PDFCreator();
                Response.Clear();
                PropertyInfo isreadonly = typeof(System.Collections.Specialized.NameValueCollection).GetProperty("IsReadOnly", BindingFlags.Instance | BindingFlags.NonPublic);
                isreadonly.SetValue(this.Request.QueryString, false, null);
                if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringPrintIDs]))
                    this.Request.QueryString.Remove(Constants.QueryStringPrintIDs);
                pdfdoc = creator.CreatePDF(ID, Server.MapPath("~/_layouts/TaxiAntwerp/images/Bayer1.png"));
                Response.AddHeader("Content-Length", pdfdoc.Length.ToString());
                Response.ContentType = "application/octet-stream";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + Constants.Config[Constants.PDF_FaxTitle]);
                Response.BinaryWrite(pdfdoc);
                Response.Flush();
                Response.End();
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, string.Concat(ex.Message, " ", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()));
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString(string.Concat(ex.Message, " ", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()));
            }
        }
    }
}

