﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Monsanto.TaxiAntwerp.ControlTemplates.TaxiAntwerp;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Drawing.Printing;

namespace Monsanto.TaxiAntwerp.TaxiAntwerpWebpart
{
    public partial class TaxiAntwerpWebpartUserControl : ControlBase
    {
        public TaxiAntwerpWebpart Webpart { get; set; }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            ((ControlBase)overviewControl).LoadControl(Webpart);
            ((ControlBase)requestControl).LoadControl(Webpart);
            ((ControlBase)this).LoadControl(Webpart);
        }

        private void LoadOverviewControl()
        {
            OverviewControl newControl = (OverviewControl)LoadControl("../" + Constants.OverviewControl);
            ((ControlBase)newControl).LoadControl(Webpart);
            pnlOverviewControl.Controls.Add(newControl);
        }

        private void LoadRequestControl()
        {
            RequestControl newControl = (RequestControl)LoadControl("../" + Constants.RequestControl);
            ((ControlBase)newControl).LoadControl(Webpart);
            pnlRequestControl.Controls.Add(newControl);
        }

        protected override void EnableMaintenance()
        {
            pnlOverviewControl.Visible = false;
            pnlRequestControl.Visible = false;
            pnlAccessDenied.Visible = false;
            pnlMaintenance.Visible = true;
        }

        protected override void EnableMenu()
        {
            pnlRequestMenu.Visible = true;
            pnlRequestContent.Visible = false;
        }

        protected override void DisableMenu()
        {
            pnlRequestMenu.Visible = false;
            pnlRequestContent.Visible = true;
        }

        protected override void EnableOverview()
        {
            pnlOverviewControl.Visible = true;
            pnlRequestControl.Visible = false;
            pnlRequestControl.Controls.Clear();
        }

        protected override void EnableRequest()
        {
            pnlOverviewControl.Visible = false;
            pnlRequestControl.Visible = true;
            pnlOverviewControl.Controls.Clear();
        }

        protected override void AccessDenied()
        {
            pnlOverviewControl.Visible = false;
            pnlRequestControl.Visible = false;
            pnlAccessDenied.Visible = true;
        }

        protected void btnRequests_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(Request.Path, Constants.Char_Question, Constants.QuerystringRequestMode, Constants.Char_Equal, Convert.ToString(RequestMode.OVERVIEW)), false);
        }

        protected void btnNewRequest_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(Request.Path, Constants.Char_Question, Constants.QuerystringRequestMode, Constants.Char_Equal, Convert.ToString(RequestMode.NEW), Constants.Char_Ampersand, Constants.QuerystringRequestID, Constants.Char_Equals, Constants.ResetIndex), false);
        }

        protected void btnCostcenters_Click(object sender, EventArgs e)
        {
            Response.Redirect(Webpart.CostcentersListUrl, false);
        }
    }
}