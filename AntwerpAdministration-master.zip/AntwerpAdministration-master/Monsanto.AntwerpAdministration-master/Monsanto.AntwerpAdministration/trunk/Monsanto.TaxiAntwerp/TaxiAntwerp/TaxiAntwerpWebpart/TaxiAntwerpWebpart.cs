﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.TaxiAntwerp.TaxiAntwerpWebpart
{
    [ToolboxItemAttribute(false)]
    public class TaxiAntwerpWebpart : WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/TaxiAntwerp/TaxiAntwerpWebpart/TaxiAntwerpWebpartUserControl.ascx";
        private string emailapp = "taxiantwerp@monsanto.com";
        private string outboundSMTPserver = "mail.monsanto.com";
        private string sharepointservicesteamemail = "sharepoint.services.antwerp@monsanto.com";
        private string siterooturl = "http://stlwspidvmdev17:60800/enterprise/antwerpadministration/";
        private string webpartpageurl = "http://stlwspidvmdev17:60800/enterprise/antwerpadministration/taxirequest/default.aspx";
        private int lastbonnr = 147500;
        private string stylelibrarypath = "/enterprise/antwerpadministration/Style Library/Antwerp Administration Design/";
        private string faxnr = "fax_003235685090@fax.antwerp.euro.monsanto.com";
        private string costcenterslisturl = "http://stlwspidvmdev17:60800/enterprise/antwerpadministration/taxirequest/Lists/CostCenters/";
        private bool automaticFax;

        #region webpart properties
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Costcenters List Url"),
        WebDescription("Set costcenters list url.")]
        public string CostcentersListUrl
        {
            get { return costcenterslisturl; }
            set { costcenterslisturl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Fax address"),
        WebDescription("Set fax address.")]
        public string FaxAddress
        {
            get { return faxnr; }
            set { faxnr = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Email application"),
        WebDescription("Set email of application.")]
        public string EmailApp
        {
            get { return emailapp; }
            set { emailapp = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Outbound SMTP server"),
        WebDescription("Set outbound SMTP server.")]
        public string OutboundSMTPserver
        {
            get { return outboundSMTPserver; }
            set { outboundSMTPserver = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("SharePoint Services team email"),
        WebDescription("Set SharePoint Services team email.")]
        public string SharePointServicesTeamEmail
        {
            get { return sharepointservicesteamemail; }
            set { sharepointservicesteamemail = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Webpart page url"),
        WebDescription("Set webpart page url.")]
        public string WebpartPageUrl
        {
            get { return webpartpageurl; }
            set { webpartpageurl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Site root url"),
        WebDescription("Set site root url.")]
        public string SiteRootUrl
        {
            get { return siterooturl; }
            set { siterooturl = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Path style library"),
        WebDescription("Set path for style library.")]
        public string StyleLibraryPath
        {
            get { return stylelibrarypath; }
            set { stylelibrarypath = value; }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Last bon number"),
        WebDescription("Set last bon number.")]
        public int LastBonNr
        {
            get { return lastbonnr; }
            set
            {
                int result;
                if (!Int32.TryParse(value.ToString(), out result))
                    throw new Microsoft.SharePoint.WebPartPages.WebPartPageUserException("Bon nr must be a valid integer!");
                lastbonnr = value;
            }
        }
        [WebBrowsable(true),
        Category("Configuration"),
        Personalizable(PersonalizationScope.Shared),
        WebDisplayName("Automatic fax"),
        WebDescription("Set automatic fax.")]
        public bool AutomaticFax
        {
            get { return automaticFax; }
            set { automaticFax = value; }
        }
        #endregion
        protected override void CreateChildControls()
        {
            Control control = Page.LoadControl(_ascxPath);
            if (control != null)
            {
                ((TaxiAntwerpWebpartUserControl)control).Webpart = this;
            }
            Controls.Add(control);
        }
    }
}
