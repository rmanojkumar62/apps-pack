﻿using System.Web;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using Microsoft.SharePoint;
using System;
using System.Linq;
using System.Collections.Generic;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf.draw;
using System.Text.RegularExpressions;
using System.Text;
using System.Reflection;
namespace Monsanto.TaxiAntwerp
{
    public class PDFCreator
    {
        //IMPORTANT: GO TO text=>pdf=>BaseFont.cs CHANGE "RESOURCE_PATH" TO "TaxiAntwerp.iTextSharp.text.pdf.fonts.";
        //GO TO text=>pdf=>fonts SELECT ALL .AFM fILES AND SET THE BUILD ACTION TO EMBEDDED RESOURCE IN THE PROPERTIES
        //OTHERWISE YOU'LL GET AN EXCEPTION THAT THE RESOURCE IS NOT FOUND!!!
        public string Title { get; set; }
        private Phrase nwLn = new Phrase(Environment.NewLine);
        private static BaseFont bf1 = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, false);
        iTextSharp.text.Font font1 = new iTextSharp.text.Font(bf1, 10, iTextSharp.text.Font.NORMAL);
        private static BaseFont bf2 = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, false);
        iTextSharp.text.Font font2 = new iTextSharp.text.Font(bf2, 8, iTextSharp.text.Font.NORMAL);
        private static BaseFont bf3 = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);
        iTextSharp.text.Font font3b = new iTextSharp.text.Font(bf3, 10, iTextSharp.text.Font.BOLD);
        private static BaseFont bf4 = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);
        iTextSharp.text.Font font4b = new iTextSharp.text.Font(bf4, 10, iTextSharp.text.Font.BOLD);
        private static BaseFont bf5 = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false);
        iTextSharp.text.Font font5b = new iTextSharp.text.Font(bf5, 14, iTextSharp.text.Font.BOLD);

        public byte[] CreatePDF(string IDs, string imagepath)
        {
            List<TaxiDetails> taxidetailslist = new List<TaxiDetails>();
            string[] IDarray = IDs.Split(Constants.Char_Star);
            foreach (string ID in IDarray)
                taxidetailslist.Add(TaxiAntwerpUtilities.GetTaxiDetailByID(ID));
            return CreatePDF(taxidetailslist, imagepath);
        }

        public byte[] CreatePDF(List<TaxiDetails> taxidetailslist, string imagepath)
        {
            byte[] result = null;
            try
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    Document document = new Document();
                    PdfWriter writer = PdfWriter.GetInstance(document, ms);
                    document.AddTitle(Title);
                    document.AddSubject(Title);
                    document.AddCreator(Constants.Config[Constants.PDF_Title]);
                    document.AddAuthor(SPContext.Current.Web.CurrentUser.Name);
                    document.Open();
                    CreatePages(writer, document, taxidetailslist, imagepath);
                    document.Close();
                    result = ms.GetBuffer();
                }
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_CreatePDF] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return result;
        }

        public void CreatePages(PdfWriter writer, iTextSharp.text.Document document, List<TaxiDetails> taxidetailslist, string imagepath)
        {
            try
            {
                int teller = 0;
                foreach (TaxiDetails taxidetails in taxidetailslist)
                {
                    CreatePages(writer, document, taxidetails, imagepath);
                    teller++;
                    if (teller < taxidetailslist.Count)
                        document.NewPage();
                }
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_CreatePages] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
        }

        public void CreatePages(PdfWriter writer, iTextSharp.text.Document document, TaxiDetails taxidetails, string imagepath)
        {
            try
            {
                iTextSharp.text.Image pic = iTextSharp.text.Image.GetInstance(imagepath);
                pic.ScaleToFit(150f, 150f);
                Phrase headMon = new Phrase();
                headMon.Add(Constants.Config[Constants.PDF_HeaderName]); headMon.Add(nwLn);
                headMon.Add(Constants.Config[Constants.PDF_HeaderAddress]); headMon.Add(nwLn);
                headMon.Add(Constants.Config[Constants.PDF_HeaderLocation]); headMon.Add(nwLn);
                headMon.Add(Constants.Config[Constants.PDF_HeaderCountry]); headMon.Add(nwLn);
                headMon.Add(Constants.Config[Constants.PDF_HeaderTel]); headMon.Add(nwLn);
                headMon.Add(Constants.Config[Constants.PDF_HeaderFax]); headMon.Add(nwLn); headMon.Add(nwLn);
                Paragraph paragraphHead = new Paragraph(headMon);
                paragraphHead.Alignment = Element.ALIGN_LEFT;
                paragraphHead.Alignment = Element.ALIGN_TOP;
                pic.Alignment = iTextSharp.text.Image.TEXTWRAP | iTextSharp.text.Image.ALIGN_RIGHT;
                pic.SpacingAfter = 15f;
                document.Add(pic);
                document.Add(paragraphHead);
                Paragraph paragraphHeadRight = new Paragraph(DateTime.Today.ToString(Constants.Config[Constants.DateFormat]), font5b);
                Paragraph title = new Paragraph(Constants.Config[Constants.PDF_HeaderTitle], font5b);
                PdfPTable tableTitle = new PdfPTable(2);
                float[] tablewidthsTitle = new float[] { 80f, 20f };
                SetTable(tableTitle, tablewidthsTitle);
                PdfPCell titlecell = new PdfPCell(title);
                titlecell.Border = 0;
                tableTitle.AddCell(titlecell);
                PdfPCell pr = new PdfPCell(paragraphHeadRight);
                pr.Border = 0;
                tableTitle.AddCell(pr);
                document.Add(tableTitle);
                Chunk linebreak = new Chunk(new LineSeparator(2f, 100f, BaseColor.BLACK, Element.ALIGN_CENTER, -1));
                document.Add(linebreak);
                PdfPTable table = new PdfPTable(2);
                float[] tablewidths = new float[] { 30f, 70f };
                SetTable(table, tablewidths);
                string[] labels = new string[] { Constants.Config[Constants.PDF_BodyFrom], Constants.Config[Constants.PDF_BodySubtitle], Constants.Config[Constants.PDF_BodyTravelDate], Constants.Config[Constants.PDF_BodyTraveller], Constants.Config[Constants.PDF_BodyDepartureHour], Constants.Config[Constants.PDF_BodyDepartureCity], Constants.Config[Constants.PDF_BodyDepartureAddress], Constants.Config[Constants.PDF_BodyDestinationCity], Constants.Config[Constants.PDF_BodyDestinationAddress], Constants.Config[Constants.PDF_BodyStopovers], Constants.Config[Constants.PDF_BodyDepartment], Constants.Config[Constants.PDF_BodyCostCenter], Constants.Config[Constants.PDF_BodyComments] };
                object[] data = new object[] { taxidetails.CreatorName, string.Empty, taxidetails.TravelDate.ToString(Constants.Config[Constants.DateFormatLong]), taxidetails.Travellers, taxidetails.DepartureHour, taxidetails.DepartureCity, taxidetails.DepartureAddress, taxidetails.DestinationCity, taxidetails.DestinationAddress, taxidetails.Stopovers, taxidetails.Department, taxidetails.CostCenter, taxidetails.Comment };
                FillTable(table, labels, data);
                AddTable(writer, document, table);
                Paragraph bottomMon1 = new Paragraph();
                bottomMon1.Add(new Phrase(Constants.Config[Constants.PDF_Footer1])); bottomMon1.Add(nwLn); bottomMon1.Add(nwLn);
                bottomMon1.Add(new Phrase(Constants.Config[Constants.PDF_Footer2])); bottomMon1.Add(nwLn); bottomMon1.Add(nwLn);
                Paragraph bottomMon2 = new Paragraph();
                bottomMon2.Add(Constants.Config[Constants.PDF_Footer3]); bottomMon2.Add(nwLn);
                bottomMon2.Add(Constants.Config[Constants.PDF_Footer4]);
                Paragraph paragraphBottom = new Paragraph();
                paragraphBottom.Add(bottomMon1);
                paragraphBottom.Add(bottomMon2);
                paragraphBottom.Alignment = Element.ALIGN_BOTTOM;
                document.Add(paragraphBottom);
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), Constants.Config[Constants.Error_CreatePages] + " (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
        }

        private void CheckTable(PdfWriter writer, Document document, PdfPTable table)
        {
            if (writer.GetVerticalPosition(true) - table.TotalHeight < 20)
                document.NewPage();
        }

        private void SetTable(PdfPTable table, float[] widths)
        {
            table.WidthPercentage = 100;
            table.SetWidths(widths);
            table.SetTotalWidth(widths);
        }

        private void AddCell(PdfPCell cell, PdfPTable table, int counter)
        {
            if (counter == 1) cell.Colspan = 2;
            cell.Border = 0;
            cell.MinimumHeight = 20f;
            table.AddCell(cell);
        }

        private void AddTable(PdfWriter writer, Document document, PdfPTable table)
        {
            table.SpacingAfter = 15f;
            document.Add(table);
        }

        private void FillTable(PdfPTable table, string[] headers, object[] data)
        {
            string s = string.Empty;
            for (int i = 0; i < headers.Length; i++)
            {
                if (i == 1)
                {
                    AddCell(new PdfPCell(), table, i);
                    AddCell(new PdfPCell(new Phrase(headers[i], font4b)), table, i);
                }
                else if (i == 3)
                {
                    if (((List<Traveller>)data[i]).Count > 1)
                        AddCell(new PdfPCell(new Phrase(Constants.Config[Constants.PDF_BodyTravellers], font3b)), table, i);
                    else
                        AddCell(new PdfPCell(new Phrase(headers[i], font3b)), table, i);
                }
                else if (i == 9)
                {
                    if (((List<Stopover>)data[i]).Count > 0)
                        AddCell(new PdfPCell(new Phrase(headers[i], font3b)), table, i);
                }
                else
                {
                    s = Convert.ToString(data[i]);
                    AddCell(new PdfPCell(new Phrase(headers[i], font3b)), table, i);
                }
                FillData(i, s, data, table);
            }
        }

        private void FillData(int i, string s, object[] data, PdfPTable table)
        {
            if (i == 3)
            {
                List<Traveller> travellers = (List<Traveller>)data[i];
                Phrase p = new Phrase(string.Empty, font3b);
                foreach (Traveller t in travellers)
                {
                    p.Add(t.Name); p.Add(nwLn);
                }
                AddCell(new PdfPCell(p), table, i);
            }
            else if (i == 9)
            {
                List<Stopover> stopovers = (List<Stopover>)data[i];
                if (stopovers.Count > 0)
                {
                    Phrase p = new Phrase(string.Empty, font3b);
                    foreach (Stopover stopover in stopovers)
                    {
                        p.Add(stopover.ToStringDisplay()); p.Add(nwLn);
                    }
                    AddCell(new PdfPCell(p), table, i);
                }
            }
            else if (i == 12)
                AddCell(new PdfPCell(new Phrase(Helper.StripHTML(s), font3b)), table, i);
            else
                if (i != 1)
                    AddCell(new PdfPCell(new Phrase(s, font3b)), table, i);
        }

        internal byte[] CreateSmallPDF(string IDs)
        {
            byte[] result = null;
            try
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    iTextSharp.text.Rectangle rect = new iTextSharp.text.Rectangle(PageSize.A4.Width, PageSize.A4.Width / 2 + 40);
                    //iTextSharp.text.Rectangle rect = new iTextSharp.text.Rectangle(PageSize.A5.Height, PageSize.A5.Width);
                    Document document = new Document(rect, 0f, 20f, 0f, 0f);
                    PdfWriter writer = PdfWriter.GetInstance(document, ms);
                    document.AddTitle(Title);
                    document.AddSubject(Title);
                    document.AddCreator(Constants.Config[Constants.PDF_Title]);
                    document.AddAuthor(SPContext.Current.Web.CurrentUser.Name);
                    document.Open();
                    int teller = 0;
                    string[] IDarray = IDs.Split(Constants.Char_Star);
                    foreach (string ID in IDarray)
                    {
                        TaxiDetails taxidetails = TaxiAntwerpUtilities.GetTaxiDetailByID(ID);
                        CreateSmallHeader(document, taxidetails);
                        CreateSmallTopSection(document, taxidetails);
                        CreateSmallBottomSection(document, taxidetails);
                        teller++;
                        if (teller < IDarray.Length)
                            document.NewPage();
                    }
                    document.Close();
                    result = ms.GetBuffer();
                }
            }
            catch (Exception ex) { TaxiAntwerpUtilities.ThrowError(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), "Error creating small PDF (current user: " + SPContext.Current.Web.CurrentUser.Name + ")"); }
            return result;
        }

        private void CreateSmallHeader(Document document, TaxiDetails taxidetails)
        {
            PdfPTable tableheader = new PdfPTable(6);
            tableheader.WidthPercentage = 100;
            float[] tableheaderwidths = new float[] { 30f, 10f, 25f, 10f, 10f, 15f };
            tableheader.SetWidths(tableheaderwidths);
            tableheader.HorizontalAlignment = 0;
            Phrase headMon = new Phrase(string.Empty, font1);
            headMon.Add(string.Empty); headMon.Add(nwLn);
            headMon.Add(string.Empty); headMon.Add(nwLn);
            headMon.Add(string.Empty); headMon.Add(nwLn);
            headMon.Add(string.Empty); headMon.Add(nwLn);
            headMon.Add(string.Empty); headMon.Add(nwLn); headMon.Add(nwLn);
            PdfPCell headerCell1 = new PdfPCell(headMon);
            headerCell1.Border = 0;
            tableheader.AddCell(headerCell1);
            PdfPCell dummycell = new PdfPCell(new Phrase(string.Empty));
            dummycell.Border = 0;
            tableheader.AddCell(dummycell);
            PdfPCell headerCell2 = new PdfPCell(new Phrase(string.Empty));
            headerCell2.Border = 0;
            tableheader.AddCell(headerCell2);
            tableheader.AddCell(dummycell);
            Phrase headerBon = new Phrase();
            headerBon.Add(string.Empty); headerBon.Add(nwLn); headerBon.Add(nwLn);
            headerBon.Add(string.Empty);
            Paragraph prg = new Paragraph(headerBon);
            prg.Alignment = Element.ALIGN_RIGHT;
            PdfPCell headerCell4 = new PdfPCell(prg);
            headerCell4.Border = 0;
            tableheader.AddCell(headerCell4);
            Phrase headerBon2 = new Phrase();
            headerBon2.Add(taxidetails.BonNumber); headerBon2.Add(nwLn); headerBon2.Add(nwLn);
            headerBon2.Add(taxidetails.TravelDate.ToString(Constants.Config[Constants.DateFormat]));
            headerBon2.Add(nwLn);
            Paragraph prg2 = new Paragraph(headerBon2);
            prg2.Alignment = Element.ALIGN_RIGHT;
            PdfPCell headerCell5 = new PdfPCell(prg2);
            headerCell5.Border = 0;
            tableheader.AddCell(headerCell5);
            document.Add(tableheader);
        }

        private void CreateSmallTopSection(Document document, TaxiDetails taxidetails)
        {
            PdfPTable tablecontent = new PdfPTable(7);
            tablecontent.WidthPercentage = 100;
            float[] tablecontentwidths = new float[] { 20f, 10f, 20f, 10f, 13f, 13f, 13f };
            tablecontent.SetWidths(tablecontentwidths);
            tablecontent.HorizontalAlignment = 0;
            string[] contentheaders = new string[] { string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty };
            foreach (string s in contentheaders)
            {
                Phrase p = null;
                if (s.Equals("UUR vertr./aank."))
                {
                    p = new Phrase(string.Empty, font1);
                    p.Add(s.Split(' ')[0]); p.Add(nwLn);
                    p.Add(s.Split(' ')[1]);
                }
                else
                    p = new Phrase(s, font1);
                PdfPCell c = new PdfPCell(p);
                c.Border = 0;
                c.MinimumHeight = 20f;
                c.HorizontalAlignment = Element.ALIGN_LEFT;
                tablecontent.AddCell(c);
            }
            object[] contentdata = new object[] { taxidetails.CreatorName, "ADMIN", taxidetails.Travellers, taxidetails.Department, taxidetails.DepartureHour, taxidetails.DepartureCity, taxidetails.DestinationCity };
            FillSmallTopData(tablecontent, taxidetails, contentdata);
            document.Add(tablecontent);
        }

        private void FillSmallTopData(PdfPTable tablecontent, TaxiDetails taxidetails, object[] contentdata)
        {
            for (int i = 0; i < contentdata.Length; i++)
            {
                Phrase p = null;
                PdfPCell c = null;
                if (i != 2)
                {
                    string s = Convert.ToString(contentdata[i]);
                    if (s.Equals(taxidetails.CreatorName))
                    {
                        p = new Phrase(string.Empty, font2);
                        if (s.Contains(Constants.Char_Comma))
                        {
                            p.Add(s.Split(Constants.Char_Comma)[0]); p.Add(nwLn);
                            p.Add(s.Split(Constants.Char_Comma)[1].Trim().Split('[')[0]);
                            c = new PdfPCell(p);
                        }
                        else
                            c = new PdfPCell(new Phrase(s, font2));
                    }
                    else if (s.Equals(taxidetails.Department))
                        c = new PdfPCell(new Phrase(s, font2));
                    else
                        c = new PdfPCell(new Phrase(s, font2));
                }
                else
                {
                    List<Traveller> list = (List<Traveller>)contentdata[i];
                    p = new Phrase(string.Empty, font2);
                    foreach (Traveller s in list)
                    {
                        Phrase p2 = new Phrase();
                        if (s.Name.Contains(Constants.Char_Comma))
                        {
                            p2.Add(s.Name.Split(Constants.Char_Comma)[0]); p2.Add(nwLn);
                            p2.Add(s.Name.Split(Constants.Char_Comma)[1].Trim().Split('[')[0] + ','); p2.Add(nwLn);
                            p.Add(p2);
                        }
                        else
                            p.Add(s.Name);
                    }
                    c = new PdfPCell(p);
                }
                c.MinimumHeight = 80f;
                c.Rowspan = 3;
                c.Border = 0;
                tablecontent.AddCell(c);
            }
        }

        private void CreateSmallBottomSection(Document document, TaxiDetails taxidetails)
        {
            PdfPTable tablebottom = new PdfPTable(2);
            tablebottom.WidthPercentage = 100;
            float[] tablebottomwidths = new float[] { 53f, 47f };
            tablebottom.SetWidths(tablebottomwidths);
            tablebottom.HorizontalAlignment = 0;
            string[] bottomheaders = new string[] { string.Empty, string.Empty };
            foreach (string s in bottomheaders)
            {
                Phrase p = new Phrase(s, font1);
                PdfPCell c = new PdfPCell(p);
                c.MinimumHeight = 20f;
                c.Border = 0;
                tablebottom.AddCell(c);
            }
            FillSmallBottomData(tablebottom, taxidetails);
            PdfPCell tc = new PdfPCell(new Phrase(string.Empty));
            tc.Padding = 5f;
            tc.Rowspan = 3;
            tc.Border = 0;
            tablebottom.AddCell(tc);
            PdfPCell tbc2 = new PdfPCell(new Phrase("            " + taxidetails.CostCenter, font1));
            tbc2.Border = 0;
            PdfPCell tbc3 = new PdfPCell(new Phrase(string.Empty, font2));
            tbc3.Border = 0;
            tbc2.MinimumHeight = 20f; tbc3.MinimumHeight = 20f;
            tablebottom.AddCell(tbc2);
            tablebottom.AddCell(tbc3);
            tablebottom.AddCell(new PdfPCell(new Phrase()));
            document.Add(tablebottom);
        }

        private void FillSmallBottomData(PdfPTable tablebottom, TaxiDetails taxidetails)
        {
            PdfPCell tbc = new PdfPCell();
            tbc.Border = 0;
            if (!string.IsNullOrEmpty(taxidetails.DepartureAddress))
            {
                Phrase vertrek2 = new Phrase(string.Empty, font2);
                vertrek2.Add(Constants.Config[Constants.PDF_Small_Vertrek] + Constants.String_Whitespace + taxidetails.DepartureAddress);
                vertrek2.Add(nwLn);
                tbc.AddElement(vertrek2);
            }
            if (!string.IsNullOrEmpty(taxidetails.DestinationAddress))
            {
                Phrase aankomst2 = new Phrase(string.Empty, font2);
                aankomst2.Add(Constants.Config[Constants.PDF_Small_Aankomst] + Constants.String_Whitespace + taxidetails.DestinationAddress);
                aankomst2.Add(nwLn);
                tbc.AddElement(aankomst2);
            }
            if (taxidetails.Stopovers.Count > 0)
            {
                string stopover = string.Empty;
                Phrase stopover2 = new Phrase(string.Empty, font2);
                if (taxidetails.Stopovers.Count == 1)
                    stopover = Constants.Config[Constants.PDF_Small_Stopover] + Constants.String_Whitespace;
                else
                    stopover = Constants.Config[Constants.PDF_Small_Stopovers] + Constants.String_Whitespace;
                int counter = 0;
                StringBuilder sb = new StringBuilder();
                foreach (Stopover stop in taxidetails.Stopovers)
                {
                    if (counter == 0)
                        sb.AppendLine(stopover + stop.ToStringDisplay());
                    else
                        sb.AppendLine("           " + stop.ToStringDisplay());
                    counter++;
                }
                stopover2.Add(new Chunk(sb.ToString()));
                tbc.AddElement(stopover2);
            }
            if (!string.IsNullOrEmpty(taxidetails.Comment))
            {
                Phrase bi1 = new Phrase(Constants.Config[Constants.PDF_Small_Info], font1);
                tbc.AddElement(bi1);
                Phrase bi2 = new Phrase(string.Empty, font2);
                bi2.Add(taxidetails.Comment); bi2.Add(nwLn);
                tbc.AddElement(bi2);
            }
            tbc.MinimumHeight = 100f;
            tablebottom.AddCell(tbc);
        }
    }
    public static class Helper
    {
        private const string htmlRegex = "<.*?>";

        public static string StripHTML(string inputString)
        {
            return Regex.Replace(inputString, htmlRegex, Constants.String_Whitespace);
        }

        public static IEnumerable<string> SplitOnLength(this string input, int length)
        {
            var words = input.Split(new[] { Constants.String_Whitespace, }, StringSplitOptions.None);
            var result = words.First();
            foreach (var word in words.Skip(1))
            {
                if (result.Length + word.Length > length)
                {
                    yield return result;
                    result = word;
                }
                else
                {
                    result += Constants.String_Whitespace + word;
                }
            }
            yield return result;
        }
    }
}