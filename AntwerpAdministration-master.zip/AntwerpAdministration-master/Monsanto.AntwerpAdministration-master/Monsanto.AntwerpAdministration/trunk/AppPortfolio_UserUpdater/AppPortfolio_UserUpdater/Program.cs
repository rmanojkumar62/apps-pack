﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Client;
using System.Net;
using System.Threading;
using System.IO;
using System.Xml;

namespace AppPortfolio_UserUpdater
{
    class Program
    {
        private static string listname = "Application Portfolio List";
        private static string sourceURL = "http://teamsites.monsanto.com/private/itsopm";
        private static string PRODdestinationURL = "http://spapps.monsanto.com/enterprise/antwerpadministration";

        //UPDATE USER DETAILS BELOW
        private static string user = "mverc";
        private static string password = "";
        private static string domain = "EUROPE-AFRICA";
        
        static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("--- APP PORTFOLIO DATA MIGRATION LOG ---");
            Console.WriteLine("Starting APP PORTFOLIO migration...");
            GetSourceItems(sb);
            sb.AppendLine("--- COMPLETED ---");
            Console.WriteLine("Completed!");
            WriteLog(sb);
            EndProgram();
        }

        static void GetSourceItems(StringBuilder sb)
        {
            using (ClientContext clientContext = new ClientContext(sourceURL))
            {
                var credentials = new NetworkCredential(user, password, domain);
                clientContext.Credentials = credentials;
                clientContext.RequestTimeout = Timeout.Infinite;
                Web rootWeb = clientContext.Web;
                clientContext.Load(rootWeb);
                try
                {
                    clientContext.ExecuteQuery();
                }
                catch (Exception ex)
                {
                    sb.AppendLine("ERROR - Executing query - main - rootweb");
                    Console.WriteLine("ERROR - Executing query - main - rootweb");
                }
                CamlQuery caml = new CamlQuery();
                caml.ViewXml = "<View Scope='RecursiveAll'/>";
                ListItemCollection items = clientContext.Web.Lists.GetByTitle(listname).GetItems(caml);
                clientContext.Load(items);
                try
                {
                    clientContext.ExecuteQuery();
                }
                catch (Exception ex)
                {
                    sb.AppendLine("ERROR - Executing query - main - getlistdata");
                    Console.WriteLine("ERROR - Executing query - main - getlistdata");
                }
                int teller = 0;
                foreach (ListItem item in items)
                {
                    sb.AppendLine("Start procedure for listitem " + item.Id);
                    Console.WriteLine("ListItem " + item.Id);
                    Console.WriteLine();
                    sb.AppendLine("Getting item data ...");
                    Console.WriteLine("Getting item data ...");
                    AppPortfolioItem tl = GetItemData(clientContext, sb, item);
                    Console.WriteLine("Getting item data DONE");
                    sb.AppendLine("Getting item data DONE");
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("Start copying item " + tl.ID + "...");
                    Console.WriteLine();
                    CopyItem(sb, tl);
                    Console.WriteLine("DONE");
                    sb.AppendLine("DONE");
                    Console.WriteLine();
                    Console.WriteLine();
                    teller++;
                }
            }
        }

        static AppPortfolioItem GetItemData(ClientContext ctx, StringBuilder sb, ListItem item)
        {
            AppPortfolioItem tl = new AppPortfolioItem();
            tl.ID = item.Id;
            List<string> itowner = GetUsernames(ctx, sb, tl.ID, item, "IT_x0020_Owner", false);
            List<string> businessowner = GetUsernames(ctx, sb, tl.ID, item, "Business_x0020_Owner", true);
            List<string> dataowner = GetUsernames(ctx, sb, tl.ID, item, "Data_x0020_Owner", true);
            List<string> othercontacts = GetUsernames(ctx, sb, tl.ID, item, "Other_x0020_IT_x0020_Contacts", true);
            tl.ITOwner = itowner;
            tl.BusinessOwner = businessowner;
            tl.DataOwner = dataowner;
            tl.OtherITContacts = othercontacts;
            return tl;
        }

        static string LookupLoginNameInUserInfoList(ClientContext context, StringBuilder sb, int sourceitemid, int lookupId)
        {
            var username = string.Empty;
            var userInfoList = context.Web.SiteUserInfoList;
            context.Load(userInfoList);
            ListItem item = userInfoList.GetItemById(lookupId);
            context.Load(item);
            try
            {
                context.ExecuteQuery();
                username = item["Name"] as string;
            }
            catch (Exception ex)
            {
                sb.AppendLine("ERROR - Executing query - LookupLoginNameInUserInfoList - SOURCE ITEM ID " + sourceitemid);
                Console.WriteLine("ERROR - Executing query - LookupLoginNameInUserInfoList - SOURCE ITEM ID " + sourceitemid);
            }
            return username;
        }

        static List<string> GetUsernames(ClientContext ctx, StringBuilder sb, int sourceitemid, ListItem item, string fieldname, bool isMultiple)
        {
            List<string> usernames = new List<string>();
            if (isMultiple)
            {
                FieldUserValue[] fuvs = (FieldUserValue[])item[fieldname];
                if (fuvs != null)
                {
                    foreach (FieldUserValue fuv in fuvs)
                    {
                        string fuvusername = string.Empty;
                        if (fuv != null)
                        {
                            fuvusername = LookupLoginNameInUserInfoList(ctx, sb, sourceitemid, fuv.LookupId);
                            if (!string.IsNullOrEmpty(fuvusername))
                                usernames.Add(fuvusername);
                        }
                    }
                }
            }
            else
            {
                FieldUserValue fuv = (FieldUserValue)item[fieldname];
                if (fuv != null)
                {
                    string fuvusername = string.Empty;
                    if (fuv != null)
                    {
                        fuvusername = LookupLoginNameInUserInfoList(ctx, sb, sourceitemid, fuv.LookupId);
                        if (!string.IsNullOrEmpty(fuvusername))
                            usernames.Add(fuvusername);
                    }
                }
            }
            return usernames;
        }

        static List<FieldUserValue> GetUsers(StringBuilder sb, ClientContext ctx, int ID, string field, List<string> usernames)
        {
            if (usernames.Count > 0)
            {
                List<FieldUserValue> fuvs = new List<FieldUserValue>();
                foreach (string username in usernames)
                {
                    FieldUserValue fuv = new FieldUserValue();
                    User user = ctx.Web.EnsureUser(username);
                    ctx.Load(user);
                    try
                    {
                        ctx.ExecuteQuery();
                        fuv.LookupId = user.Id;
                        fuvs.Add(fuv);
                    }
                    catch (Exception ex)
                    {
                        string userID = ResolvePrincipal(sb, username);
                        if (!string.IsNullOrEmpty(userID))
                        {
                            if (userID != "-1")
                            {
                                fuv.LookupId = Convert.ToInt32(userID);
                                fuvs.Add(fuv);
                            }
                            else
                            {
                                sb.AppendLine("ERROR - User " + username + " not found --- Item ID:" + ID + " --- FIELD:" + field);
                                Console.WriteLine("ERROR - User " + username + " not found");
                            }
                        }
                        else
                        {
                            sb.AppendLine("ERROR - User " + username + " not found --- Item ID:" + ID + " --- FIELD:" + field);
                            Console.WriteLine("ERROR - User " + username + " not found");
                        }
                    }
                }
                return fuvs;
            }
            return null;
        }

        private static void CopyItem(StringBuilder sb, AppPortfolioItem tl)
        {
            using (ClientContext clientContext = new ClientContext(PRODdestinationURL))
            {
                var credentials = new NetworkCredential(user, password, domain);
                clientContext.Credentials = credentials;
                clientContext.RequestTimeout = Timeout.Infinite;
                Web rootWeb = clientContext.Web;
                clientContext.Load(rootWeb);
                clientContext.ExecuteQuery();
                List list = clientContext.Web.Lists.GetByTitle(listname);
                clientContext.Load(list);
                clientContext.ExecuteQuery();
                Console.WriteLine("");
                ListItem oListItem = list.GetItemById(tl.ID);
                clientContext.Load(oListItem);
                clientContext.ExecuteQuery();
                List<FieldUserValue> fuvitownerlist = GetUsers(sb, clientContext, tl.ID, "IT_x0020_Owner", tl.ITOwner);
                if (fuvitownerlist != null)
                {
                    if (fuvitownerlist.Count > 0)
                    {
                        FieldUserValue[] fuvitowner = fuvitownerlist.ToArray();
                        oListItem["IT_x0020_Owner"] = fuvitowner[0];
                        oListItem.Update();
                        clientContext.ExecuteQuery();
                    }
                }
                List<FieldUserValue> fuvbusinessownerlist = GetUsers(sb, clientContext, tl.ID, "Business_x0020_Owner", tl.BusinessOwner);
                if (fuvbusinessownerlist != null)
                {
                    if (fuvbusinessownerlist.Count > 0)
                    {
                        oListItem["Business_x0020_Owner"] = fuvbusinessownerlist.ToArray();
                        oListItem.Update();
                        clientContext.ExecuteQuery();
                    }
                }
                List<FieldUserValue> fuvdataownerlist = GetUsers(sb, clientContext, tl.ID, "Data_x0020_Owner", tl.DataOwner);
                if (fuvdataownerlist != null)
                {
                    if (fuvdataownerlist.Count > 0)
                    {
                        oListItem["Data_x0020_Owner"] = fuvdataownerlist.ToArray();
                        oListItem.Update();
                        clientContext.ExecuteQuery();
                    }
                }
                List<FieldUserValue> fuvotherlist = GetUsers(sb, clientContext, tl.ID, "Other_x0020_IT_x0020_Contacts", tl.OtherITContacts);
                if (fuvotherlist != null)
                {
                    if (fuvotherlist.Count > 0)
                    {
                        oListItem["Other_x0020_IT_x0020_Contacts"] = fuvotherlist.ToArray();
                        oListItem.Update();
                        clientContext.ExecuteQuery();
                    }
                }
                oListItem.Update();
                clientContext.ExecuteQuery();
            }
        }
        
        static string ResolvePrincipal(StringBuilder sb, string username)
        {
            WebRequest webRequest = WebRequest.Create(PRODdestinationURL + "_vti_bin/People.asmx");
            HttpWebRequest httpRequest = (HttpWebRequest)webRequest;
            httpRequest.Method = "POST";
            httpRequest.ContentType = "text/xml; charset=utf-8";
            httpRequest.Accept = "text/xml";
            httpRequest.Headers.Add("SOAPAction", "http://schemas.microsoft.com/sharepoint/soap/ResolvePrincipals");
            httpRequest.ProtocolVersion = HttpVersion.Version11;
            httpRequest.KeepAlive = false;
            httpRequest.Credentials = CredentialCache.DefaultCredentials;
            Stream requestStream = httpRequest.GetRequestStream();
            StreamWriter streamWriter = new StreamWriter(requestStream, Encoding.ASCII);
            StringBuilder soapRequest = new StringBuilder();
            soapRequest.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            soapRequest.AppendLine("<soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>");
            soapRequest.AppendLine("<soap:Body>");
            soapRequest.AppendLine("<ResolvePrincipals xmlns=\"http://schemas.microsoft.com/sharepoint/soap/\">");
            soapRequest.AppendLine("<principalKeys>");
            soapRequest.AppendLine("<string>" + username + "</string>");
            soapRequest.AppendLine("</principalKeys>");
            soapRequest.AppendLine("<principalType>User</principalType>");
            soapRequest.AppendLine("<addToUserInfoList>true</addToUserInfoList>");
            soapRequest.AppendLine("</ResolvePrincipals>");
            soapRequest.AppendLine("</soap:Body>");
            soapRequest.AppendLine("</soap:Envelope>");
            streamWriter.Write(soapRequest.ToString());
            streamWriter.Close();
            HttpWebResponse wr = null;
            HttpStatusCode statuscode;
            try
            {
                wr = (HttpWebResponse)httpRequest.GetResponse();
                statuscode = wr.StatusCode;
            }
            catch (WebException we)
            {
                statuscode = ((HttpWebResponse)we.Response).StatusCode;
            }
            //IF STATUSCODE ==200 or OK => PROCEED
            Stream srd = wr.GetResponseStream();
            XmlDocument doc = new XmlDocument();
            doc.Load(srd);
            XmlNodeList nodes = doc.GetElementsByTagName("UserInfoID");
            if (nodes != null)
            {
                if (nodes.Count > 0)
                {
                    sb.AppendLine("Resolve principal successful");
                    Console.WriteLine("Resolve principal successful");
                    return nodes[0].InnerText;
                }
            }
            return string.Empty;
        }

        private static void EndProgram()
        {
            Console.WriteLine("Press enter to exit the application");
            Console.ReadLine();
        }

        private static void WriteLog(StringBuilder sb)
        {
            try
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter("c:\\PROD-AppPortfolioDataMigrationLOG.txt"))
                {
                    file.Write(sb);
                }
            }
            catch (Exception ex) { Console.WriteLine("Something went wrong when creating log file! {0} - {1}", ex.Message, ex.StackTrace); }
        }
    }

    public class AppPortfolioItem
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public List<string> ITOwner { get; set; }
        public List<string> BusinessOwner { get; set; }
        public List<string> DataOwner { get; set; }
        public List<string> OtherITContacts { get; set; }

        public AppPortfolioItem() { }
    }
}
