﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WeeklyMeeting
{
    public class Constants
    {
        #region FIXED CONSTANTS
        public const string Mode_New = "new";
        public const string Mode_Display = "display";
        public const string Mode_Edit = "edit";
        public const string StrIsDlg = "IsDlg";
        public const string StrIsDlgValue = "1";
        public const string StrIsDlgClose_OK="SP.UI.ModalDialog.commonModalDialogClose(1,1);";
        public const string StrIsDlgClose_Cancel = "SP.UI.ModalDialog.commonModalDialogClose(0,0);";
        public const string NewFormID = "-1";
        public const string NewFormStatus = "New";
        public const string QueryStringMode = "mode";
        public const string QueryStringID="ID";
        public const string QueryStringFormID = "FORMID";
        public const string QueryStringItemIDS = "ITEMIDS";
        public const string QueryStringListID = "LISTID";
        public const string QueryStringSource = "SOURCE";
        public const string TopicCtrlPrefix = "tctrl_";
        public const string TopicCtrl = @"~/_CONTROLTEMPLATES/Monsanto.WeeklyMeeting/TopicControl.ascx";
        public const string TopicLabel = "lblTopic";
        public const string TopicID = "HiddenTopicID";
        public const string TopicPriority = "HiddenTopicPriority";
        public const string TopicBox = "txtAgendaItems";
        public const string TopicPanel = "pnlTopics";
        public const string List_Configuration = "Configuration";
        public const string Col_Value = "Value";
        public const string Col_ID = "ID";
        public const string Col_Title = "Title";
        public const string Col_Department = "Afdeling";
        public const string Col_DepartmentID = "AfdelingID";
        public const string Col_Data = "Data";
        public const string Col_Author = "Author";
        public const string Col_Priority = "Priority";
        public const string Col_Responsible = "Responsible";
        public const string Col_Status = "Status";
        public const string Col_LinkFilename = "LinkFilename";
        public const string Mail_HTMLHEADER="[HTMLHEADER]";
        public const string WORD_DefaultFont = "Arial";
        #endregion

        #region CONFIGURABLE CONSTANTS
        public const string Mail_SendExportMail = "Mail_SendExportMail";
        public const string Mail_MonsantoSMTP = "Mail_MonsantoSMTP";
        public const string Mail_WeeklyMeetingEmail = "Mail_WeeklyMeetingEmail";
        public const string Mail_HTML_Header1 = "Mail_HTML_Header1";
        public const string Mail_HTML_Header2 = "Mail_HTML_Header2";
        public const string Mail_HTML_Header3 = "Mail_HTML_Header3";
        public const string DateTimeFormat = "DateTimeFormat";
        public const string DateFormat = "DateFormat";
        public const string DateFormat_Mail = "DateFormat_Mail";
        public const string DateFormat_Word = "DateFormat_Word";
        public const string CAML_Departments = "CAML_Departments";
        public const string CAML_Department = "CAML_Department";
        public const string CAML_Topics = "CAML_Topics";
        public const string CAML_Templates = "CAML_Templates";
        public const string CAML_Templates_Viewfields = "CAML_Templates_Viewfields";
        public const string CAML_Documents = "CAML_Documents";
        public const string CAML_Documents_Viewfields = "CAML_Documents_Viewfields";
        public const string List_AgendaItems = "List_AgendaItems";
        public const string List_Departments = "List_Departments";
        public const string List_Topics = "List_Topics";
        public const string Lib_Templates = "Lib_Templates";
        public const string Lib_Documents = "Lib_Documents";
        public const string Label_OverviewHeader = "Label_OverviewHeader";
        public const string Label_FormHeader = "Label_FormHeader";
        public const string Label_Department = "Label_Department";
        public const string Label_Status = "Label_Status";
        public const string Btn_New_Input = "Btn_New_Input";
        public const string Btn_Create_Report = "Btn_Create_Report";
        public const string Btn_Save = "Btn_Save";
        public const string Btn_Edit = "Btn_Edit";
        public const string Btn_Cancel = "Btn_Cancel";
        public const string Btn_CloseConfirmation = "Btn_CloseConfirmation";
        public const string Message_DepartmentSelect = "Message_DepartmentSelect";
        public const string Message_Confirmation_Form = "Message_Confirmation_Form";
        public const string Message_Confirmation_Export = "Message_Confirmation_Export";
        public const string Message_No_Items = "Message_No_Items";
        public const string StrMeetingPrefix = "StrMeetingPrefix";
        public const string StrDocExtension = "StrDocExtension";
        public const string WORD_Header = "WORD_Header";
        public const string DocHeader_BasedOn = "DocHeader_BasedOn";
        public const string DocHeader_NextParagraphStyle="DocHeader_NextParagraphStyle";
        public const string DocHeader_Color="DocHeader_Color";
        public const string DocHeader_Font="DocHeader_Font";
        public const string DocHeader_FontSize="DocHeader_FontSize";
        public const string DocHeader_Prefix="DocHeader_Prefix";
        public const string TopicHeading_BasedOn="TopicHeading_BasedOn";
        public const string TopicHeading_NextParagraphStyle="TopicHeading_NextParagraphStyle";
        public const string TopicHeading_Color="TopicHeading_Color";
        public const string TopicHeading_Font="TopicHeading_Font";
        public const string TopicHeading_FontSize="TopicHeading_FontSize";
        public const string TopicHeading_Prefix="TopicHeading_Prefix";
        public const string DepartmentHeading_BasedOn = "DepartmentHeading_BasedOn";
        public const string DepartmentHeading_NextParagraphStyle = "DepartmentHeading_NextParagraphStyle";
        public const string DepartmentHeading_Color = "DepartmentHeading_Color";
        public const string DepartmentHeading_Font = "DepartmentHeading_Font";
        public const string DepartmentHeading_FontSize = "DepartmentHeading_FontSize";
        public const string DepartmentHeading_Prefix = "DepartmentHeading_Prefix";

        public const string FontAwesomeCDN = "FontAwesomeCDN";
        public const string BootstrapCssCDN = "BootstrapCssCDN";
        public const string BootstrapCssThemeCDN = "BootstrapCssThemeCDN";
        public const string BootstrapScriptCDN = "BootstrapScriptCDN";
        public const string Dlg_CloseFunction = "Dlg_CloseFunction";
        public const string Form_EditURL = "Form_EditURL";
        public const string Form_NewURL = "Form_NewURL";
        public const string Form_ExportURL = "Form_ExportURL";
        public const string Grid_ImgURL = "Grid_ImgURL";
        #endregion

        public const string TopicXML = "/ArrayOfFormTopic/FormTopic";
        public const string TopicXML_ID = "ID";
        public const string TopicXML_Name = "Name";
        public const string TopicXML_Priority = "Priority";
        public const string TopicXML_AgendaItems = "AgendaItems";

        public static Dictionary<string, string> _Config;
        public static Dictionary<string, string> Config
        {
            get
            {
                if (_Config == null)
                    _Config = MeetingUtilities.GetConfigValues();
                return _Config;
            }
        }

        private Constants() { }
    }
}