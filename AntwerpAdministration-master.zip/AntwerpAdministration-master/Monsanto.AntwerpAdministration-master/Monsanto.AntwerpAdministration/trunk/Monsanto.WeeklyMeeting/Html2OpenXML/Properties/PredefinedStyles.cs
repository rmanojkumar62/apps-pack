﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WeeklyMeeting.Html2OpenXML.Properties
{
    public class PredefinedStyles
    {
        public static string GetString(string className)
        {
            string headstyle=string.Empty;
            switch (className.ToUpper())
            {
                case "HEADING 1":
                    headstyle = Heading_1;
                    break;
                case "HEADING 2":
                    headstyle = Heading_2;
                    break;
                case "HEADING 3":
                    headstyle = Heading_3;
                    break;
                case "HEADING 4":
                    headstyle = Heading_4;
                    break;
                case "HEADING 5":
                    headstyle = Heading_5;
                    break;
                case "HEADING 6":
                    headstyle = Heading_6;
                    break;
            }
            return headstyle;
        }

        public static string Caption
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:b /><w:bCs /><w:color w:val=\"4F81BD\" w:themeColor=\"accent1\" /><w:sz w:val=\"18\" /><w:szCs w:val=\"18\" /></w:rPr>";
            }
        }

        public static string Heading_1
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:rFonts w:asciiTheme=\"majorHAnsi\" w:hAnsiTheme=\"majorHAnsi\" w:eastAsiaTheme=\"majorEastAsia\" w:cstheme=\"majorBidi\" /><w:b /><w:bCs /><w:color w:val=\"365F91\" w:themeColor=\"accent1\" w:themeShade=\"BF\" /><w:sz w:val=\"28\" /><w:szCs w:val=\"28\" /></w:rPr>";
            }
        }

        public static string Heading_2
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:rFonts w:asciiTheme=\"majorHAnsi\" w:hAnsiTheme=\"majorHAnsi\" w:eastAsiaTheme=\"majorEastAsia\" w:cstheme=\"majorBidi\" /><w:b /><w:bCs /><w:color w:val=\"4F81BD\" w:themeColor=\"accent1\" /><w:sz w:val=\"26\" /><w:szCs w:val=\"26\" /></w:rPr>";
            }
        }

        public static string Heading_3
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:rFonts w:asciiTheme=\"majorHAnsi\" w:hAnsiTheme=\"majorHAnsi\" w:eastAsiaTheme=\"majorEastAsia\" w:cstheme=\"majorBidi\" /><w:b /><w:bCs /><w:color w:val=\"4F81BD\" w:themeColor=\"accent1\" /></w:rPr>";
            }
        }

        public static string Heading_4
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:rFonts w:asciiTheme=\"majorHAnsi\" w:hAnsiTheme=\"majorHAnsi\" w:eastAsiaTheme=\"majorEastAsia\" w:cstheme=\"majorBidi\" /><w:b /><w:bCs /><w:i /><w:iCs /><w:color w:val=\"4F81BD\" w:themeColor=\"accent1\" /></w:rPr>";
            }
        }

        public static string Heading_5
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:rFonts w:asciiTheme=\"majorHAnsi\" w:hAnsiTheme=\"majorHAnsi\" w:eastAsiaTheme=\"majorEastAsia\" w:cstheme=\"majorBidi\" /><w:color w:val=\"243F60\" w:themeColor=\"accent1\" w:themeShade=\"7F\" /></w:rPr>";
            }
        }

        public static string Heading_6
        {
            get
            {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:rFonts w:asciiTheme=\"majorHAnsi\" w:hAnsiTheme=\"majorHAnsi\" w:eastAsiaTheme=\"majorEastAsia\" w:cstheme=\"majorBidi\" /><w:i /><w:iCs /><w:color w:val=\"243F60\" w:themeColor=\"accent1\" w:themeShade=\"7F\" /></w:rPr>";
            }
        }

        public static string HyperLink
        {
            get {
                return "<w:rPr xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:color w:val=\"0000FF\" w:themeColor=\"hyperlink\" /><w:u w:val=\"single\" /></w:rPr>";
                }
        }
    }
}
