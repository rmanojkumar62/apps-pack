﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Monsanto.WeeklyMeeting
{
    [Serializable]
    [XmlType("FormTopic")]
    public class FormTopic
    {
        [XmlElement("ID")]
        public int ID { get; set; }
        [XmlElement("Name")]
        public string Name { get; set; }
        [XmlElement("Priority")]
        public string Priority { get; set; }
        [XmlElement("AgendaItems")]
        public string AgendaItems { get; set; }

        public FormTopic() { }

        public FormTopic(int ID,string Name,string Priority, string AgendaItems)
        {
            this.ID = ID;
            this.Name = Name;
            this.Priority = Priority;
            this.AgendaItems = AgendaItems;
        }
    }

    public class Topic
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Priority { get; set; }

        public Topic() { }

        public Topic(int ID, string Name, string Priority)
        {
            this.ID = ID;
            this.Name = Name;
            this.Priority = Priority;
        }
    }

    public class Department
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int ResponsibleID { get; set; }
        public string ResponsibleName { get; set; }
        public string ResponsibleLogin { get; set; }
        
        public Department() { }

        public Department(int ID, string Name, int ResponsibleID, string ResponsibleName, string ResponsibleLogin)
        {
            this.ID = ID;
            this.Name = Name;
            this.ResponsibleID = ResponsibleID;
            this.ResponsibleName = ResponsibleName;
            this.ResponsibleLogin = ResponsibleLogin;
        }
    }

    public class AgendaItem
    {
        public Topic Topic { get; set; }
        public string Department { get; set; }
        public int ResponsibleID { get; set; }
        public string ResponsibleName { get; set; }
        public string ResponsibleLogin { get; set; }
        public string CreatedBy { get; set; }
        public string Item { get; set; }

        public AgendaItem() { }

        public AgendaItem(Topic Topic, string Department, int ResponsibleID, string ResponsibleName, string ResponsibleLogin, string CreatedBy, string Item)
        {
            this.Topic = Topic;
            this.Department = Department;
            this.ResponsibleID = ResponsibleID;
            this.ResponsibleName = ResponsibleName;
            this.ResponsibleLogin = ResponsibleLogin;
            this.CreatedBy = CreatedBy;
            this.Item = Item;
        }
    }
}
