﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using System.Xml.Serialization;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using System.Reflection;

namespace Monsanto.WeeklyMeeting
{
    public class MeetingUtilities
    {
        public static Dictionary<string, string> GetConfigValues()
        {
            Dictionary<string, string> configValues = new Dictionary<string, string>();
            try
            {
                SPList config = SPContext.Current.Web.Lists.TryGetList(Constants.List_Configuration);
                foreach (SPListItem item in config.GetItems())
                    if (!configValues.ContainsKey(Convert.ToString(item[Constants.Col_Title])))
                        configValues.Add(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_Value]));
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return configValues;
        }

        public static void GetDepartments(DropDownList dropdown,string selectmessage)
        {
            try
            {
                dropdown.Items.Add(new ListItem(selectmessage, "0"));
                SPQuery q = new SPQuery();
                q.Query = Constants.Config[Constants.CAML_Departments];
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Departments]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    string title = Convert.ToString(item[Constants.Col_Title]);
                    dropdown.Items.Add(new ListItem(title, title));
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        public static Department GetDepartment(string department)
        {
            try
            {
                SPQuery q = new SPQuery();
                q.Query = string.Format(Constants.Config[Constants.CAML_Department],department);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Departments]).GetItems(q);
                if (items.Count > 0)
                {
                    int afdelingID = items[0].ID;
                    string afdelingname = Convert.ToString(items[0][Constants.Col_Title]);
                    SPFieldUser spfu = (SPFieldUser)items[0].Fields.GetField(Constants.Col_Responsible);
                    SPFieldUserValue spfuv = (SPFieldUserValue)spfu.GetFieldValue(items[0][Constants.Col_Responsible].ToString());
                    SPUser user = spfuv.User;
                    return new Department(afdelingID, afdelingname,user.ID,user.Name,user.LoginName);
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return null;
        }

        public static List<Topic> GetTopics()
        {
            List<Topic> topics = new List<Topic>();
            try
            {
                SPQuery q = new SPQuery();
                q.Query = Constants.Config[Constants.CAML_Topics];
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Topics]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    Topic topic = new Topic();
                    topic.Name = Convert.ToString(item[Constants.Col_Title]);
                    topic.Priority = Convert.ToString(item[Constants.Col_Priority]);
                    topic.ID = item.ID;
                    topics.Add(topic);
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return topics;
        }

        /*public static Topic GetTopicByName(List<Topic> topics, string name)
        {
            return topics.Where(n => n.Name.Equals(name)).First();
        }*/

        public static string DataToXML(List<FormTopic> topiccollection)
        {
            string xmloutput = string.Empty;
            try
            {
                var stringwriter = new System.IO.StringWriter();
                Type[] types = { typeof(FormTopic) };
                XmlSerializer serializer = new XmlSerializer(typeof(List<FormTopic>), types);
                serializer.Serialize(stringwriter, topiccollection);
                xmloutput= stringwriter.ToString();
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return xmloutput;
        }

        public static List<FormTopic> XMLToData(string dataXML)
        {
            List<FormTopic> list = new List<FormTopic>();
            try
            {
                using (XmlReader reader = XmlReader.Create(new StringReader(dataXML)))
                {
                    Type[] types = { typeof(FormTopic) };
                    XmlSerializer serializer = new XmlSerializer(typeof(List<FormTopic>), types);
                    list = (List<FormTopic>)serializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return list;
        }

        public static string StripHTML(string input)
        {
            string output = Regex.Replace(input, "<.*?>", String.Empty);
            output = Regex.Replace(output, @"\s+", String.Empty);
            return output;
        }

        public static string ConvertToTable(string data)
        {
            data = Regex.Replace(data, @"\t|\n|\r", "");
            data = data.Replace("</li><ul>", "</td></tr><tr><td valign='top' colSpan='3'><table cellpadding='0' cellspacing='0' style='padding-left:20px;font-family: Verdana, sans-serif; font-size: 10pt;'>");
            data = data.Replace("</ul><li>", "</table></td></tr><tr><td width='5' align='center' valign='top'>&bull;</td><td width='15'></td><td valign='top'>");
            data = data.Replace("<ul>", "<table cellpadding='0' cellspacing='0' style='font-family: Verdana, sans-serif; font-size: 10pt;'>");
            data = data.Replace("</ul>", "</table>");
            data = data.Replace("<li>", "<tr><td width='5' align='center' valign='top'>&bull;</td><td width='15'></td><td valign='top'>");
            data = data.Replace("</li>", "</td></tr>");
            return data;
        }

        public static string CreateValidNestedLists(string input)
        {
            input = input.Replace("</li><ul>", "</li><li><ul>");
            input = input.Replace("</ul><li>", "</ul></li><li>");
            return input;
        }

        public static List<AgendaItem> GetAgendaItems(string listID,string[] itemIDS)
        {
            List<AgendaItem> agendaItems = new List<AgendaItem>();
            SPList list = null;
            try
            {

                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                {
                    using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                    {
                        list = web.Lists[new Guid(listID)];
                        foreach (string id in itemIDS)
                        {
                            var listItem = list.GetItemById(Int32.Parse(id));
                            string department = Convert.ToString(listItem[Constants.Col_Department]);
                            SPFieldUser spfu = (SPFieldUser)listItem.Fields.GetField(Constants.Col_Responsible);
                            SPFieldUserValue spfuv = (SPFieldUserValue)spfu.GetFieldValue(listItem[Constants.Col_Responsible].ToString());
                            SPUser user = spfuv.User;
                            int responsibleID = user.ID;
                            string responsibleName = user.Name;
                            string responsibleLogin = user.LoginName;
                            string data = Convert.ToString(listItem[Constants.Col_Data]);
                            string author = Convert.ToString(listItem[Constants.Col_Author]).Split('#')[1];
                            using (XmlReader reader = XmlReader.Create(new StringReader(data)))
                            {
                                XmlDocument xmldoc = new XmlDocument();
                                xmldoc.Load(reader);
                                XmlNodeList nodes = xmldoc.DocumentElement.SelectNodes(Constants.TopicXML);
                                foreach (XmlNode node in nodes)
                                {
                                    int topicID = Convert.ToInt32(node.SelectSingleNode(Constants.TopicXML_ID).InnerText);
                                    string topicName = node.SelectSingleNode(Constants.TopicXML_Name).InnerText;
                                    string topicPriority = node.SelectSingleNode(Constants.TopicXML_Priority).InnerText;
                                    string agendaitems = node.SelectSingleNode(Constants.TopicXML_AgendaItems).InnerText;
                                    AgendaItem agendaItem = new AgendaItem();
                                    agendaItem.Item = agendaitems;
                                    //agendaItem.Topic = MeetingUtilities.GetTopicByName(topics,topicname);
                                    agendaItem.Topic = new Topic(topicID, topicName, topicPriority);
                                    agendaItem.Department = department;
                                    agendaItem.ResponsibleID = responsibleID;
                                    agendaItem.ResponsibleName = responsibleName;
                                    agendaItem.ResponsibleLogin = responsibleLogin;
                                    agendaItem.CreatedBy = author;
                                    agendaItems.Add(agendaItem);
                                }
                            }
                            agendaItems = agendaItems.OrderBy(a => a.Topic.Priority).ThenBy(a => a.ResponsibleName).ThenBy(a => a.Department).ToList();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return agendaItems;
        }

        public static void UpdateAgendaItems(string[] itemIDS, string listID)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Web.CurrentUser.UserToken))
                {
                    using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                    {
                        SPList list = web.Lists[new Guid(listID)];
                        foreach (string itemID in itemIDS)
                        {
                            try
                            {
                                web.AllowUnsafeUpdates = true;
                                SPListItem item = list.GetItemById(int.Parse(itemID));
                                item[Constants.Col_Status] = "ReadyForHiding";
                                item.Update();
                            }
                            catch (Exception ex)
                            {
                                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                            }
                            finally
                            {
                                web.AllowUnsafeUpdates = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        public static bool HasAdminPermission()
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;
                return currentWeb.UserIsWebAdmin || currentWeb.UserIsSiteAdmin || currentWeb.DoesUserHavePermissions(SPBasePermissions.FullMask);
            }
            catch (SPException ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return false;
        }

        public static string GetMailTemplate()
        {
            string body = string.Empty;
            string mailtemplatepath = string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Main"]);
            try
            {
                SPFile file = SPContext.Current.Web.GetFile(mailtemplatepath);
                using (Stream filestream = file.OpenBinaryStream())
                {
                    using (StreamReader reader = new StreamReader(filestream))
                    {
                        body = reader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return body;
        }
    }
}