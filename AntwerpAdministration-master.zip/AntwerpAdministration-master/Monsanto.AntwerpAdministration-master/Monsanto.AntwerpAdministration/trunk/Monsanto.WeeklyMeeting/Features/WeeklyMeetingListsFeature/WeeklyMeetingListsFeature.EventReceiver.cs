using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using System.Reflection;

namespace Monsanto.WeeklyMeeting.Features.WeeklyMeetingListsFeature
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("e1430811-ce68-486e-bb55-101b8382f95f")]
    public class WeeklyMeetingListsFeatureEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        //public override void FeatureActivated(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            string[] lists = new string[] { "Agenda Items", "Configuration", "Topics", "Departments", "Templates", "Reports" };
            SPWeb web = null;
            try
            {
                web = properties.Feature.Parent as SPWeb;
                foreach (string listname in lists)
                {
                    SPList list = web.Lists.TryGetList(listname);
                    if (list != null)
                    {
                        list.OnQuickLaunch = false;
                        list.Delete();
                        //web.Lists.Delete(list.ID);
                    }
                }
                web.Update();
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            finally
            {
                if (web != null)
                    web.Dispose();
            }
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
