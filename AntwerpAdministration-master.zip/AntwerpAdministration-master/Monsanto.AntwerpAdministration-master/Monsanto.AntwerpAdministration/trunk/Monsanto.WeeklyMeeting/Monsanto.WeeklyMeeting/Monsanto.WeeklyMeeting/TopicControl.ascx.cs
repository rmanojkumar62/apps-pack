﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Monsanto.WeeklyMeeting.CONTROLTEMPLATES.Monsanto.WeeklyMeeting
{
    public partial class TopicControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e) { }

        public int GetTopicID()
        {
            return Convert.ToInt32(HiddenTopicID.Value);
        }

        public string GetTopicName()
        {
            return lblTopic.Text;
        }

        public string GetTopicPriority()
        {
            return HiddenTopicPriority.Value;
        }

        public string GetAgendaItems()
        {
            return txtAgendaItems.Text;
        }
    }
}
