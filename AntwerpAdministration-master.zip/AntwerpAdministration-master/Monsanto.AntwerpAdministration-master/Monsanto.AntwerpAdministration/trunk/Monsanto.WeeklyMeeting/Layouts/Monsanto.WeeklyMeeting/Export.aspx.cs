﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Net.Mail;
using System.Xml;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using Monsanto.WeeklyMeeting.HtmlToOpenXml;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;
using DocumentFormat.OpenXml.Drawing.Wordprocessing;
using System.Web.UI;
using System.Reflection;

namespace Monsanto.WeeklyMeeting.Layouts.Monsanto.WeeklyMeeting
{
    public partial class Export : LayoutsPageBase
    {
        public string documentName = string.Concat(Constants.Config[Constants.StrMeetingPrefix], DateTime.Now.ToString(Constants.Config[Constants.DateTimeFormat]), Constants.Config[Constants.StrDocExtension]);

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            string BootstrapCssCDN = Convert.ToString(Constants.Config[Constants.BootstrapCssCDN]);
            string BootstrapCssThemeCDN = Convert.ToString(Constants.Config[Constants.BootstrapCssThemeCDN]);
            string BootstrapScriptCDN = Convert.ToString(Constants.Config[Constants.BootstrapScriptCDN]);
            string fontawesomeCDN = Convert.ToString(Constants.Config[Constants.FontAwesomeCDN]);
            if (!string.IsNullOrEmpty(BootstrapCssCDN))
            {
                this.Controls.Add(new CssRegistration()
                {
                    Name = BootstrapCssCDN
                });
            }
            if (!string.IsNullOrEmpty(BootstrapCssThemeCDN))
            {
                this.Controls.Add(new CssRegistration()
                {
                    Name = BootstrapCssThemeCDN
                });
            }
            if (!string.IsNullOrEmpty(fontawesomeCDN))
            {
                this.Controls.Add(new CssRegistration()
                {
                    Name = fontawesomeCDN
                });
            }
            if (!string.IsNullOrEmpty(BootstrapScriptCDN))
            {
                this.Controls.Add(new LiteralControl()
                {    
                    Text="<script src=\""+BootstrapScriptCDN+"\"></script>"
                });
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string[] itemIDS = Request[Constants.QueryStringItemIDS] != null ? Request[Constants.QueryStringItemIDS].Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries) : new string[] { };
                string listID = Request[Constants.QueryStringListID];
                List<AgendaItem> agendaItems = MeetingUtilities.GetAgendaItems(Request[Constants.QueryStringListID],itemIDS);
                if (Convert.ToBoolean(Constants.Config["Use_Doc_Template"]))
                {
                    CopyDocumentTemplate();
                    EditDocument(agendaItems);
                }
                else
                    CreateWordDocument(agendaItems);
                MeetingUtilities.UpdateAgendaItems(itemIDS, listID);
                if(Convert.ToBoolean(Constants.Config[Constants.Mail_SendExportMail]))
                    SendMail(GetMailOutput(agendaItems));
            }
            lblConfirmationMessage.Text = Constants.Config[Constants.Message_Confirmation_Export];
            btn_confirmation.InnerText = Constants.Config[Constants.Btn_CloseConfirmation];
        }

        private string GetMailOutput(List<AgendaItem> agendaItems)
        {
            string previousTopic = string.Empty;
            string previousDepartment = string.Empty;
            string mailoutput = string.Empty;
            try
            {
                StringBuilder sb = new StringBuilder();
                foreach (AgendaItem currentItem in agendaItems)
                {
                    if (!string.IsNullOrEmpty(currentItem.Item) && !string.IsNullOrEmpty(MeetingUtilities.StripHTML(currentItem.Item)))
                    {
                        if (previousTopic != currentItem.Topic.Name)
                        {
                            sb.Append(Convert.ToString(Constants.Config[Constants.Mail_HTML_Header1]).Replace(Constants.Mail_HTMLHEADER, currentItem.Topic.Name));
                            previousTopic = currentItem.Topic.Name;
                            previousDepartment = string.Empty;
                        }
                        if (previousDepartment != currentItem.Department)
                        {
                            sb.Append(Convert.ToString(Constants.Config[Constants.Mail_HTML_Header2]).Replace(Constants.Mail_HTMLHEADER, currentItem.Department));
                            previousDepartment = currentItem.Department;
                        }
                        sb.Append(Convert.ToString(Constants.Config[Constants.Mail_HTML_Header3]).Replace(Constants.Mail_HTMLHEADER, MeetingUtilities.ConvertToTable(currentItem.Item)));
                    }
                }
                mailoutput = sb.ToString();
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return mailoutput;
        }

        private void SendMail(string output)
        {
            try
            {
                string body = string.Empty;
                body = MeetingUtilities.GetMailTemplate();
                body = body.Replace("[DATA]", output);
                body = body.Replace("[VERSLAGDATUM]", DateTime.Now.ToString(Constants.Config[Constants.DateFormat_Mail]));
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(Constants.Config[Constants.Mail_WeeklyMeetingEmail]);
                mailMessage.To.Add(new MailAddress(SPContext.Current.Web.CurrentUser.Email));
                mailMessage.Subject = string.Concat(Constants.Config[Constants.StrMeetingPrefix], DateTime.Today.ToString(Constants.Config[Constants.DateFormat]));
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = body;
                SmtpClient smtpClient = new SmtpClient(Constants.Config[Constants.Mail_MonsantoSMTP]);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        #region WORD FILE
        private void CopyDocumentTemplate()
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                {
                    using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                    {
                        SPList templatesList = web.Lists[Constants.Config[Constants.Lib_Templates]];
                        SPQuery query = new SPQuery();
                        query.ViewFields = Constants.Config[Constants.CAML_Templates_Viewfields];
                        query.Query = Constants.Config[Constants.CAML_Templates];
                        SPListItemCollection itemcollection = templatesList.GetItems(query);
                        if (itemcollection.Count > 0)
                        {
                            SPFile file = itemcollection[0].File;
                            byte[] byteArray = file.OpenBinary();
                            SPFolder destinationList = web.Lists[Constants.Config[Constants.Lib_Documents]].RootFolder;
                            try
                            {
                                web.AllowUnsafeUpdates = true;
                                SPFile spfile = destinationList.Files.Add(documentName, byteArray, true);
                                destinationList.Update();
                            }
                            catch (Exception ex)
                            {
                                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                            }
                            finally
                            {
                                web.AllowUnsafeUpdates = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        private void EditDocument(List<AgendaItem> agendaItems)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Web.CurrentUser.UserToken))
                {
                    using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                    {
                        SPList list = web.Lists[Constants.Config[Constants.Lib_Documents]];
                        SPQuery query = new SPQuery();
                        query.ViewFields = Constants.Config[Constants.CAML_Documents_Viewfields];
                        query.Query = string.Format(Constants.Config[Constants.CAML_Documents], documentName);
                        SPListItemCollection itemcollection = list.GetItems(query);
                        if (itemcollection.Count > 0)
                        {
                            SPFile file = itemcollection[0].File;
                            byte[] byteArray = file.OpenBinary();
                            using (MemoryStream memorystream = new MemoryStream())
                            {
                                memorystream.Write(byteArray, 0, byteArray.Length);
                                using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(memorystream, true))
                                {
                                    Document document = wordDoc.MainDocumentPart.Document;
                                    MainDocumentPart mainDocPart = wordDoc.MainDocumentPart;
                                    StyleDefinitionsPart stylePart = mainDocPart.StyleDefinitionsPart;
                                    ApplyDocumentStyles(stylePart);
                                    CreateDocumentHeader(mainDocPart);
                                    FillDocumentBody(document, agendaItems, mainDocPart);
                                }
                                try
                                {
                                    string linkFileName = Convert.ToString(file.Item[Constants.Col_LinkFilename]);
                                    web.AllowUnsafeUpdates = true;
                                    StreamReader reader = new StreamReader(memorystream);
                                    string text = reader.ReadToEnd();
                                    file.ParentFolder.Files.Add(linkFileName, memorystream, true);
                                }
                                catch (Exception ex)
                                {
                                    Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                                    Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                                }
                                finally
                                {
                                    web.AllowUnsafeUpdates = false;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        private void CreateWordDocument(List<AgendaItem> agendaItems)
        {
            using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Web.CurrentUser.UserToken))
            {
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPFolder destinationList = web.Lists[Constants.Config[Constants.Lib_Documents]].RootFolder;
                    try
                    {
                        using (MemoryStream memorystream = new MemoryStream())
                        {
                            using (WordprocessingDocument wordDoc = WordprocessingDocument.Create(memorystream, WordprocessingDocumentType.Document))
                            {
                                MainDocumentPart mainDocPart = wordDoc.AddMainDocumentPart();
                                wordDoc.MainDocumentPart.Document = new Document();
                                wordDoc.MainDocumentPart.Document.Body = new Body();
                                Document document = wordDoc.MainDocumentPart.Document;
                                StyleDefinitionsPart stylePart = wordDoc.MainDocumentPart.StyleDefinitionsPart;
                                if (stylePart == null)
                                {
                                    stylePart = wordDoc.MainDocumentPart.AddNewPart<StyleDefinitionsPart>();
                                    Styles root = new Styles();
                                    root.Save(stylePart);
                                }
                                ApplyDocumentStyles(stylePart);
                                CreateWordDocumentHeader(mainDocPart);
                                FillDocumentBody(document, agendaItems, mainDocPart);
                                wordDoc.MainDocumentPart.Document.Save();
                            }
                            try
                            {
                                memorystream.Seek(0, SeekOrigin.Begin);
                                web.AllowUnsafeUpdates = true;
                                SPFile spfile = destinationList.Files.Add(documentName, memorystream, true);
                                destinationList.Update();
                            }
                            catch (Exception ex)
                            {
                                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                            }
                            finally
                            {
                                web.AllowUnsafeUpdates = false;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                        Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                    }
                }
            }
        }

        private void CreateDocumentHeader(MainDocumentPart mainDocPart)
        {
            mainDocPart.DeleteParts(mainDocPart.HeaderParts);
            HeaderPart headerPart = mainDocPart.AddNewPart<HeaderPart>();
            string headerPartId = mainDocPart.GetIdOfPart(headerPart);
            GenerateHeaderPartContent(headerPart);
            IEnumerable<SectionProperties> sections = mainDocPart.Document.Body.Elements<SectionProperties>();
            foreach (var section in sections)
            {
                section.RemoveAllChildren<HeaderReference>();
                section.PrependChild<HeaderReference>(new HeaderReference() { Id = headerPartId });
            }
        }

        private void CreateWordDocumentHeader(MainDocumentPart mainDocPart)
        {
            HeaderPart headerPart = mainDocPart.AddNewPart<HeaderPart>();
            string headerPartId = mainDocPart.GetIdOfPart(headerPart);
            GenerateHeaderPartContent(headerPart);
            IEnumerable<SectionProperties> sections = mainDocPart.Document.Body.Elements<SectionProperties>();
            if (sections.Count() == 0)
            {
                mainDocPart.Document.Body.AppendChild(new SectionProperties(new HeaderReference() { Id = headerPartId }));
            }
            else
            {
                foreach (var section in sections)
                {
                    section.RemoveAllChildren<HeaderReference>();
                    section.PrependChild<HeaderReference>(new HeaderReference() { Id = headerPartId });
                }
            }
        }

        public void GenerateHeaderPartContent(HeaderPart part)
        {
            try
            {
                Header header = new Header() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14 wp14" } };
                header.AddNamespaceDeclaration("wpc", "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas");
                header.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
                header.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
                header.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
                header.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
                header.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
                header.AddNamespaceDeclaration("wp14", "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing");
                header.AddNamespaceDeclaration("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing");
                header.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
                header.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
                header.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");
                header.AddNamespaceDeclaration("wpg", "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup");
                header.AddNamespaceDeclaration("wpi", "http://schemas.microsoft.com/office/word/2010/wordprocessingInk");
                header.AddNamespaceDeclaration("wne", "http://schemas.microsoft.com/office/word/2006/wordml");
                header.AddNamespaceDeclaration("wps", "http://schemas.microsoft.com/office/word/2010/wordprocessingShape");
                Paragraph paragraph = new Paragraph() { RsidParagraphAddition = "00164C17", RsidRunAdditionDefault = "00164C17" };
                ParagraphProperties paragraph_props = new ParagraphProperties();
                ParagraphStyleId paragraphStyleID = new ParagraphStyleId() { Val = "DocHeader" };
                paragraph_props.Append(paragraphStyleID);
                paragraph.Append(paragraph_props);
                Run run = null;
                if (Convert.ToBoolean(Constants.Config["DocHeader_EnableLogo"]))
                {
                    Drawing element = CreateImagePart(part, header);
                    run = new Run(element);
                    paragraph.Append(run);
                }
                run = new Run();
                Text text = new Text(string.Concat(Convert.ToString(Constants.Config[Constants.WORD_Header]), DateTime.Now.ToString(Constants.Config[Constants.DateFormat_Word])));
                run.Append(text);
                paragraph.Append(run);
                header.Append(paragraph);

                /*paragraph = new Paragraph();
                paragraph_props = new ParagraphProperties();
                paragraph_props.Justification=new Justification(){ Val = JustificationValues.Right };
                paragraph.Append(paragraph_props);
                run= new Run(element);
                paragraph.Append(run);
                header.Append(paragraph);*/
                part.Header = header;
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        private Drawing CreateImagePart(HeaderPart headerPart, Header header)
        {
            Stream file_monsantologo_stream = null;
            var element = new Drawing();
            try
            {
                ImagePart imgPart = headerPart.AddImagePart(ImagePartType.Png);
                string imgPartId = headerPart.GetIdOfPart(imgPart);
                //var widthPx = 0;
                //var heightPx = 0;
                //var widthEmus = 0L;
                //var heightEmus = 0L;
                SPFile file_monsantologo = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Monsanto_Logo"]));
                file_monsantologo_stream = file_monsantologo.OpenBinaryStream();
                
                //stream = File.OpenRead(Server.MapPath("~/_layouts/Monsanto.WeeklyMeeting/images/monsanto-logo-header-small.png"));
                //using (stream = File.OpenRead(Server.MapPath("~/_layouts/Monsanto.WeeklyMeeting/images/monsanto-logo-header-small.png")))
                //{
                //var img = System.Drawing.Image.FromStream(stream);
                imgPart.FeedData(file_monsantologo_stream);
                //widthPx = img.Width;
                //heightPx = img.Height;
                //var horzRezDpi = img.HorizontalResolution;
                //var vertRezDpi = img.VerticalResolution;
                //const int emusPerInch = 914400;
                //const int emusPerCm = 360000;
                //widthEmus = (long)(widthPx / horzRezDpi * emusPerInch);
                //heightEmus = (long)(heightPx / vertRezDpi * emusPerInch);
                //var maxWidthEmus = (long)(3.5 * emusPerCm);
                //if (widthEmus > maxWidthEmus)
                //{
                //    var ratio = (heightEmus * 1.0m) / widthEmus;
                //    widthEmus = maxWidthEmus;
                //    heightEmus = (long)(widthEmus * ratio);
                //}
                //}

                element =
                     new Drawing(
                         new DW.Anchor(
                    //new DW.Inline(
                            new DW.SimplePosition() { X = 0, Y = 0 },
                            new DW.HorizontalPosition() { RelativeFrom = HorizontalRelativePositionValues.Column, PositionOffset = new DW.PositionOffset("4676776") },
                            new DW.VerticalPosition() { RelativeFrom = VerticalRelativePositionValues.Paragraph, PositionOffset = new DW.PositionOffset("-57150") },
                            new DW.Extent() { Cx = 1276206, Cy = 480695 },
                            new DW.EffectExtent() { LeftEdge = 0, TopEdge = 0, RightEdge = 0, BottomEdge = 0 },
                            new DW.WrapNone(),
                            new DW.DocProperties() { Id = (UInt32Value)1U, Name = "Picture 1" },
                            new DW.NonVisualGraphicFrameDrawingProperties(new A.GraphicFrameLocks() { NoChangeAspect = true }),
                             new A.Graphic(
                                 new A.GraphicData(
                                     new PIC.Picture(
                                         new PIC.NonVisualPictureProperties(
                                             new PIC.NonVisualDrawingProperties()
                                             {
                                                 Id = 0,
                                                 Name = "Picture 1"
                                             },
                                             new PIC.NonVisualPictureDrawingProperties()
                                             {
                                                 PictureLocks = new A.PictureLocks()
                                                 {
                                                     NoChangeAspect = true,
                                                     NoChangeArrowheads = true
                                                 }
                                             }
                                         ),
                                         new PIC.BlipFill(
                                             new A.Blip(
                                                 new A.BlipExtensionList(
                                                     new A.BlipExtension()
                                                     {Uri ="{28A0092B-C50C-407E-A947-70E740481C1C}"})
                                             )
                                             {
                                                 Embed = imgPartId,
                                                 CompressionState = A.BlipCompressionValues.Print
                                             },
                                             new A.SourceRectangle(),
                                             new A.Stretch(new A.FillRectangle())
                                         ),
                                         new PIC.ShapeProperties(
                                             new A.Transform2D(
                                                 new A.Offset() { X = 0, Y = 0 },
                                                 new A.Extents() { Cx = 1332395, Cy = 501859 }
                                             ),
                                             new A.PresetGeometry(
                                                 new A.AdjustValueList()
                                             ) { Preset = A.ShapeTypeValues.Rectangle },
                                             new A.NoFill()

                                         ))
                                 ) { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
                         )
                         {
                             SimplePos = false,
                             RelativeHeight = 251658240,
                             BehindDoc = true,
                             Locked = false,
                             LayoutInCell = true,
                             AllowOverlap = true,
                             DistanceFromTop = 0,
                             DistanceFromBottom = 0,
                             DistanceFromLeft = 114300,
                             DistanceFromRight = 114300,
                             EditId = "50D07946"
                         });
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            finally
            {
                if (file_monsantologo_stream != null)
                {
                    file_monsantologo_stream.Close();
                    file_monsantologo_stream = null;
                }
            }
            return element;
        }
        
        private RunProperties GetRunProperties(int type)
        {
            RunProperties runProp = new RunProperties();
            Color runColor = new Color();
            RunFonts runFont = new RunFonts();
            try
            {
                switch (type)
                {
                    case 0:
                        if (!string.IsNullOrEmpty(Constants.Config[Constants.DocHeader_Color]))
                            runColor.Val = Constants.Config[Constants.DocHeader_Color];
                        if (!string.IsNullOrEmpty(Constants.Config[Constants.DocHeader_Font]))
                            runFont.Ascii = Constants.Config[Constants.DocHeader_Font];
                        else
                            runFont.Ascii = Constants.WORD_DefaultFont;
                        runProp.Append(new Bold());
                        runProp.Append(new DocumentFormat.OpenXml.Wordprocessing.FontSize() { Val = Constants.Config[Constants.DocHeader_FontSize] });
                        break;
                    case 1:
                        if (!string.IsNullOrEmpty(Constants.Config[Constants.TopicHeading_Color]))
                            runColor.Val = Constants.Config[Constants.TopicHeading_Color];
                        if (!string.IsNullOrEmpty(Constants.Config[Constants.TopicHeading_Font]))
                            runFont.Ascii = Constants.Config[Constants.TopicHeading_Font];
                        else
                            runFont.Ascii = Constants.WORD_DefaultFont;
                        runProp.Append(new Bold());
                        runProp.Append(new DocumentFormat.OpenXml.Wordprocessing.FontSize() { Val = Constants.Config[Constants.TopicHeading_FontSize] });
                        break;
                    case 2:
                        if (!string.IsNullOrEmpty(Constants.Config[Constants.DepartmentHeading_Color]))
                            runColor.Val = Constants.Config[Constants.DepartmentHeading_Color];
                        if (!string.IsNullOrEmpty(Constants.Config[Constants.DepartmentHeading_Font]))
                            runFont.Ascii = Constants.Config[Constants.DepartmentHeading_Font];
                        else
                            runFont.Ascii = Constants.WORD_DefaultFont;
                        runProp.Append(new Bold());
                        runProp.Append(new DocumentFormat.OpenXml.Wordprocessing.FontSize() { Val = Constants.Config[Constants.DepartmentHeading_FontSize] });
                        break;
                }
                runProp.Append(runColor);
                runProp.Append(runFont);
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return runProp;
        }

        private void ApplyDocumentStyles(StyleDefinitionsPart stylePart)
        {
            try
            {
                DocumentFormat.OpenXml.Wordprocessing.Style headerStyle = new DocumentFormat.OpenXml.Wordprocessing.Style();
                headerStyle.StyleId = "DocHeader";
                headerStyle.Append(new Name() { Val = "Doc Header" });
                headerStyle.Append(new BasedOn() { Val = Constants.Config[Constants.DocHeader_BasedOn] });
                headerStyle.Append(new NextParagraphStyle() { Val = Constants.Config[Constants.DocHeader_NextParagraphStyle] });
                headerStyle.Append(GetRunProperties(0));

                DocumentFormat.OpenXml.Wordprocessing.Style topicHeadingStyle = new DocumentFormat.OpenXml.Wordprocessing.Style();
                topicHeadingStyle.StyleId = "TopicHeading";
                topicHeadingStyle.Append(new Name() { Val = "Topic Heading" });
                topicHeadingStyle.Append(new BasedOn() { Val = Constants.Config[Constants.TopicHeading_BasedOn] });
                topicHeadingStyle.Append(new NextParagraphStyle() { Val = Constants.Config[Constants.TopicHeading_NextParagraphStyle] });
                topicHeadingStyle.Append(GetRunProperties(1));

                DocumentFormat.OpenXml.Wordprocessing.Style departmentHeadingStyle = new DocumentFormat.OpenXml.Wordprocessing.Style();
                departmentHeadingStyle.StyleId = "DepartmentHeading";
                departmentHeadingStyle.Append(new Name() { Val = "Department Heading" });
                departmentHeadingStyle.Append(new BasedOn() { Val = Constants.Config[Constants.DepartmentHeading_BasedOn] });
                departmentHeadingStyle.Append(new NextParagraphStyle() { Val = Constants.Config[Constants.DepartmentHeading_NextParagraphStyle] });
                departmentHeadingStyle.Append(GetRunProperties(2));

                stylePart.Styles = new Styles();
                stylePart.Styles.Append(headerStyle);
                stylePart.Styles.Append(topicHeadingStyle);
                stylePart.Styles.Append(departmentHeadingStyle);
                stylePart.Styles.Save();
            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        private void FillDocumentBody(Document document, List<AgendaItem> agendaItems, MainDocumentPart mainDocPart)
        {
            try
            {
                string previousTopic = string.Empty;
                string previousDepartment = string.Empty;
                foreach (AgendaItem item in agendaItems)
                {
                    if (!string.IsNullOrEmpty(item.Item) && !string.IsNullOrEmpty(MeetingUtilities.StripHTML(item.Item)))
                    {
                        if (previousTopic != item.Topic.Name)
                        {
                            CreateParagraph(string.Concat(Constants.Config[Constants.TopicHeading_Prefix], item.Topic.Name), "TopicHeading", document);
                            previousTopic = item.Topic.Name;
                            previousDepartment = string.Empty;
                        }
                        if (previousDepartment != item.Department)
                        {
                            CreateParagraph(string.Concat(Constants.Config[Constants.DepartmentHeading_Prefix], item.Department), "DepartmentHeading", document);
                            previousDepartment = item.Department;
                        }
                        HtmlConverter converter = new HtmlConverter(mainDocPart);
                        var paragraphs = converter.Parse(MeetingUtilities.CreateValidNestedLists(item.Item));
                        for (int i = 0; i < paragraphs.Count; i++)
                        {
                            Paragraph lastParagraphP = document.Body.Elements<Paragraph>().LastOrDefault();
                            if (lastParagraphP != null)
                            {
                                Paragraph itemP = paragraphs[i] as Paragraph;
                                lastParagraphP.Parent.InsertAfter(itemP, lastParagraphP);
                            }
                        }
                        CreateParagraph(" ", null, document);
                    }
                    
                  
                }
                //CreateParagraph("Topic to be communicated", "TopicHeading", document);
                

            }
            catch (Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        private void CreateParagraph(string str, string paragraphstyleID, Document document)
        {
            try
            {
                Paragraph paragraph = new Paragraph();
                Run run = new Run();
                Text text = new Text(str);
                ParagraphProperties paragraph_props = new ParagraphProperties();
                if (paragraphstyleID != null)
                    paragraph_props.ParagraphStyleId = new ParagraphStyleId() { Val = paragraphstyleID };
                paragraph.Append(paragraph_props);
                run.Append(text);
                paragraph.Append(run);
                Paragraph lastParagraph = document.Body.Elements<Paragraph>().LastOrDefault();
                if (lastParagraph != null)
                    lastParagraph.Parent.InsertAfter(paragraph, lastParagraph);
                else
                    document.Body.AppendChild(paragraph);
            }
            catch(Exception ex)
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }
        #endregion
        
        protected void btnClose_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.StrIsDlg]))
            {
                string[] isDlg = this.Request.QueryString.GetValues(Constants.StrIsDlg);
                if (!String.IsNullOrEmpty(isDlg[0]) && isDlg[0] == Constants.StrIsDlgValue)
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), Constants.StrIsDlgClose_OK, true);
            }
            else
            {
                Response.Redirect(Request.QueryString[Constants.QueryStringSource], false);
            }
        }
    }
}