﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Drawing;
using Microsoft.SharePoint.Utilities;
using Monsanto.WeeklyMeeting.CONTROLTEMPLATES.Monsanto.WeeklyMeeting;
using System.Web.UI;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Monsanto.WeeklyMeeting.Layouts.Monsanto.WeeklyMeeting
{
    public partial class Form : LayoutsPageBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            try
            {
                base.OnLoad(e);
                if (!IsPostBack)
                {
                    if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringFormID]))
                    {
                        if (Request.QueryString[Constants.QueryStringFormID] != Constants.NewFormID)
                            LoadForm(Request.QueryString[Constants.QueryStringFormID]);
                        else
                            LoadTopics();
                    }
                    else
                    {
                        switch (Request.QueryString[Constants.QueryStringMode])
                        {
                            case "new":
                                LoadTopics();
                                break;
                            case "edit":
                                LoadForm(Request.QueryString[Constants.QueryStringID]);
                                break;
                            case "display":
                                dropDepartment.Enabled = false;
                                dropStatus.Enabled = false;
                                LoadForm(Request.QueryString[Constants.QueryStringID]);
                                break;
                        }
                    }
                }
            }
            catch (Exception ex) { }
        }
        
        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            string BootstrapCssCDN = Convert.ToString(Constants.Config[Constants.BootstrapCssCDN]);
            string BootstrapCssThemeCDN = Convert.ToString(Constants.Config[Constants.BootstrapCssThemeCDN]);
            string BootstrapScriptCDN = Convert.ToString(Constants.Config[Constants.BootstrapScriptCDN]);
            string fontawesomeCDN=Convert.ToString(Constants.Config[Constants.FontAwesomeCDN]);
            if (!string.IsNullOrEmpty(BootstrapCssCDN))
            {
                this.Controls.Add(new CssRegistration()
                {
                    Name = BootstrapCssCDN
                });
            }
            if (!string.IsNullOrEmpty(BootstrapCssThemeCDN))
            {
                this.Controls.Add(new CssRegistration()
                {
                    Name = BootstrapCssThemeCDN
                });
            }
            if (!string.IsNullOrEmpty(fontawesomeCDN))
            {
                this.Controls.Add(new CssRegistration()
                {
                    Name = fontawesomeCDN
                });
            }
            if (!string.IsNullOrEmpty(BootstrapScriptCDN))
            {
                this.Controls.Add(new LiteralControl()
                {
                    Text = "<script src=\"" + BootstrapScriptCDN + "\"></script>"
                });
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            LoadLabels();
            LoadButtons();
            if (!IsPostBack)
                LoadDepartments();
            else
                LoadTopics();
        }

        private void LoadLabels()
        {
            lblFormHeader.Text = Constants.Config[Constants.Label_FormHeader];
            lblDepartment.Text = Constants.Config[Constants.Label_Department];
            lblStatus.Text = Constants.Config[Constants.Label_Status];
            lblConfirmationMessage.Text = Constants.Config[Constants.Message_Confirmation_Form];
        }

        private void LoadButtons()
        {
            btnSave_Text.InnerText = Constants.Config[Constants.Btn_Save];
            btnEdit_Text.InnerText = Constants.Config[Constants.Btn_Edit];
            btnCancel_Text.InnerText = Constants.Config[Constants.Btn_Cancel];
            btn_confirmation.InnerText = Constants.Config[Constants.Btn_CloseConfirmation];
            switch (Request.QueryString[Constants.QueryStringMode])
            {
                case "new":
                case "edit":
                    btnSave.Visible = true;
                    btnEdit.Visible = false;
                    break;
                case "display":
                    btnSave.Visible = false;
                    btnEdit.Visible = true;
                    break;
            }
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.StrIsDlg]))
            {
                string[] isDlg = this.Request.QueryString.GetValues(Constants.StrIsDlg);
                if (!String.IsNullOrEmpty(isDlg[0]) && isDlg[0] == Constants.StrIsDlgValue)
                    btnCloseConfirmation.Attributes["onclick"] = Constants.Config[Constants.Dlg_CloseFunction];
            }
        }

        private void LoadDepartments()
        {
            MeetingUtilities.GetDepartments(dropDepartment, Constants.Config[Constants.Message_DepartmentSelect]);
        }

        private void LoadTopics()
        {
            int counter = 0;
            List<Topic> topics = MeetingUtilities.GetTopics();
            foreach (Topic topic in topics)
            {
                TopicControl tc = (TopicControl)LoadControl(Constants.TopicCtrl);
                tc.ID = String.Format("{0}{1}", Constants.TopicCtrlPrefix, counter);
                Label legend = (Label)tc.FindControl(Constants.TopicLabel);
                legend.Text = topic.Name;
                HiddenField topicID = (HiddenField)tc.FindControl(Constants.TopicID);
                topicID.Value = topic.ID.ToString();
                HiddenField topicPriority = (HiddenField)tc.FindControl(Constants.TopicPriority);
                topicPriority.Value = topic.Priority;
                //TextBox agendaitems = (TextBox)tc.FindControl(Constants.TopicBox);
                ////agendaitems.Text = topic.AgendaItems;
                //if (Request.QueryString[Constants.QueryStringMode].Equals(Constants.Mode_Display))
                //    agendaitems.Enabled = false;
                pnlTopics.Controls.Add(tc);
                counter++;
            }
        }

        private void LoadTopicControls(List<FormTopic> topics)
        {
            int counter = 0;
            foreach (FormTopic topic in topics)
            {
                TopicControl tc = (TopicControl)LoadControl(Constants.TopicCtrl);
                tc.ID = String.Format("{0}{1}", Constants.TopicCtrlPrefix, counter);
                Label topiclabel = (Label)tc.FindControl(Constants.TopicLabel);
                topiclabel.Text = topic.Name;
                HiddenField topicID = (HiddenField)tc.FindControl(Constants.TopicID);
                topicID.Value = topic.ID.ToString();
                HiddenField topicPriority = (HiddenField)tc.FindControl(Constants.TopicPriority);
                topicPriority.Value = topic.Priority;
                TextBox agendaitems = (TextBox)tc.FindControl(Constants.TopicBox);
                agendaitems.Text = topic.AgendaItems;
                if (Request.QueryString[Constants.QueryStringMode].Equals(Constants.Mode_Display))
                    agendaitems.Enabled = false;
                pnlTopics.Controls.Add(tc);
                counter++;
            }
        }

        private void LoadForm(string ID)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPListItem item = web.Lists.TryGetList(Constants.Config[Constants.List_AgendaItems]).Items.GetItemById(Convert.ToInt32(ID));
                    string department = Convert.ToString(item[Constants.Col_Department]);
                    if (!string.IsNullOrEmpty(department))
                        this.dropDepartment.SelectedValue = department;
                    string status = Convert.ToString(item[Constants.Col_Status]);
                    if (!string.IsNullOrEmpty(status))
                        this.dropStatus.SelectedValue = status;
                    List<FormTopic> topics = MeetingUtilities.XMLToData(Convert.ToString(item[Constants.Col_Data]));
                    LoadTopicControls(topics);
                    if (MeetingUtilities.HasAdminPermission())
                        rowStatus.Visible = true;
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        protected void ResetRequiredFields()
        {
            this.lblDepartment.ForeColor = Color.Empty;
        }

        protected bool CheckRequiredFields()
        {
            bool isNOK = false;
            if (this.dropDepartment.SelectedIndex <= 0)
            {
                lblDepartment.ForeColor = Color.Red;
                isNOK = true;
            }
            return isNOK;
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            ResetRequiredFields();
            if (CheckRequiredFields())
            {
                //ThrowError(ErrorType.FIELDS, "One or more fields are not filled in correctly.");
                return;
            }
            else
            {
                string departmentstr = dropDepartment.SelectedValue;
                ControlCollection ctrls = this.pnlTopics.Controls;
                try
                {
                    // GET ALL TOPICS DATA FROM FORM
                    List<FormTopic> tc = new List<FormTopic>();
                    foreach (Control ctrl in ctrls)
                    {
                        if (ctrl.Controls.Count > 0 && ctrl.ID.Contains(Constants.TopicCtrlPrefix))
                        {
                            TopicControl form = (TopicControl)ctrl;
                            int topicID = form.GetTopicID();
                            string topicName = form.GetTopicName();
                            string topicPriority = form.GetTopicPriority();
                            string agendaitems = form.GetAgendaItems();

                            string agendadata = Regex.Replace(agendaitems, @"<(?!br[\x20/>])[^<>]+>", string.Empty);;
                            tc.Add(new FormTopic(topicID, topicName, topicPriority, agendadata));
                        }
                    }
                    // CONVERT TOPIC COLLECTION TO XML
                    string data = MeetingUtilities.DataToXML(tc);
                    Department department = MeetingUtilities.GetDepartment(departmentstr);
                    // SAVE ALL DATA TO LIST
                    try
                    {
                        using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Web.CurrentUser.UserToken))
                        using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                        {
                            SPListItem item = null;
                            if ((!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringMode]) && Request.QueryString[Constants.QueryStringMode] == Constants.Mode_New) || (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringFormID]) && Request.QueryString[Constants.QueryStringFormID] == Constants.NewFormID))
                                item = web.Lists.TryGetList(Constants.Config[Constants.List_AgendaItems]).AddItem();
                            else if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringMode]) && Request.QueryString[Constants.QueryStringMode] != Constants.Mode_New)
                                item = web.Lists.TryGetList(Constants.Config[Constants.List_AgendaItems]).Items.GetItemById(Convert.ToInt32(Request.QueryString[Constants.QueryStringID]));
                            else if (!string.IsNullOrEmpty(Request.QueryString[Constants.QueryStringFormID]) && Request.QueryString[Constants.QueryStringFormID] != Constants.NewFormID)
                                item = web.Lists.TryGetList(Constants.Config[Constants.List_AgendaItems]).Items.GetItemById(Convert.ToInt32(Request.QueryString[Constants.QueryStringFormID]));
                            if (item != null)
                            {
                                if (department != null)
                                {
                                    item[Constants.Col_Department] = department.Name;
                                    item[Constants.Col_DepartmentID] = department.ID;
                                    SPFieldUserValue userValue = new SPFieldUserValue(web, department.ResponsibleID, department.ResponsibleLogin);
                                    item[Constants.Col_Responsible] = userValue;
                                }
                                item[Constants.Col_Data] = data;
                                if (dropStatus.SelectedIndex == -1 || dropStatus.SelectedValue.Equals(Constants.NewFormStatus))
                                    item[Constants.Col_Status] = Constants.NewFormStatus;
                                else
                                    item[Constants.Col_Status] = dropStatus.SelectedValue;
                                item.Update();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                        Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                    }
                }
                catch (Exception ex) 
                {
                    Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                    Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO WEEKLY MEETING ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                }
                ShowConfirmation();
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "RequestEnded();", true);
        }
        public static class HtmlRemoval
        {
            /// <summary>
            /// Remove HTML from string with Regex.
            /// </summary>
            public static string StripTagsRegex(string source)
            {
                return Regex.Replace(source, "<.*?>", string.Empty);
            }

            /// <summary>
            /// Compiled regular expression for performance.
            /// </summary>
            static Regex _htmlRegex = new Regex("<.*?>", RegexOptions.Compiled);

            /// <summary>
            /// Remove HTML from string with compiled Regex.
            /// </summary>
            public static string StripTagsRegexCompiled(string source)
            {
                return _htmlRegex.Replace(source, string.Empty);
            }

            /// <summary>
            /// Remove HTML tags from string using char array.
            /// </summary>
            public static string StripTagsCharArray(string source)
            {
                char[] array = new char[source.Length];
                int arrayIndex = 0;
                bool inside = false;

                for (int i = 0; i < source.Length; i++)
                {
                    char let = source[i];
                    if (let == '<')
                    {
                        inside = true;
                        continue;
                    }
                    if (let == '>')
                    {
                        inside = false;
                        continue;
                    }
                    if (!inside)
                    {
                        array[arrayIndex] = let;
                        arrayIndex++;
                    }
                }
                return new string(array, 0, arrayIndex);
            }
        }
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Format(Constants.Config[Constants.Form_EditURL], SPContext.Current.Web.Url, Request.QueryString[Constants.QueryStringID], Request.QueryString[Constants.QueryStringSource]), false);
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "RequestEnded();", true);
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.StrIsDlg]))
            {
                string[] isDlg = this.Request.QueryString.GetValues(Constants.StrIsDlg);
                if (!String.IsNullOrEmpty(isDlg[0]) && isDlg[0] == Constants.StrIsDlgValue)
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), Constants.StrIsDlgClose_Cancel, true);
            }
            else
                Response.Redirect(Request.QueryString[Constants.QueryStringSource], false);
        }

        protected void btnOverview_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString[Constants.StrIsDlg]))
            {
                string[] isDlg = this.Request.QueryString.GetValues(Constants.StrIsDlg);
                if (!String.IsNullOrEmpty(isDlg[0]) && isDlg[0] == Constants.StrIsDlgValue)
                    this.Page.ClientScript.RegisterStartupScript(this.GetType(), Guid.NewGuid().ToString(), Constants.StrIsDlgClose_OK, true);
            }
            else
                Response.Redirect(Request.QueryString[Constants.QueryStringSource], false);
        }

        private void ShowConfirmation()
        {
            pnlFormWrapper.Visible = false;
            pnlConfirmationWrapper.Visible = true;
        }
    }
}