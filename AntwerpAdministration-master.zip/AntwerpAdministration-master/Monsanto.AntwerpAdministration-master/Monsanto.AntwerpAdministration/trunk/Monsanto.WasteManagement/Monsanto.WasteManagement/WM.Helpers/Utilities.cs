﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.Collections;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Serialization;
using System.Reflection;
using System.IO;
using System.Web.UI;
using Monsanto.WasteManagement.WM.Enums;
using System.Xml.Linq;
using Microsoft.SharePoint.Workflow;
using Monsanto.WasteManagement.WM.Domain;

namespace Monsanto.WasteManagement
{
    public class Utilities
    {
        public static bool IsWaste()
        {
            string groupname = Constants.Config[Constants.Group_WasteMembers];
            return GroupExists(groupname);
        }

        public static bool IsDO()
        {
            string groupname = Constants.Config[Constants.Group_DOMembers];
            return GroupExists(groupname);
        }

        private static bool GroupExists(string groupname)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPGroupCollection groups = SPContext.Current.Web.CurrentUser.Groups;
                    if (string.IsNullOrEmpty(groupname) || (groupname.Length > 255) || (groups == null) || (groups.Count == 0))
                        return false;
                    else
                    {
                        XDocument doc = XDocument.Parse(groups.Xml);
                        const string NAME = "Name";
                        return doc.Descendants().Where(g => g.Attribute(NAME) != null).Where(g => g.Attribute(NAME).Value.Equals(groupname, StringComparison.InvariantCultureIgnoreCase)).Count() > 0;
                    }
                }

            }
            catch (SPException spex) { return false; }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return false;
        }

        public static void LoadMasterValues(DropDownList dropdown, string masterlistname, string caml, string selectmessage)
        {
            try
            {
                if (!string.IsNullOrEmpty(selectmessage))
                    dropdown.Items.Add(new ListItem(selectmessage, Constants.drop_Zero_Value));
                SPQuery q = new SPQuery();
                q.Query = caml;
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(masterlistname).GetItems(q);
                foreach (SPListItem item in items)
                    dropdown.Items.Add(new ListItem(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_ID])));
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static void LoadProducts(string afdelingID, DropDownList dropdown, string selectmessage)
        {
            try
            {
                if (!string.IsNullOrEmpty(selectmessage))
                    dropdown.Items.Add(new ListItem(selectmessage, Constants.drop_Zero_Value));
                SPQuery q = new SPQuery();
                q.Query = string.Format(Constants.Config[Constants.CAML_Producten], afdelingID);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Producten]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    string ID = Convert.ToString(item[Constants.Col_ID]);
                    string title = Convert.ToString(item[Constants.Col_Title]);
                    dropdown.Items.Add(new ListItem(title, ID));
                }
                q = new SPQuery();
                q.Query = Constants.Config[Constants.CAML_Producten_Andere];
                items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Producten]).GetItems(q);
                foreach (SPListItem item in items)
                    dropdown.Items.Add(new ListItem(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_ID])));
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static void LoadADR(string productID, CheckBoxList checklist)
        {
            try
            {
                SPQuery q = new SPQuery();
                q.Query = Constants.Config[Constants.CAML_ADR];
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_ADR]).GetItems(q);
                foreach (SPListItem item in items)
                    checklist.Items.Add(new ListItem(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_ID])));
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static void LoadLocaties(DropDownList drops1, DropDownList drops2, string selectmessage)
        {
            try
            {
                SPQuery q;
                SPListItemCollection items;
                if (drops1 != null)
                {
                    drops1.Items.Add(new ListItem(selectmessage, Constants.drop_Zero_Value));
                    q = new SPQuery();
                    q.Query = Constants.Config[Constants.CAML_Locaties_1];
                    items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Afvalparking]).GetItems(q);
                    foreach (SPListItem item in items)
                    {
                        string title = Convert.ToString(item[Constants.Col_Title]);
                        drops1.Items.Add(new ListItem(title, title));
                    }
                }
                if (drops2 != null)
                {
                    drops2.Items.Add(new ListItem(selectmessage, Constants.drop_Zero_Value));
                    q = new SPQuery();
                    q.Query = Constants.Config[Constants.CAML_Locaties_2];
                    items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Afvalparking]).GetItems(q);
                    List<int> locaties = new List<int>();
                    foreach (SPListItem item in items)
                    {
                        int locatie = Convert.ToInt32(item[Constants.Col_Title]);
                        locaties.Add(locatie);
                    }
                    locaties.Sort();
                    foreach (int locatie in locaties)
                    {
                        string str_locatie = locatie.ToString();
                        drops2.Items.Add(new ListItem(str_locatie, str_locatie));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static void LoadBanen(DropDownList dropdown, string type, string adr)
        {
            try
            {
                SPQuery q = new SPQuery();
                if (type.Equals("Gereinigd"))
                    q.Query = string.Format(Constants.Config[Constants.CAML_Banen_Gereinigd], type);
                else
                    q.Query = string.Format(Constants.Config[Constants.CAML_Banen_Ongereinigd], type, adr);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_ADR_Baan]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    SPFieldLookup banen = item.Fields[Constants.Col_Baan] as SPFieldLookup;
                    if (banen.AllowMultipleValues)
                    {
                        SPFieldLookupValueCollection values = new SPFieldLookupValueCollection(item[Constants.Col_Baan].ToString());
                        foreach (SPFieldLookupValue value in values)
                            dropdown.Items.Add(value.LookupValue);
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static void LoadAfvalstromen(DropDownList dropdown, string selectmessage)
        {
            try
            {
                if (!string.IsNullOrEmpty(selectmessage))
                    dropdown.Items.Add(new ListItem(selectmessage, Constants.drop_Zero_Value));
                SPQuery q = new SPQuery();
                q.Query = Constants.Config[Constants.CAML_Afvalstromen];
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Producten]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    SPFieldLookupValue flv = new SPFieldLookupValue(item["Afdeling"].ToString());
                    dropdown.Items.Add(new ListItem(string.Concat(flv.LookupValue, " --- ", Convert.ToString(item[Constants.Col_Title])), Convert.ToString(item[Constants.Col_ID])));
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static void LoadFirmas_ByType(DropDownList dropdown, FirmaType type, string selectmessage)
        {
            try
            {
                if (!string.IsNullOrEmpty(selectmessage))
                    dropdown.Items.Add(new ListItem(selectmessage, Constants.drop_Zero_Value));
                SPQuery q = new SPQuery();
                q.Query = string.Format(Constants.Config[Constants.CAML_Firmas_ByType], type);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Firmas]).GetItems(q);
                foreach (SPListItem item in items)
                    dropdown.Items.Add(new ListItem(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_ID])));
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static Firma LoadFirma(int id)
        {
            Firma firma=null;
            try
            {
                if (id > 0)
                {
                    SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Firmas]).GetItemById(id);
                    firma = new Firma(item.ID, Convert.ToString(item[Constants.Col_Title]),
                        Convert.ToString(item["Straat"]),
                        Convert.ToString(item["Postcode"]),
                        Convert.ToString(item["Gemeente"]),
                        Convert.ToString(item["Land"]));
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return firma;
        }

        public static List<string> LoadTransactionECcodes()
        {
            List<string> codes = new List<string>();
            try
            {
                SPQuery q = new SPQuery();
                q.Query = "<OrderBy><FieldRef Name='Datum' Ascending='TRUE'/><FieldRef Name='Title' Ascending='TRUE'/></OrderBy>";
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Parking]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    if (item != null)
                    {
                        string eccode = Convert.ToString(item["EC_x0020_code"]);
                        if(!codes.Contains(eccode))
                            codes.Add(eccode);
                    }
                }
                codes.Sort();
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return codes;
        }

        public static List<ParkingTransactie> LoadParkingTransacties(string ticketnr,RequestType requestType)
        {
            List<ParkingTransactie> transacties = new List<ParkingTransactie>();
            try
            {
                SPQuery q = new SPQuery();
                q.Query = string.Format(Constants.Config[Constants.CAML_Parking], ticketnr);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Parking]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    if (item != null)
                    {
                        string transactie = Convert.ToString(item["Transactie"]);
                        DateTime datum = Convert.ToDateTime(item["Datum"]);
                        string afdeling = Convert.ToString(item["Afdeling"]);
                        string product = Convert.ToString(item["Product"]);
                        string volume = Convert.ToString(item["Volume_x0020_per_x0020_vat"]);
                        int aantalvaten = Convert.ToInt32(item["Aantal_x0020_vaten"]);
                        int aantalpaletten = Convert.ToInt32(item["Aantal_x0020_paletten"]);
                        string locatieafvalparking = Convert.ToString(item["Locatie_x0020_afvalparking"]);
                        string indaverref = Convert.ToString(item["Indaver_x0020_Referentie"]);
                        string verwerker = Convert.ToString(item["Verwerker"]);
                        string eccode = Convert.ToString(item["EC_x0020_code"]);
                        string requesttype = Convert.ToString(item["Ticket_x0020_type"]);
                        transacties.Add(new ParkingTransactie(transactie, ticketnr, datum, afdeling, product, volume, aantalvaten, aantalpaletten, locatieafvalparking, indaverref, verwerker, eccode, Utilities.GetRequestType(requesttype)));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return transacties;
        }

        public static List<Transaction> LoadParkingTransacties(DateTime from, DateTime to, string locatie, string ticketType,string eccodefilter)
        {
            List<Transaction> transacties = new List<Transaction>();
            try
            {
                SPQuery q = new SPQuery();
                string queryoutput = string.Empty;
                if (!string.IsNullOrEmpty(locatie) && !string.IsNullOrEmpty(eccodefilter))
                    queryoutput = string.Format(Constants.Config[Constants.CAML_Transacties_Parking_WithLocAndEC], eccodefilter, locatie, ticketType, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                else if (!string.IsNullOrEmpty(locatie) && string.IsNullOrEmpty(eccodefilter))
                    queryoutput = string.Format(Constants.Config[Constants.CAML_Transacties_Parking_WithLoc], locatie, ticketType, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                else if (string.IsNullOrEmpty(locatie) && !string.IsNullOrEmpty(eccodefilter))
                    queryoutput = string.Format(Constants.Config[Constants.CAML_Transacties_Parking_WithEC], eccodefilter, ticketType, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                else
                    queryoutput = string.Format(Constants.Config[Constants.CAML_Transacties_Parking_WithoutLocAndEC], ticketType, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                q.Query = queryoutput;
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Parking]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    if (item != null)
                    {
                        string transactie = Convert.ToString(item["Transactie"]);
                        string ticketnr = Convert.ToString(item["Title"]);
                        DateTime datum = Convert.ToDateTime(item["Datum"]);
                        string afdeling = Convert.ToString(item["Afdeling"]);
                        string product = Convert.ToString(item["Product"]);
                        string volume = Convert.ToString(item["Volume_x0020_per_x0020_vat"]);
                        int aantalvaten = Convert.ToInt32(item["Aantal_x0020_vaten"]);
                        int aantalpaletten = Convert.ToInt32(item["Aantal_x0020_paletten"]);
                        string locatieafvalparking = Convert.ToString(item["Locatie_x0020_afvalparking"]);
                        string indaverref = Convert.ToString(item["Indaver_x0020_Referentie"]);
                        string verwerker = Convert.ToString(item["Verwerker"]);
                        string eccode = Convert.ToString(item["EC_x0020_code"]);
                        string requesttype = Convert.ToString(item["Ticket_x0020_type"]);
                        transacties.Add(new ParkingTransactie(transactie, ticketnr, datum, afdeling, product, volume, aantalvaten, aantalpaletten, locatieafvalparking, indaverref, verwerker, eccode, Utilities.GetRequestType(requesttype)));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return transacties;
        }

        public static List<Transaction> LoadDirecteBeladingTransacties(DateTime from, DateTime to, string ticketType, string eccodefilter)
        {
            List<Transaction> transacties = new List<Transaction>();
            try
            {
                SPQuery q = new SPQuery();
                if (!string.IsNullOrEmpty(eccodefilter))
                    q.Query = string.Format(Constants.Config[Constants.CAML_Transacties_DirecteBelading_WithEC], eccodefilter, ticketType, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                else
                    q.Query = string.Format(Constants.Config[Constants.CAML_Transacties_DirecteBelading_WithoutEC], ticketType, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_DirecteBelading]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    if (item != null)
                    {
                        string transactie = Convert.ToString(item["Transactie"]);
                        string ticketnr = Convert.ToString(item["Title"]);
                        DateTime datum = Convert.ToDateTime(item["Datum"]);
                        string afdeling = Convert.ToString(item["Afdeling"]);
                        string product = Convert.ToString(item["Product"]);
                        string volume = Convert.ToString(item["Volume_x0020_per_x0020_vat"]);
                        int aantalvaten = Convert.ToInt32(item["Aantal_x0020_vaten"]);
                        int aantalpaletten = Convert.ToInt32(item["Aantal_x0020_paletten"]);
                        string eccode = Convert.ToString(item["EC_x0020_code"]);
                        string indaverref = Convert.ToString(item["Indaver_x0020_Referentie"]);
                        string verwerker = Convert.ToString(item["Verwerker"]);
                        string requesttype = Convert.ToString(item["Ticket_x0020_type"]);
                        transacties.Add(new DirecteBeladingTransactie(transactie, ticketnr, datum, afdeling, product, volume, aantalvaten, aantalpaletten, eccode, indaverref, verwerker, Utilities.GetRequestType(requesttype)));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return transacties;
        }

        public static List<Transport> LoadTransportTransacties(DateTime from, DateTime to, string afvalstroom)
        {
            List<Transport> transacties = new List<Transport>();
            try
            {
                SPQuery q = new SPQuery();
                if (!string.IsNullOrEmpty(afvalstroom))
                    q.Query = string.Format(Constants.Config[Constants.CAML_Transacties_Transport_WithStroom], afvalstroom, from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                else
                    q.Query = string.Format(Constants.Config[Constants.CAML_Transacties_Transport_WithoutStroom], from.ToString("yyyy-MM-dd"), to.ToString("yyyy-MM-dd"));
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Transport]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    if (item != null)
                    {
                        string stroom = Convert.ToString(item[Constants.Col_Title]);
                        string specificatie = Convert.ToString(item["Specificatie"]);
                        DateTime datum = Convert.ToDateTime(item["Datum"]);
                        string afdeling = Convert.ToString(item["Afdeling"]);
                        int gewicht = Convert.ToInt32(item["Gewicht"]);
                        string cmr = Convert.ToString(item["CMR"]);
                        string verwerver = Convert.ToString(item["Verwerver"]);
                        string vervoerder = Convert.ToString(item["Vervoerder"]);
                        string verwerker = Convert.ToString(item["Verwerker"]);
                        transacties.Add(new Transport(stroom, specificatie, datum, afdeling, gewicht, cmr, verwerver, vervoerder, verwerker));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return transacties;
        }
    
        public static List<Attachment> GetItemAttachments(string listname,int itemID)
        {
            List<Attachment> uploads = new List<Attachment>();
            try
            {
                SPList tickets = SPContext.Current.Web.Lists.TryGetList(listname);
                SPListItem item = tickets.GetItemById(Convert.ToInt32(itemID));
                if (item.Attachments.Count > 0)
                {
                    SPAttachmentCollection attachments = item.Attachments;
                    foreach (string fileName in attachments)
                    {
                        SPFile file = SPContext.Current.Web.GetFile(attachments.UrlPrefix + fileName);
                        uploads.Add(new Attachment(fileName, file.OpenBinary(), file.Length, "Uploaded", string.Concat(item.Attachments.UrlPrefix, fileName)));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return uploads;
        }

        public static SPListItem GetTicketByID(string itemID, RequestType requesttype)
        {
            string listname = string.Empty;
            switch (requesttype)
            {
                case RequestType.WDT:
                    listname = Constants.Config[Constants.List_WasteDisposalTicket];
                    break;
                case RequestType.ERT:
                    listname = Constants.Config[Constants.List_EmptyRecipientTicket];
                    break;
            }
            if (!string.IsNullOrEmpty(listname))
            {
                try
                {
                    Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("ID:", itemID, "----List:", listname));
                    Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("ID:", itemID, "----List:", listname));
           
                    SPList tickets = SPContext.Current.Web.Lists.TryGetList(listname);
                    SPListItem item = tickets.GetItemById(Convert.ToInt32(itemID));
                    return item;
                }
                catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            }
            return null;
        }
        
        public static Ticket LoadTicket(RequestType requestType,string itemID,string listname)
        {
            try
            {
                SPList tickets = SPContext.Current.Web.Lists.TryGetList(listname);
                SPListItem item = tickets.GetItemById(Convert.ToInt32(itemID));
                if (item != null)
                {
                    string opm_Producent = Convert.ToString(item["Opmerkingen_x0020_Producent"]);
                    string opm_Waste = Convert.ToString(item["Opmerkingen_x0020_Waste"]);
                    string opm_DO = Convert.ToString(item["Opmerkingen_x0020_DO"]);
                    string resp_producent = Utilities.GetSharePointUserField(Convert.ToString(item["Verantwoordelijke"]), (SPFieldUser)item.Fields.GetField("Verantwoordelijke"), UserProperty.Name);
                    string resp_waste = Utilities.GetSharePointUserField(Convert.ToString(item["Verantwoordelijke_x0020_Waste"]), (SPFieldUser)item.Fields.GetField("Verantwoordelijke_x0020_Waste"), UserProperty.Name);
                    string resp_do = Utilities.GetSharePointUserField(Convert.ToString(item["Verantwoordelijke_x0020_DO"]), (SPFieldUser)item.Fields.GetField("Verantwoordelijke_x0020_DO"), UserProperty.Name);
                    DateTime datum_Aanvraag = Convert.ToDateTime(item["Datum_x0020_Aanvraag"]);
                    DateTime datum_Waste = Convert.ToDateTime(item["Datum_x0020_Waste"]);
                    DateTime datum_DO = Convert.ToDateTime(item["Datum_x0020_DO"]);
                    List<ChangeLog> logs = Utilities.XMLToData_ChangeLog(Convert.ToString(item["Changelog"]));
                    switch (requestType)
                    {
                        case RequestType.WDT:
                            string productID = Convert.ToString(item["ProductID"]);
                            string product = Convert.ToString(item["Product"]);
                            string productomschrijving = Convert.ToString(item["Product_x0020_Omschrijving"]);
                            string locatieafvalvaten = Convert.ToString(item["Locatie_x0020_afvalvaten"]);
                            string aantalpaletten = Convert.ToString(item["Aantal_x0020_paletten"]);
                            string aantalvaten = Convert.ToString(item["Aantal_x0020_vaten"]);
                            string volumeID = Convert.ToString(item["VolumeID"]);
                            string volume = Convert.ToString(item["Volume_x0020_per_x0020_vat"]);
                            string ECID = Convert.ToString(item["ECID"]);
                            string EC = Convert.ToString(item["EC_x0020_code"]);
                            string SAPID = Convert.ToString(item["SAPID"]);
                            string SAP = Convert.ToString(item["SAP_x0020_nr"]);
                            string indaverID = Convert.ToString(item["INDAVERID"]);
                            string indaverref = Convert.ToString(item["INDAVER_x0020_referentie"]);
                            string UNID = Convert.ToString(item["UNID"]);
                            string UN = Convert.ToString(item["UN"]);
                            string ADRID = Convert.ToString(item["ADRID"]);
                            string ADR = Convert.ToString(item["ADR"]);
                            string ADR_Pics = Convert.ToString(item["ADR_x0020_Pictogrammen"]);
                            string locatieafvalparking = Convert.ToString(item["Locatie_x0020_afvalparking"]);
                            string palletnummer = Convert.ToString(item["Pallet_x0020_nummer"]);
                            return new WasteDisposalTicket(item.Attachments.Count, item.ID, Convert.ToString(item["Status"]), Convert.ToString(item["ID"]), Convert.ToString(item["Ticket_x0020_nr"]), Convert.ToString(item["Title"]), Convert.ToString(item["AfdelingID"]), Convert.ToString(item["Afdeling"]), productID, product, productomschrijving, locatieafvalvaten, aantalpaletten, aantalvaten, volumeID, volume, ECID, EC, SAPID, SAP, indaverID, indaverref, UNID, UN, ADRID, ADR, ADR_Pics, locatieafvalparking,palletnummer, opm_Producent, opm_Waste, opm_DO, resp_producent, resp_waste, resp_do, datum_Aanvraag, datum_Waste, datum_DO, logs);
                        case RequestType.ERT:
                            string tickettype = Convert.ToString(item["Ticket_x0020_Type"]);
                            List<Product> products = Utilities.XMLToData_Product(Convert.ToString(item["Producten"]));
                            return new EmptyRecipientTicket(item.Attachments.Count, item.ID, Convert.ToString(item["Status"]), Convert.ToString(item["ID"]), Convert.ToString(item["Ticket_x0020_nr"]), Convert.ToString(item["Title"]), tickettype, Convert.ToString(item["AfdelingID"]), Convert.ToString(item["Afdeling"]), opm_Producent, opm_Waste, opm_DO, resp_producent, resp_waste, resp_do, datum_Aanvraag, datum_Waste, datum_DO, logs, products);
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return null;
        }

        public static string GetADRIcon(int adrID)
        {
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_ADR]).GetItemById(adrID);
                if (item != null)
                    return Convert.ToString(SPContext.Current.Web.Url + Constants.CHAR_Slash + item.Url);
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return string.Empty;
        }

        public static string GetADRIconByTitle(string adr)
        {
            try
            {
                SPQuery q = new SPQuery();
                q.Query = string.Format(Constants.Config[Constants.CAML_ADRLabel], adr);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_ADR]).GetItems(q);
                if (items.Count > 0)
                    return Convert.ToString(SPContext.Current.Web.Url + Constants.CHAR_Slash + items[0].Url);
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return string.Empty;
        }

        public static string GetIndaverLookup(int indaverID)
        {
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_INDAVER]).GetItemById(indaverID);
                if (item != null)
                {
                    string label = Convert.ToString(item[Constants.Col_Label]);
                    if (!string.IsNullOrEmpty(label))
                    {
                        SPFieldLookupValue flv = new SPFieldLookupValue(Convert.ToString(label));
                        return GetIndaverLabel(flv.LookupValue);
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return string.Empty;
        }

        public static string GetIndaverLabel(string label)
        {
            try
            {
                SPQuery q = new SPQuery();
                q.Query = string.Format(Constants.Config[Constants.CAML_IndaverLabel], label);
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_INDAVER_Labels]).GetItems(q);
                if (items.Count > 0)
                    return Convert.ToString(SPContext.Current.Web.Url + Constants.CHAR_Slash + items[0].Url);
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return string.Empty;
        }

        public static SPFieldUserValueCollection SetSharePointUserField_Aanvrager(string username, string userID)
        {
            SPFieldUserValueCollection values = new SPFieldUserValueCollection();
            try
            {
                values.Add(new SPFieldUserValue(SPContext.Current.Web, Convert.ToInt32(userID), username));
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return values;
        }

        public static string GetSharePointUserField(string userstring, SPFieldUser field, UserProperty userprop)
        {
            try
            {
                if (string.IsNullOrEmpty(userstring))
                    return string.Empty;
                SPFieldUserValue fieldValue = (SPFieldUserValue)field.GetFieldValue(userstring);
                SPUser user = fieldValue.User;
                switch (userprop)
                {
                    case UserProperty.Name:
                        return user.Name;
                    case UserProperty.Login:
                        return user.LoginName;
                    case UserProperty.Email:
                        return user.Email;
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return null;
        }

        public static Status GetStatus(string status)
        {
            switch (status)
            {
                case Constants.Status_Geïnitieerd:
                    return Status.Geïnitieerd;
                case Constants.Status_InBehandeling:
                    return Status.In_Behandeling;
                case Constants.Status_Afgewerkt:
                    return Status.Afgewerkt;
                case Constants.Status_Uitgeschreven:
                    return Status.Uitgeschreven;
                case Constants.Status_TerugNaarProducent:
                    return Status.Terug_Naar_Producent;
                case Constants.Status_LabelsAfhaling:
                    return Status.LabelsAfhaling;
                case Constants.Status_DirecteBelading:
                    return Status.Directe_Belading;
                default:
                    return Status.Empty;
            }
        }

        public static string DataToXML_ChangeLog(List<ChangeLog> changeloglist)
        {
            string xmloutput = string.Empty;
            try
            {
                var stringwriter = new System.IO.StringWriter();
                Type[] types = { typeof(ChangeLog) };
                XmlSerializer serializer = new XmlSerializer(typeof(List<ChangeLog>), types);
                serializer.Serialize(stringwriter, changeloglist);
                xmloutput = stringwriter.ToString();
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return xmloutput;
        }

        public static List<ChangeLog> XMLToData_ChangeLog(string dataXML)
        {
            List<ChangeLog> list = new List<ChangeLog>();
            try
            {
                if (!string.IsNullOrEmpty(dataXML))
                {
                    using (XmlReader reader = XmlReader.Create(new StringReader(dataXML)))
                    {
                        Type[] types = { typeof(ChangeLog) };
                        XmlSerializer serializer = new XmlSerializer(typeof(List<ChangeLog>), types);
                        list = (List<ChangeLog>)serializer.Deserialize(reader);
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return list;
        }

        public static string DataToXML_Product(List<Product> products)
        {
            string xmloutput = string.Empty;
            try
            {
                var stringwriter = new System.IO.StringWriter();
                Type[] types = { typeof(Product) };
                XmlSerializer serializer = new XmlSerializer(typeof(List<Product>), types);
                serializer.Serialize(stringwriter, products);
                xmloutput = stringwriter.ToString();
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return xmloutput;
        }

        public static List<Product> XMLToData_Product(string dataXML)
        {
            List<Product> list = new List<Product>();
            try
            {
                if (!string.IsNullOrEmpty(dataXML))
                {
                    using (XmlReader reader = XmlReader.Create(new StringReader(dataXML)))
                    {
                        Type[] types = { typeof(Product) };
                        XmlSerializer serializer = new XmlSerializer(typeof(List<Product>), types);
                        list = (List<Product>)serializer.Deserialize(reader);
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return list;
        }

        public static List<ChangeLog> GetAfdelingLogs(List<ChangeLog> logs, string afdeling)
        {
            return logs.Where(l => l.Afdeling.Equals(afdeling)).ToList();
        }

        public static string GetActionIcon(ButtonAction action)
        {
            switch (action)
            {
                case ButtonAction.Save:
                    return string.Format(Constants.Config[Constants.ACTION_Save_Icon], action);
                case ButtonAction.Submit:
                    return string.Format(Constants.Config[Constants.ACTION_Submit_Icon], action);
                case ButtonAction.Return:
                    return string.Format(Constants.Config[Constants.ACTION_Return_Icon], action);
                default:
                    return string.Empty;
            }
        }

        public static Control FindChildControl(Control rootControl, string controlID)
        {
            if (rootControl.ID == controlID) return rootControl;
            foreach (Control controlToSearch in rootControl.Controls)
            {
                Control controlToReturn = FindChildControl(controlToSearch, controlID);
                if (controlToReturn != null) return controlToReturn;
            }
            return null;
        }

        public static RequestType GetRequestType(string requesttype)
        {
            switch (requesttype)
            {
                case "WDT":
                    return RequestType.WDT;
                case "ERT":
                    return RequestType.ERT;
                default:
                    return RequestType.Empty;
            }
        }
        
        public static ERT_Type GetERTType(string erttype)
        {
            switch (erttype)
            {
                case "Gereinigd":
                    return ERT_Type.Gereinigd;
                case "Ongereinigd":
                    return ERT_Type.Ongereinigd;
                default:
                    return ERT_Type.Empty;
            }
        }

        public static string GetActionIcons(int itemID, RequestType requesttype)
        {
            return string.Format(Constants.Config[Constants.Disp_Edit_Icons], requesttype, itemID, requesttype, itemID);
        }

        public static int GetMaxTicketNr(string listname, int maxnr)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = Constants.Config[Constants.CAML_MaxTicketNr];
                    SPList list = web.Lists.TryGetList(listname);
                    SPListItemCollection listitems = list.GetItems(query);
                    if (listitems.Count > 1)
                    {
                        SPListItem item = listitems[0];
                        int ticketnr = Convert.ToInt32(item[Constants.Col_TicketNr]);
                        ticketnr = ticketnr + 1;
                        return ticketnr;
                    }
                    else
                    {
                        return maxnr;
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return 0;
        }

        public static Dictionary<string, string> GetConfigValues()
        {
            Dictionary<string, string> configValues = new Dictionary<string, string>();
            try
            {
                SPList config = SPContext.Current.Web.Lists.TryGetList(Constants.List_Configuration);
                foreach (SPListItem item in config.GetItems())
                    if (!configValues.ContainsKey(Convert.ToString(item[Constants.Col_Title])))
                        configValues.Add(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_Value]));
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return configValues;
        }

        public static string GetMailTemplate(string templatepath)
        {
            string body = string.Empty;
            try
            {
                string mailtemplatepath = string.Concat(SPContext.Current.Web.Url, templatepath);
                SPFile file = SPContext.Current.Web.GetFile(mailtemplatepath);
                using (Stream filestream = file.OpenBinaryStream())
                {
                    using (StreamReader reader = new StreamReader(filestream))
                    {
                        body = reader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return body;
        }

        public static void LogErrorMessage(Exception ex,string classname,string methodname)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, classname, methodname, ex.Message);
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, classname, methodname, ex.Message);
        }

        public static void StartWF(string listname,int itemID, string workflowname)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPList list = web.Lists.TryGetList(listname);
                    SPListItem item = list.GetItemById(itemID);
                    SPWorkflowAssociationCollection associationCollection = list.WorkflowAssociations;
                    foreach (SPWorkflowAssociation association in associationCollection)
                    {
                        if (association.Name == workflowname)
                        {
                            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("Starting security workflow..., ID:", itemID));
                            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("Starting security workflow..., ID:", itemID));
                            web.Site.WorkflowManager.StartWorkflow(item, association, association.AssociationData);
                            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("Security workflow started, ID:", itemID));
                            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("Security workflow started, ID:", itemID));
                            break;
                        }
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public static bool HasAdminPermission()
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;
                return currentWeb.UserIsWebAdmin || currentWeb.UserIsSiteAdmin || currentWeb.DoesUserHavePermissions(SPBasePermissions.FullMask);
            }
            catch (SPException ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return false;
        }

        public static void CreateTransaction(string itemID, string listname, RequestType requesttype, TicketTransaction tickettransaction, TransactionType transactie)
        {
            Ticket ticket = Utilities.LoadTicket(requesttype, itemID, listname);
            if (ticket != null)
            {
                if (tickettransaction == TicketTransaction.Parking)
                {
                    ParkingTransactie pt = null;
                    if (requesttype == RequestType.WDT)
                    {
                        WasteDisposalTicket wdt = (WasteDisposalTicket)ticket;
                        pt = new ParkingTransactie(transactie.ToString(), wdt.TicketNumber, DateTime.Now, wdt.Afdeling, wdt.Product, wdt.Volume, Convert.ToInt32(wdt.AantalVaten), Convert.ToInt32(wdt.AantalPaletten), wdt.LocatieAfvalparking, wdt.EC, requesttype);
                    }
                    else if (requesttype == RequestType.ERT)
                    {
                        EmptyRecipientTicket ert = (EmptyRecipientTicket)ticket;
                        int aantalvaten = ert.Products.Sum(p => p.Aantal);
                        pt = new ParkingTransactie(transactie.ToString(), ert.TicketNumber, DateTime.Now, ert.Afdeling, aantalvaten, 0, requesttype);
                    }
                    SaveParkingTransaction(pt);
                }
                else if (tickettransaction == TicketTransaction.DirecteBelading)
                {
                    DirecteBeladingTransactie dbt = null;
                    if (requesttype == RequestType.WDT)
                    {
                        WasteDisposalTicket wdt = (WasteDisposalTicket)ticket;
                        dbt = new DirecteBeladingTransactie(transactie.ToString(), wdt.TicketNumber, DateTime.Now, wdt.Afdeling, wdt.Product, wdt.Volume, Convert.ToInt32(wdt.AantalVaten), Convert.ToInt32(wdt.AantalPaletten), wdt.EC, requesttype);
                    }
                    else if (requesttype == RequestType.ERT)
                    {
                        EmptyRecipientTicket ert = (EmptyRecipientTicket)ticket;
                        int aantalvaten = ert.Products.Sum(p => p.Aantal);
                        dbt = new DirecteBeladingTransactie(transactie.ToString(), ert.TicketNumber, DateTime.Now, ert.Afdeling, aantalvaten, 0, requesttype);
                    }
                    SaveDirecteBeladingTransaction(dbt);
                }
            }
        }

        public static void SaveParkingTransaction(ParkingTransactie parkingtransaction)
        {
            SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Parking]).Items.Add();
            if (item != null)
            {
                item[Constants.Col_Title] = parkingtransaction.TicketNumber;
                item["Datum"] = parkingtransaction.Datum;
                item["Afdeling"] = parkingtransaction.Afdeling;
                item["Product"] = parkingtransaction.Product;
                item["Volume_x0020_per_x0020_vat"] = parkingtransaction.Volume;
                item["Aantal_x0020_vaten"] = parkingtransaction.AantalVaten;
                item["Aantal_x0020_paletten"] = parkingtransaction.AantalPaletten;
                item["Locatie_x0020_afvalparking"] = parkingtransaction.LocatieAfvalvaten;
                item["Transactie"] = parkingtransaction.TransactionCode;
                item["Indaver_x0020_Referentie"] = parkingtransaction.IndaverReferentie;
                item["Verwerker"] = parkingtransaction.Verwerker;
                item["EC_x0020_code"] = parkingtransaction.ECCode;
                item["Ticket_x0020_type"] = parkingtransaction.TicketType;
                item.Update();
            }
        }

        public static void SaveDirecteBeladingTransaction(DirecteBeladingTransactie directebeladingtransaction)
        {
            SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_DirecteBelading]).Items.Add();
            if (item != null)
            {
                item["Transactie"] = directebeladingtransaction.TransactionCode;
                item[Constants.Col_Title] = directebeladingtransaction.TicketNumber;
                item["Datum"] = directebeladingtransaction.Datum;
                item["Afdeling"] = directebeladingtransaction.Afdeling;
                item["Product"] = directebeladingtransaction.Product;
                item["Volume_x0020_per_x0020_vat"] = directebeladingtransaction.Volume;
                item["Aantal_x0020_vaten"] = directebeladingtransaction.AantalVaten;
                item["Aantal_x0020_paletten"] = directebeladingtransaction.AantalPaletten;
                item["Indaver_x0020_Referentie"] = directebeladingtransaction.IndaverReferentie;
                item["Verwerker"] = directebeladingtransaction.Verwerker;
                item["Ticket_x0020_type"] = directebeladingtransaction.TicketType;
                item.Update();
            }
        }

        public static List<WasteDisposalTicket> LoadOverzichtTickets(Status status)
        {
            List<WasteDisposalTicket> tickets = new List<WasteDisposalTicket>();
            try
            {
                SPQuery q = new SPQuery();
                string queryoutput = string.Empty;
                if (status.Equals(Status.Afgewerkt))
                    queryoutput = string.Format(Constants.Config[Constants.CAML_Overzicht_Parking],status.ToString());
                else if (status.Equals(Status.Directe_Belading))
                    queryoutput = string.Format(Constants.Config[Constants.CAML_Overzicht_DirecteBelading], Constants.Status_DirecteBelading);
                q.Query = queryoutput;
                SPListItemCollection items = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_WasteDisposalTicket]).GetItems(q);
                foreach (SPListItem item in items)
                {
                    if (item != null)
                    {
                        string opm_Producent = Convert.ToString(item["Opmerkingen_x0020_Producent"]);
                        string opm_Waste = Convert.ToString(item["Opmerkingen_x0020_Waste"]);
                        string opm_DO = Convert.ToString(item["Opmerkingen_x0020_DO"]);
                        string resp_producent = Utilities.GetSharePointUserField(Convert.ToString(item["Verantwoordelijke"]), (SPFieldUser)item.Fields.GetField("Verantwoordelijke"), UserProperty.Name);
                        string resp_waste = Utilities.GetSharePointUserField(Convert.ToString(item["Verantwoordelijke_x0020_Waste"]), (SPFieldUser)item.Fields.GetField("Verantwoordelijke_x0020_Waste"), UserProperty.Name);
                        string resp_do = Utilities.GetSharePointUserField(Convert.ToString(item["Verantwoordelijke_x0020_DO"]), (SPFieldUser)item.Fields.GetField("Verantwoordelijke_x0020_DO"), UserProperty.Name);
                        DateTime datum_Aanvraag = Convert.ToDateTime(item["Datum_x0020_Aanvraag"]);
                        DateTime datum_Waste = Convert.ToDateTime(item["Datum_x0020_Waste"]);
                        DateTime datum_DO = Convert.ToDateTime(item["Datum_x0020_DO"]);
                        List<ChangeLog> logs = Utilities.XMLToData_ChangeLog(Convert.ToString(item["Changelog"]));
                        string productID = Convert.ToString(item["ProductID"]);
                        string product = Convert.ToString(item["Product"]);
                        string productomschrijving = Convert.ToString(item["Product_x0020_Omschrijving"]);
                        string locatieafvalvaten = Convert.ToString(item["Locatie_x0020_afvalvaten"]);
                        string aantalpaletten = Convert.ToString(item["Aantal_x0020_paletten"]);
                        string aantalvaten = Convert.ToString(item["Aantal_x0020_vaten"]);
                        string volumeID = Convert.ToString(item["VolumeID"]);
                        string volume = Convert.ToString(item["Volume_x0020_per_x0020_vat"]);
                        string ECID = Convert.ToString(item["ECID"]);
                        string EC = Convert.ToString(item["EC_x0020_code"]);
                        string SAPID = Convert.ToString(item["SAPID"]);
                        string SAP = Convert.ToString(item["SAP_x0020_nr"]);
                        string indaverID = Convert.ToString(item["INDAVERID"]);
                        string indaverref = Convert.ToString(item["INDAVER_x0020_referentie"]);
                        string UNID = Convert.ToString(item["UNID"]);
                        string UN = Convert.ToString(item["UN"]);
                        string ADRID = Convert.ToString(item["ADRID"]);
                        string ADR = Convert.ToString(item["ADR"]);
                        string ADR_Pics = Convert.ToString(item["ADR_x0020_Pictogrammen"]);
                        string locatieafvalparking = Convert.ToString(item["Locatie_x0020_afvalparking"]);
                        string palletnummer = Convert.ToString(item["Pallet_x0020_nummer"]);
                        tickets.Add(new WasteDisposalTicket(item.Attachments.Count, item.ID, Convert.ToString(item["Status"]), Convert.ToString(item["ID"]), Convert.ToString(item["Ticket_x0020_nr"]), Convert.ToString(item["Title"]), Convert.ToString(item["AfdelingID"]), Convert.ToString(item["Afdeling"]), productID, product, productomschrijving, locatieafvalvaten, aantalpaletten, aantalvaten, volumeID, volume, ECID, EC, SAPID, SAP, indaverID, indaverref, UNID, UN, ADRID, ADR, ADR_Pics, locatieafvalparking, palletnummer, opm_Producent, opm_Waste, opm_DO, resp_producent, resp_waste, resp_do, datum_Aanvraag, datum_Waste, datum_DO, logs));
                    }
                }
            }
            catch (Exception ex) { LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return tickets;
        }
    }
}