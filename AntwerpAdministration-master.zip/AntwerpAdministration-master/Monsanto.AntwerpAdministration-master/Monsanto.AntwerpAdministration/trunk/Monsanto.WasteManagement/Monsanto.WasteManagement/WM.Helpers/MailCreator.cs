﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using Microsoft.SharePoint;
using System.IO;
using System.Net;
using System.Reflection;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement
{
    class MailCreator
    {
        private static string LoadLabels(string ADRIDS)
        {
            string output=string.Empty;
            if (!string.IsNullOrEmpty(ADRIDS))
            {
                string[] IDs = ADRIDS.Split(',');
                output += "<tr style='height:80pt'><td width=200 style='width:150.0pt;border:none;border-bottom:solid white 1.0pt;padding:1.5pt 1.5pt 1.5pt 3.75pt;height:80pt'><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>ADR labels<o:p></o:p></span></p></td><td style='border:none;border-bottom:solid white 1.0pt;background:#F4F5F5;padding:1.5pt 1.5pt 1.5pt 1.5pt;height:29.25pt'><p class=MsoNormal>";
                foreach (string ID in IDs)
                {
                    string fileURL = Utilities.GetADRIcon(Convert.ToInt32(ID.Trim()));
                    output += "<span style='margin-right:10pt;font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'><img width=80 height=80 src='" + fileURL + "'/></span>";
                }
                output += "</p></td></tr>";
            }
            return output;
        }

        private static string PopulateBody(int itemID, RequestType requesttype, string templatepath, string listname)
        {
            string body = string.Empty;
            try
            {
                body = Utilities.GetMailTemplate(templatepath);
                Ticket ticket = Utilities.LoadTicket(requesttype, itemID.ToString(), listname);
                if (ticket != null)
                {
                    switch (requesttype)
                    {
                        case RequestType.WDT:
                            WasteDisposalTicket wdt = (WasteDisposalTicket)ticket;
                            body = body.Replace("[PRODUCT]", (string.IsNullOrEmpty(wdt.Product)) ? string.Empty : wdt.Product);
                            body = body.Replace("[LOCATIEAFVALVATEN]", (string.IsNullOrEmpty(wdt.LocatieAfvalvaten)) ? string.Empty : wdt.LocatieAfvalvaten);
                            body = body.Replace("[AANTALPALETTEN]", (string.IsNullOrEmpty(wdt.AantalPaletten)) ? string.Empty : wdt.AantalPaletten);
                            body = body.Replace("[AANTALVATEN]", (string.IsNullOrEmpty(wdt.AantalVaten)) ? string.Empty : wdt.AantalVaten);
                            body = body.Replace("[VOLUMEPERVAT]", (string.IsNullOrEmpty(wdt.Volume)) ? string.Empty : wdt.Volume);
                            body = body.Replace("[EC]", (string.IsNullOrEmpty(wdt.EC)) ? string.Empty : wdt.EC);
                            body = body.Replace("[SAP]", (string.IsNullOrEmpty(wdt.SAP)) ? string.Empty : wdt.SAP);
                            body = body.Replace("[INDAVER]", (string.IsNullOrEmpty(wdt.IndaverReferentie)) ? string.Empty : wdt.IndaverReferentie);
                            body = body.Replace("[ADR]", (string.IsNullOrEmpty(wdt.ADR) || wdt.ADR == "geen") ? "NVT" : wdt.ADR);
                            body = body.Replace("[UN]", (string.IsNullOrEmpty(wdt.UN) || wdt.UN == "Niet van toepassing") ? "NVT" : wdt.UN);
                            body = body.Replace("[LABELS]", LoadLabels(wdt.ADRID));
                            break;
                        case RequestType.ERT:
                            EmptyRecipientTicket ert = (EmptyRecipientTicket)ticket;
                            string productsoutput = string.Empty, locatiesoutput = string.Empty;
                            if (ert.Products != null)
                            {
                                foreach (Product p in ert.Products)
                                {
                                    if (string.IsNullOrEmpty(p.UN) || p.UN == "Niet van toepassing")
                                        p.UN = "NVT";
                                    if (string.IsNullOrEmpty(p.ADR) || p.ADR == "geen")
                                        p.ADR = "NVT";
                                    else
                                    {
                                        p.ADR = "<span>" + p.ADR + "</span><br/><img width='60' height='60' style='border-width: 0px;' src='" + Utilities.GetADRIconByTitle(p.ADR) + "'/>";
                                    }
                                    productsoutput += "<tr><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.Aantal + "<o:p></o:p></span></p></td><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.ProductName + "<o:p></o:p></span></p></td><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.ADR + "<o:p></o:p></span></p></td><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.UN + "<o:p></o:p></span></p></td><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.Verpakkingswijze + "<o:p></o:p></span></p></td></tr>";
                                    locatiesoutput += "<tr><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.ProductName + "<o:p></o:p></span></p></td><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.Afvalparking + "<o:p></o:p></span></p></td><td><p class=MsoNormal><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>" + p.Baan + "<o:p></o:p></span></p></td></tr>";
                                }
                            }
                            body = body.Replace("[PRODUCTEN]", (string.IsNullOrEmpty(productsoutput)) ? "<tr><td colspan='5'>Geen producten beschikbaar</td></tr>" : productsoutput);
                            body = body.Replace("[LOCATIES]", (string.IsNullOrEmpty(locatiesoutput)) ? "<tr><td colspan='5'>Geen locaties beschikbaar</td></tr>" : locatiesoutput);
                            break;
                    }
                    body = body.Replace("[STATUS]", ticket.Status);
                    body = body.Replace("[TICKETLINK]", string.Concat(Constants.Config[Constants.PageURL], "?REQUESTTYPE=", requesttype, "&FORM=display&ITEMID=", ticket.ID));
                    body = body.Replace("[TICKETLINKDISPLAY]", string.Concat(requesttype, " ", ticket.TicketNumber));
                    body = body.Replace("[AFDELING]", (string.IsNullOrEmpty(ticket.Afdeling)) ? string.Empty : ticket.Afdeling);
                    body = body.Replace("[DASHBOARDURL]", Constants.Config[Constants.SiteRootURL]);
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            return body;
        }

        public static void SendMail(int itemID, string status, RequestType requesttype, string templatepath,string listname)
        {
            Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("ID:",itemID,"----Status:",status,"----TemplatePath:",templatepath));
            Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("ID:", itemID, "----Status:", status, "----TemplatePath:", templatepath));
            MemoryStream memoryStreamOfFile = null;
            try
            {
                using (Stream filestream = SPContext.Current.Web.GetFile(Constants.Config[Constants.MailLogoPath]).OpenBinaryStream())
                {
                    SPListItem ticket = Utilities.GetTicketByID(itemID.ToString(),requesttype);
                    if (ticket != null)
                    {
                        Status statusenum = Utilities.GetStatus(status);
                        MailMessage mailMessage = new MailMessage();
                        List<string> to_users = GetToUsers(statusenum, ticket);
                        foreach (string emailaddress in to_users)
                            mailMessage.To.Add(new MailAddress(emailaddress));
                        List<string> cc_users = GetCCUsers(statusenum, ticket);
                        foreach (string emailaddress in cc_users)
                            mailMessage.CC.Add(new MailAddress(emailaddress));
                        string content;
                        LinkedResource objLinkedRes;
                        mailMessage.IsBodyHtml = true;
                        objLinkedRes = new LinkedResource(filestream);
                        objLinkedRes.ContentId = "wdt-logo";
                        string subject = string.Empty, emailapp=string.Empty;
                        switch (requesttype)
                        {
                            case RequestType.WDT:
                                subject = Constants.Config[Constants.Mail_Subject_WDT];
                                emailapp = Constants.Config[Constants.WDT_EmailApp];
                                break;
                            case RequestType.ERT:
                                subject = Constants.Config[Constants.Mail_Subject_ERT];
                                emailapp = Constants.Config[Constants.ERT_EmailApp];
                                break;
                        }
                        mailMessage.From = new MailAddress(emailapp);
                        mailMessage.Subject = string.Concat(subject, Constants.Str_Dash_Separator, Convert.ToString(ticket[Constants.Col_TicketNr]), Constants.Str_Dash_Separator, status.ToString());
                        content = PopulateBody(itemID, requesttype, templatepath, listname);
                        AlternateView objHTLMAltView = AlternateView.CreateAlternateViewFromString(content, new System.Net.Mime.ContentType("text/html"));
                        objHTLMAltView.LinkedResources.Add(objLinkedRes);
                        mailMessage.AlternateViews.Add(objHTLMAltView);
                        SmtpClient smtpClient = new SmtpClient(Constants.Config[Constants.MailSMTP]);
                        smtpClient.Send(mailMessage);
                    }
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            finally
            {
                if (memoryStreamOfFile != null)
                    memoryStreamOfFile.Close();
            }
        }

        private static List<string> GetToUsers(Status status, SPListItem item)
        {
            List<string> emaillist = new List<string>();
            switch (status)
            {
                case Status.Geïnitieerd:
                case Status.Afgewerkt: 
                    emaillist.Add(Constants.Config[Constants.WasteMailbox]);
                    break;
                case Status.In_Behandeling:
                    emaillist.Add(Constants.Config[Constants.DO_DistributionList]);
                    break;
                case Status.LabelsAfhaling:
                case Status.Terug_Naar_Producent:
                case Status.Directe_Belading:
                    emaillist.Add(Utilities.GetSharePointUserField(Convert.ToString(item[Constants.Col_Verantwoordelijke]), (SPFieldUser)item.Fields.GetField(Constants.Col_Verantwoordelijke), UserProperty.Email));
                    break;
            }
            return emaillist;
        }

        private static List<string> GetCCUsers(Status status, SPListItem item)
        {
            List<string> emaillist = new List<string>();
            switch (status)
            {
                case Status.Geïnitieerd:
                    emaillist.Add(Utilities.GetSharePointUserField(Convert.ToString(item[Constants.Col_Verantwoordelijke]), (SPFieldUser)item.Fields.GetField(Constants.Col_Verantwoordelijke), UserProperty.Email));
                    break;
                case Status.In_Behandeling: 
                    emaillist.Add(Constants.Config[Constants.WasteMailbox]);
                    break;
                case Status.Afgewerkt:
                    emaillist.Add(Constants.Config[Constants.DO_DistributionList]);
                    emaillist.Add(Utilities.GetSharePointUserField(Convert.ToString(item[Constants.Col_Verantwoordelijke]), (SPFieldUser)item.Fields.GetField(Constants.Col_Verantwoordelijke), UserProperty.Email));
                    break;
            }
            return emaillist;
        }
        
        private static void AddToEmailList(List<string> emaillist, string emailaddress)
        {
            if (!emaillist.Contains(emailaddress) && !string.IsNullOrEmpty(emailaddress))
                emaillist.Add(emailaddress);
        }

        public void SendErrorMail(string emailapp, string errormailaddress, string smtpserver)
        {
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(emailapp);
                mailMessage.To.Add(new MailAddress(errormailaddress));
                mailMessage.Subject = "Error occurred in WDT";
                //mailMessage.Body = tex.Class + "\n" + tex.Method + "\n" + tex.FriendlyMessage + "\n" + tex.Message + "\n" + tex.StackTrace + "\n" + ((tex.InnerException == null) ? string.Empty : tex.InnerException.Message);
                SmtpClient smtpClient = new SmtpClient(smtpserver);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }
    }
}