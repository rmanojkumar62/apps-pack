﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Monsanto.WasteManagement.WasteManagementWebPart;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using Monsanto.WasteManagement.WM.Enums;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class TicketControl : ControlBase
    {
        public WasteManagementUserControl wmuc { get; set; }

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }
        
        public void Page_Load(object sender, EventArgs e)
        {
            msgRequired.InnerText = Constants.Config[Constants.Message_Required_Fields];
            LoadParentControl_WDT();
            LoadParentControl_ERT();
            if (IsPostBack)
            {
                ((ButtonControl)buttonCtrl_Top).tc = this;
                ((ButtonControl)buttonCtrl_Bottom).tc = this;
            }
        }

        private void LoadParentControl_WDT()
        {
            ((WasteDisposalControl)wasteDisposalCtrl).wmuc = wmuc;
            ((WasteDisposalControl)wasteDisposalCtrl).tc = this;
        }

        private void LoadParentControl_ERT()
        {
            ((LegeRecipientenControl)legeRecipientenCtrl).wmuc = wmuc;
            ((LegeRecipientenControl)legeRecipientenCtrl).tc = this;
        }

        public override void LoadForm(SPControlMode controlmode, RequestType requesttype)
        {
            lblTicket.Text = GetEmptyTicketName(requesttype);
            switch (GetRequestType())
            {
                case RequestType.WDT:
                    ((WasteDisposalControl)wasteDisposalCtrl).LoadForm(controlmode, requesttype);
                    wasteDisposalCtrl.Visible = true;
                    legeRecipientenCtrl.Visible = false;
                    break;
                case RequestType.ERT:
                    ert_type.InnerText = GetERTType().ToString();
                    ((LegeRecipientenControl)legeRecipientenCtrl).LoadForm(controlmode, requesttype);
                    wasteDisposalCtrl.Visible = false;
                    legeRecipientenCtrl.Visible = true;
                    break;
            }
            LoadButtonControl(controlmode, requesttype, string.Empty);
        }

        public override void LoadForm(SPControlMode controlmode, RequestType requesttype, string itemID)
        {
            try
            {
                Ticket ticket = Utilities.LoadTicket(requesttype, itemID, GetListName(requesttype));
                if (ticket != null)
                {
                    ticketID.Value = ticket.TicketID;
                    ticketNumber.Value = ticket.TicketNumber;
                    if (string.IsNullOrEmpty(ticket.TicketName))
                        lblTicket.Text = string.Concat(GetEmptyTicketName(requesttype), Constants.Str_Dash_Separator, ticket.TicketNumber);
                    else
                        lblTicket.Text = ticket.TicketName;
                    lblStatus.Text = ticket.Status;
                    LoadWasteControl(ticket);
                    LoadDOControl(ticket);
                    LoadChangeLogControl(ticket);
                    switch (controlmode)
                    {
                        case SPControlMode.Display:
                            DisplayMode(ticket);
                            break;
                        case SPControlMode.Edit:
                            EditMode(ticket);
                            break;
                    }
                    switch (GetRequestType())
                    {
                        case RequestType.WDT:
                            LoadParentControl_WDT();
                            ((WasteDisposalControl)wasteDisposalCtrl).LoadForm(controlmode, ticket);
                            wasteDisposalCtrl.Visible = true;
                            legeRecipientenCtrl.Visible = false;
                            break;
                        case RequestType.ERT:
                            LoadParentControl_ERT();
                            SetERTType(Utilities.GetERTType(((EmptyRecipientTicket)ticket).TicketType));
                            ert_type.InnerText = GetERTType().ToString();
                            ((LegeRecipientenControl)legeRecipientenCtrl).LoadForm(controlmode, ticket);
                            wasteDisposalCtrl.Visible = false;
                            legeRecipientenCtrl.Visible = true;
                            break;
                    }
                    LoadButtonControl(controlmode, requesttype, ticket.Status);
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public override void DisplayMode(Ticket ticket)
        {
            msgRequired.Visible = false;
            DisableControls();
        }

        public override void DisableControls()
        {
            DisableWaste();
            DisableDO();
        }
        
        private void LoadWasteControl(Ticket ticket)
        {
            ((DepartmentControl)wasteCtrl).LoadControl(Afdeling.Waste);
            ((DepartmentControl)wasteCtrl).LoadData(Afdeling.Waste, ticket.VerantwoordelijkeWaste, ticket.DatumWaste, ticket.OpmerkingWaste, ticket.Status);
        }

        private void LoadDOControl(Ticket ticket)
        {
            ((DepartmentControl)doCtrl).LoadControl(Afdeling.DO);
            ((DepartmentControl)doCtrl).LoadData(Afdeling.DO, ticket.VerantwoordelijkeDO, ticket.DatumDO, ticket.OpmerkingDO, ticket.Status);
        }

        private void LoadChangeLogControl(Ticket ticket)
        {
            ((ChangeLogControl)changeLogCtrl).LoadLogs(ticket.Logs);
            changeLogCtrl.Visible = true;
        }

        private void LoadButtonControl(SPControlMode controlmode,RequestType requesttype, string status)
        {
            ((ButtonControl)buttonCtrl_Top).tc = this;
            ((ButtonControl)buttonCtrl_Top).LoadButtons(controlmode, Utilities.GetStatus(status), requesttype);
            ((ButtonControl)buttonCtrl_Bottom).tc = this;
            ((ButtonControl)buttonCtrl_Bottom).LoadButtons(controlmode, Utilities.GetStatus(status), requesttype);
        }
        
        private void DisableWaste()
        {
            ((DepartmentControl)wasteCtrl).DisableControls();
        }

        private void DisableDO()
        {
            ((DepartmentControl)doCtrl).DisableControls();
        }

        public override void EditMode(Ticket ticket)
        {
            //WASTE - ALL EDITABLE
            //DO - ALWAYS DISABLE WASTE SECTION + DISABLE DO IF NO DO ACTION IS REQUIRED (STATUS!= In Behandeling)
            if (Utilities.IsDO())
            {
                DisableWaste();
                if (ticket.Status.Equals(Constants.Status_Geïnitieerd) || 
                    ticket.Status.Equals(Constants.Status_TerugNaarProducent) ||
                    ticket.Status.Equals(Constants.Status_LabelsAfhaling) ||
                    ticket.Status.Equals(Constants.Status_Afgewerkt) || 
                    ticket.Status.Equals(Constants.Status_Uitgeschreven))
                    DisableDO();
            }
            //AANVRAGER - ALWAYS DISABLE WASTE & DO SECTION
            if (GetAanvragerName().Equals(SPContext.Current.Web.CurrentUser.Name))
                DisableControls();
        }

        public void SaveProducent(SPListItem item)
        {
            switch (GetRequestType())
            {
                case RequestType.WDT:
                    ((WasteDisposalControl)wasteDisposalCtrl).SaveProducent(item);
                    break;
                case RequestType.ERT:
                    ((LegeRecipientenControl)legeRecipientenCtrl).SaveProducent(item);
                    break;
            }
        }

        public void SaveWaste(SPListItem item, ButtonAction action)
        {
            if (GetRequestType() == RequestType.WDT)
                ((WasteDisposalControl)wasteDisposalCtrl).SaveLocatieParking(item);
            if (action == ButtonAction.Submit || action == ButtonAction.Return)
            {
                SPFieldUserValue userValue = new SPFieldUserValue(SPContext.Current.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                item["Verantwoordelijke_x0020_Waste"] = userValue;
                item["Datum_x0020_Waste"] = DateTime.Now;
            }
            item["Opmerkingen_x0020_Waste"] = ((DepartmentControl)wasteCtrl).GetRemarks();
        }

        public void SaveDO(SPListItem item, ButtonAction action)
        {
            if (GetRequestType() == RequestType.WDT)
                ((WasteDisposalControl)wasteDisposalCtrl).SaveLocatieParking(item);
            if (action == ButtonAction.Submit || action == ButtonAction.Return)
            {
                SPFieldUserValue userValue = new SPFieldUserValue(SPContext.Current.Web, SPContext.Current.Web.CurrentUser.ID, SPContext.Current.Web.CurrentUser.LoginName);
                item["Verantwoordelijke_x0020_DO"] = userValue;
                item["Datum_x0020_DO"] = DateTime.Now;
            }
            item["Opmerkingen_x0020_DO"] = ((DepartmentControl)doCtrl).GetRemarks();
        }

        public void SaveChangeLog(SPListItem item, ButtonAction action, string oldstatus, string newstatus)
        {
            if (item != null)
            {
                string afdeling = string.Empty;
                if (Utilities.IsWaste())
                    afdeling = "Waste";
                else if (Utilities.IsDO())
                    afdeling = "DO";
                List<ChangeLog> logs = ((ChangeLogControl)changeLogCtrl).GetChangeLog();
                logs.Add(new ChangeLog(SPContext.Current.Web.CurrentUser.Name, afdeling, DateTime.Now, action, oldstatus, newstatus));
                ((ChangeLogControl)changeLogCtrl).SetChangeLog(logs);
                item["Changelog"] = Utilities.DataToXML_ChangeLog(logs);
                try
                {
                    item.Update();
                }
                catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            }
        }

        public void SendMail(int ID, string status)
        {
            RequestType requesttype = GetRequestType();
            switch (requesttype)
            {
                case RequestType.WDT:
                    MailCreator.SendMail(ID, status, RequestType.WDT, Constants.Config[Constants.MailTemplate_WDT], GetListName(requesttype));
                    break;
                case RequestType.ERT:
                    MailCreator.SendMail(ID, status, RequestType.ERT, Constants.Config[Constants.MailTemplate_ERT], GetListName(requesttype));
                    break;
            }
        }

        public void CreateTransaction(TicketTransaction tickettransaction)
        {
            Utilities.CreateTransaction(GetTicketID(), GetListName(GetRequestType()), GetRequestType(), tickettransaction, TransactionType.IN);
        }

        private string GetEmptyTicketName(RequestType requesttype)
        {
            switch (requesttype)
            {
                case RequestType.WDT:
                    return Constants.Config[Constants.title_WDT];
                case RequestType.ERT:
                    return Constants.Config[Constants.title_ERT];
            }
            return string.Empty;
        }

        public string GetListName(RequestType requesttype)
        {
            switch (requesttype)
            {
                case RequestType.WDT:
                    return Constants.Config[Constants.List_WasteDisposalTicket];
                case RequestType.ERT:
                    return Constants.Config[Constants.List_EmptyRecipientTicket];
            }
            return string.Empty;
        }

        public string GetStatus()
        {
            return lblStatus.Text;
        }
        
        public string GetTicketID()
        {
            return ticketID.Value;
        }

        public string GetTicketNumber()
        {
            return ticketNumber.Value;
        }

        public bool IsAanvrager()
        {
            return SPContext.Current.Web.CurrentUser.Name == GetAanvragerName();
        }

        public string GetAanvragerName()
        {
            switch (GetRequestType())
            {
                case RequestType.WDT:
                    return ((WasteDisposalControl)wasteDisposalCtrl).GetAanvragerName();
                case RequestType.ERT:
                    return ((LegeRecipientenControl)legeRecipientenCtrl).GetAanvragerName();
            }
            return string.Empty;
        }

        public string GetAanvragerID()
        {
            switch (GetRequestType())
            {
                case RequestType.WDT:
                    return ((WasteDisposalControl)wasteDisposalCtrl).GetAanvragerID();
                case RequestType.ERT:
                    return ((LegeRecipientenControl)legeRecipientenCtrl).GetAanvragerID();
            }
            return string.Empty;
        }

        public List<ChangeLog> GetChangeLog()
        {
            return ((ChangeLogControl)changeLogCtrl).GetChangeLog();
        }

        public void SetRequestType(RequestType requesttype)
        {
            ViewState["RequestType"] = requesttype;
        }

        public RequestType GetRequestType()
        {
            return (RequestType)ViewState["RequestType"];
        }

        public void SetERTType(ERT_Type requesttype)
        {
            ViewState["ERT_Type"] = requesttype;
        }

        public ERT_Type GetERTType()
        {
            if (ViewState["ERT_Type"] == null)
                return ERT_Type.Empty;
            else
                return (ERT_Type)ViewState["ERT_Type"];
        }
    }
}