﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class ChangeLogControl : UserControl
    {
        protected void Page_Load(object sender, EventArgs e) 
        {
            headingChangeLog_text.InnerText = Constants.Config[Constants.Control_Heading_ChangeLog];
            if (IsPostBack)
                LoadLogs(GetChangeLog());
        }

        public void LoadLogs(List<ChangeLog> logs)
        {
            if (logs != null)
            {
                if (logs.Count > 0)
                    badgeChangeLog.InnerText = logs.Count.ToString();
                foreach (ChangeLog log in logs)
                {
                    HtmlTableRow row = new HtmlTableRow();
                    HtmlTableCell cell = new HtmlTableCell();
                    cell.InnerText = log.Verantwoordelijke;
                    cell.Attributes.Add("class", "col-xs-4");
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.InnerText = log.Afdeling;
                    cell.Attributes.Add("class", "col-xs-2");
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.InnerText = log.Datum.ToString(Constants.Format_Timestamp);
                    cell.Attributes.Add("class", "col-xs-2");
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.InnerHtml = log.OldStatus;
                    cell.Attributes.Add("class", "col-xs-1");
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.InnerHtml = log.NewStatus;
                    cell.Attributes.Add("class", "col-xs-1");
                    row.Cells.Add(cell);
                    cell = new HtmlTableCell();
                    cell.InnerHtml = Utilities.GetActionIcon(log.Action);
                    cell.Attributes.Add("class", "col-xs-1");
                    row.Cells.Add(cell);
                    tablechangelog.Rows.Add(row);
                }
                SetChangeLog(logs);
            }
        }

        public void SetChangeLog(List<ChangeLog> logs)
        {
            ViewState["ChangeLog"] = logs;
        }

        public List<ChangeLog> GetChangeLog()
        {
            List<ChangeLog> logs = (List<ChangeLog>)ViewState["ChangeLog"];
            if (logs == null)
                logs = new List<ChangeLog>();
            return logs;
        }
    }
}