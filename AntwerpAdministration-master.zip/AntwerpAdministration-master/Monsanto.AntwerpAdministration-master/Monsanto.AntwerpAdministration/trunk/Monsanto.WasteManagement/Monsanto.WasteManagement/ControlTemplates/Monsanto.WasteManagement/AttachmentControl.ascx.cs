﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;
using System.Linq;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class AttachmentControl : ControlBase
    {
        public TicketControl tc { get; set; }

        protected void Page_Load(object sender, EventArgs e) 
        {
            headingBijlagen_text.InnerText = Constants.Config[Constants.Control_Heading_Attachment];
            btnAddAttachment_text.InnerText = Constants.Config[Constants.Button_AddAttachment];
            btnBrowse_text.InnerText = Constants.Config[Constants.Button_Browse];
            btnUpload_text.InnerText = Constants.Config[Constants.Button_Upload];
            btnCancelAttachment_text.InnerText = Constants.Config[Constants.Button_Cancel];
            lblNoAttachments.Text = Constants.Config[Constants.Label_NoAttachments];
            if (GetAttachments().Count <= 0)
                pnlBijlagen.CssClass = "form-group hideprint";
            if (IsPostBack)
                BuildAttachmentTable(GetAttachments(), GetAttachmentMode(), GetAttachmentStatus());
        }

        public override void DisplayMode(Ticket ticket)
        {
            if (ticket.AttachmentCount <= 0)
            {
                row_noattachments.Visible = true;
                row_attachmentlist.Visible = false;
            }
        }

        public void LoadAttachments(SPControlMode controlmode,string status, int itemID,string listname)
        {
            SetAttachmentMode(controlmode);
            SetAttachmentStatus(status);
            row_uploadattachment.Attributes.Add("style", "display:none");
            switch (controlmode)
            {
                case SPControlMode.New:
                    row_addattachment.Visible = true;
                    row_noattachments.Visible = true;
                    break;
                case SPControlMode.Display:
                case SPControlMode.Edit:
                    SetAttachments(Utilities.GetItemAttachments(listname, itemID));
                    BuildAttachmentTable(GetAttachments(), controlmode, status);
                    row_addattachment.Visible = HasEditPermission(controlmode, status);
                    break;
            }
        }

        protected void btnAddAttachment_Click(object sender, EventArgs e)
        {
            row_addattachment.Visible = false;
            row_uploadattachment.Attributes.Remove("style");
            row_noattachments.Visible = false;
            row_attachmentlist.Visible = false;
        }

        protected void btnCancelAttachment_Click(object sender, EventArgs e)
        {
            row_addattachment.Visible = true;
            row_uploadattachment.Attributes.Add("style", "display:none");
            CheckAttachmentCount();
        }

        protected void btnUploadAttachment_Click(object sender, EventArgs e)
        {
            List<Attachment> attachments = GetAttachments();
            if (inputFile.HasFile)
            {
                if (attachments.Where(a => a.FileName.Equals(inputFile.FileName)).Count() <= 0)
                {
                    attachments.Add(new Attachment(inputFile.FileName, inputFile.FileBytes, inputFile.PostedFile.ContentLength, "Ready for upload"));
                    SetAttachments(attachments);
                    BuildAttachmentTable(attachments, GetAttachmentMode(), GetAttachmentStatus());
                }
            }
            row_addattachment.Visible = true;
            row_uploadattachment.Attributes.Add("style", "display:none");
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "BindCollapser();", true);
        }

        protected void btnDeleteAttachment_Click(object sender, EventArgs e)
        {
            List<Attachment> attachments = GetAttachments();
            string index = ((HtmlButton)sender).ID.Split('_')[1];
            if (!string.IsNullOrEmpty(index))
            {
                Attachment att = attachments.ElementAt(Convert.ToInt32(index));
                if (att.FileStatus.Equals("Uploaded"))
                    att.FileStatus = "Deleted";
                else
                    attachments.RemoveAt(Convert.ToInt32(index));
            }
            SetAttachments(attachments);
            BuildAttachmentTable(attachments, GetAttachmentMode(),GetAttachmentStatus());
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "BindCollapser();", true);
        }

        private void CheckAttachmentCount()
        {
            int count = GetAttachments().Where(a => !a.FileStatus.Equals("Deleted")).Count();
            if (count > 0)
            {
                row_attachmentlist.Visible = true;
                row_noattachments.Visible = false;
            }
            else
            {
                row_attachmentlist.Visible = false;
                row_noattachments.Visible = true;
            }
        }

        private void BuildAttachmentTable(List<Attachment> attachments, SPControlMode controlmode,string status)
        {
            tableattachments.Rows.Clear();
            if (attachments.Count > 0)
            {
                int count = attachments.Where(a => !a.FileStatus.Equals("Deleted")).Count();
                if (count > 0)
                    badgeBijlagen.InnerText = count.ToString();
                else
                    badgeBijlagen.InnerText = string.Empty;
                CreateTableHeaderRow(controlmode);
                int counter = 0;
                foreach (Attachment attachment in attachments)
                {
                    if (!attachment.FileStatus.Equals("Deleted"))
                        CreateTableDataRow(controlmode, attachment, counter, status);
                    counter++;
                }
            }
            else
                badgeBijlagen.InnerText = string.Empty;
            CheckAttachmentCount();
        }

        private void CreateTableHeaderRow(SPControlMode controlmode)
        {
            TableHeaderRow hrow = new TableHeaderRow();
            TableHeaderCell hcell = new TableHeaderCell();
            hcell.Text = "Name";
            hrow.Cells.Add(hcell);
            hcell = new TableHeaderCell();
            hcell.Text = "Size";
            hrow.Cells.Add(hcell);
            hcell = new TableHeaderCell();
            hcell.Text = "Status";
            hrow.Cells.Add(hcell);
            if (controlmode != SPControlMode.Display)
            {
                hcell = new TableHeaderCell();
                hcell.Text = "";
                hcell.CssClass = "hideprint";
                hrow.Cells.Add(hcell);
            }
            tableattachments.Rows.Add(hrow);
        }

        private void CreateTableDataRow(SPControlMode controlmode,Attachment attachment,int counter,string status)
        {
            TableRow row = new TableRow();
            TableCell cell = new TableCell();
            if (!string.IsNullOrEmpty(attachment.FileURL))
            {
                HtmlAnchor a = new HtmlAnchor();
                a.HRef = attachment.FileURL;
                a.Target = "_blank";
                a.InnerText = attachment.FileName;
                cell.Controls.Add(a);
            }
            else
                cell.Text = attachment.FileName;
            row.Cells.Add(cell);
            cell = new TableCell();
            cell.Text = attachment.FileSizeString;
            row.Cells.Add(cell);
            cell = new TableCell();
            cell.Text = attachment.FileStatus;
            row.Cells.Add(cell);
            if (controlmode != SPControlMode.Display)
            {
                if (HasEditPermission(controlmode, status))
                {
                    cell = new TableCell();
                    HtmlButton btn = new HtmlButton();
                    btn.CausesValidation = false;
                    btn.ID = "btnDeleteAttachment_" + counter;
                    btn.Attributes.Add("class", "btn btn-success hideprint");
                    btn.InnerHtml = "<i class='fa fa-times'></i>";
                    btn.ServerClick += new EventHandler(btnDeleteAttachment_Click);
                    cell.Controls.Add(btn);
                    row.Cells.Add(cell);
                }
            }
            tableattachments.Rows.Add(row);
        }

        private void SetAttachmentMode(SPControlMode mode)
        {
            ViewState["AttachmentMode"] = mode;
        }

        private SPControlMode GetAttachmentMode()
        {
            if (ViewState["AttachmentMode"] == null)
                return SPControlMode.Invalid;
            else
                return (SPControlMode)ViewState["AttachmentMode"];
        }
        
        private void SetAttachmentStatus(string status)
        {
            ViewState["AttachmentStatus"] = status;
        }

        private string GetAttachmentStatus()
        {
            if (ViewState["AttachmentStatus"] == null)
                return string.Empty;
            else
                return (string)ViewState["AttachmentStatus"];
        }

        public void SetAttachments(List<Attachment> attachments)
        {
            ViewState["Attachments"] = attachments;
        }
        
        public List<Attachment> GetAttachments()
        {
            List<Attachment> attachments = (List<Attachment>)ViewState["Attachments"];
            if (attachments == null)
                attachments = new List<Attachment>();
            return attachments;
        }

        private bool HasEditPermission(SPControlMode controlmode, string status)
        {
            bool haspermission = false;
            if (controlmode == SPControlMode.Edit)
            {
                switch (status)
                {
                    case Constants.Status_Geïnitieerd:
                    //case Constants.Status_LabelsBevestiging:
                    //case Constants.Status_Afgewerkt:
                        if (Utilities.IsWaste())
                            haspermission = true;
                        break;
                    case Constants.Status_InBehandeling:
                        if (Utilities.IsDO())
                            haspermission = true;
                        break;
                    case Constants.Status_TerugNaarProducent:
                    case Constants.Status_LabelsAfhaling:
                        if(tc.IsAanvrager())
                            haspermission = true;
                        break;
                }
            }
            else if (controlmode == SPControlMode.New)
                if (tc.IsAanvrager())
                    haspermission = true;
            return haspermission;
        }
    }
}