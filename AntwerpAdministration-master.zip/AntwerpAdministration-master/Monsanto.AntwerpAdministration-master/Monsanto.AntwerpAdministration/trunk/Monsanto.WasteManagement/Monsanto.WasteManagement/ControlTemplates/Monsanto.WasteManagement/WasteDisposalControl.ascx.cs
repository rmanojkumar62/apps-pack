﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.WebControls;
using System.Text;
using System.Web;
using Microsoft.SharePoint;
using System.IO;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;
using System.Collections;
using Monsanto.WasteManagement.WasteManagementWebPart;
using System.Linq;
using System.Reflection;
using Monsanto.WasteManagement.WM.Enums;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class WasteDisposalControl : ControlBase
    {
        public WasteManagementUserControl wmuc { get; set; }
        public TicketControl tc { get; set; }

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        public void Page_Load(object sender, EventArgs e)
        {
            headerProducent.InnerText = Constants.Config[Constants.Control_Heading_Producent];
            headerAfvalparking.InnerText = Constants.Config[Constants.Control_Heading_AfvalParking_Waste];
            headingADR_text.InnerText = Constants.Config[Constants.Control_Heading_ADR];
            headingINDAVER_text.InnerText = Constants.Config[Constants.Control_Heading_INDAVER];
            ((AttachmentControl)attachmentCtrl).tc = tc;
            if (IsPostBack)
            {
                pnlADRIcons.Controls.Clear();
                bool isItemSelected = false;
                string outputIDs = string.Empty;
                string outputValues = string.Empty;
                foreach (ListItem li in checkADR.Items)
                {
                    if (li.Selected)
                    {
                        outputIDs = string.Concat(outputIDs, li.Value, ", ");
                        outputValues = string.Concat(outputValues, li.Text, ", ");
                        AddADRIcon(Convert.ToInt32(li.Value));
                        isItemSelected = true;
                    }
                }
                outputIDs = outputIDs.TrimEnd(new char[] { ',', ' ' });
                outputValues = outputValues.TrimEnd(new char[] { ',', ' ' });
                lblADR_Value.Text = outputValues;
                ADR_ID.Value = outputIDs;
                if (isItemSelected)
                    lblADRIcons.Visible = false;
                LoadIndaverLabel();
            }
            if (lblADRIcons.Visible)
                pnlADRLabels.CssClass = "form-group pnlADRLabels hideprint";
            if(lblIndaverLabel.Visible)
                pnlINDAVER.CssClass = "form-group pnlINDAVER hideprint";
        }

        private void LoadParentControl_WDT()
        {
            ((AttachmentControl)attachmentCtrl).tc = tc;
        }

        public override void LoadForm(SPControlMode controlmode, RequestType requesttype)
        {
            lblAanvrager.Text = SPContext.Current.Web.CurrentUser.Name;
            Aanvrager_ID.Value = SPContext.Current.Web.CurrentUser.ID.ToString();
            lblDatumAanvraag.Text = DateTime.Now.ToString(Constants.Format_Date);
            Utilities.LoadMasterValues(dropAfdeling, Constants.Config[Constants.List_Afdelingen], Constants.Config[Constants.CAML_Afdelingen], Constants.Config[Constants.drop_Message_Afdeling]);
            Utilities.LoadMasterValues(dropVolumes, Constants.Config[Constants.List_Volumes], Constants.Config[Constants.CAML_Volumes], Constants.Config[Constants.drop_Message_Volume]);
            LoadParentControl_WDT();
            ((AttachmentControl)attachmentCtrl).LoadAttachments(controlmode,string.Empty, -1, Constants.Config[Constants.List_WasteDisposalTicket]);
        }

        public override void LoadForm(SPControlMode controlmode, Ticket ticket)
        {
            try
            {
                LoadProducent(ticket);
                LoadLocatie(ticket);
                LoadParentControl_WDT();
                ((AttachmentControl)attachmentCtrl).LoadAttachments(controlmode, ticket.Status, ticket.ID, Constants.Config[Constants.List_WasteDisposalTicket]);
                pnlAfvalParking.Visible = true;
                switch (controlmode)
                {
                    case SPControlMode.Display:
                        DisplayMode(ticket);
                        break;
                    case SPControlMode.Edit:
                        EditMode(ticket);
                        break;
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public override void DisplayMode(Ticket ticket)
        {
            ((AttachmentControl)attachmentCtrl).DisplayMode(ticket);
            DisableControls();
        }

        public override void DisableControls()
        {
            DisableProducent();
            DisableLocatie();
        }

        private void DisableProducent()
        {
            dropAfdeling.Enabled = false;
            rfvAfdeling.Enabled = false;
            dropProduct.Enabled = false;
            rfvProduct.Enabled = false;
            txtProductOmschrijving.Enabled = false;
            rfvProductOmschrijving.Enabled = false;
            txtLocatieAfvalvaten.Enabled = false;
            rfvLocatie.Enabled = false;
            txtPaletten.Enabled = false;
            rfvPaletten.Enabled = false;
            regexPaletten.Enabled = false;
            txtVaten.Enabled = false;
            rfvVaten.Enabled = false;
            regexVaten.Enabled = false;
            dropVolumes.Enabled = false;
            rfvVolume.Enabled = false;
            lblADR_Value.Visible = true;
            checkADR.Visible = false;
            checkNVT.Visible = false;
            checkADR.Enabled = false;
            rfvADR.Enabled = false;
            checkNVT.Enabled = false;
            txtUN_Value.Enabled = false;
            regexUN.Enabled = false;
            txtOpmerkingen_Producent.Enabled = false;
        }

        private void DisableLocatie()
        {
            dropLocatie1.Enabled = false;
            dropLocatie2.Enabled = false;
            rfvLocatie1.Enabled = false;
            rfvLocatie2.Enabled = false;
            txtPalletNummer.Enabled = false;
        }

        private void LoadProducent(Ticket ticket)
        {
            WasteDisposalTicket wdt = (WasteDisposalTicket)ticket;
            Utilities.LoadMasterValues(dropAfdeling, Constants.Config[Constants.List_Afdelingen], Constants.Config[Constants.CAML_Afdelingen], Constants.Config[Constants.drop_Message_Afdeling]);
            Utilities.LoadProducts(wdt.AfdelingID, dropProduct, Constants.Config[Constants.drop_Message_Product]);
            Utilities.LoadMasterValues(dropVolumes, Constants.Config[Constants.List_Volumes], Constants.Config[Constants.CAML_Volumes], Constants.Config[Constants.drop_Message_Volume]);
            string[] ids = wdt.ADRID.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string id in ids)
                AddADRIcon(Convert.ToInt32(id.Trim()));
            lblAanvrager.Text = wdt.VerantwoordelijkeProducent;
            lblDatumAanvraag.Text = wdt.DatumAanvraag.ToString(Constants.Format_Date);
            dropAfdeling.SelectedValue = wdt.AfdelingID;
            dropProduct.SelectedValue = wdt.ProductID;
            txtProductOmschrijving.Text = wdt.ProductOmschrijving;
            txtLocatieAfvalvaten.Text = wdt.LocatieAfvalvaten;
            txtPaletten.Text = wdt.AantalPaletten;
            txtVaten.Text = wdt.AantalVaten;
            dropVolumes.SelectedValue = wdt.VolumeID;
            Volume_ID.Value = wdt.VolumeID;
            EC_ID.Value = wdt.ECID;
            lblEC_Value.Text = wdt.EC;
            SAP_ID.Value = wdt.SAPID;
            lblSAP_Value.Text = wdt.SAP;
            INDAVER_ID.Value = wdt.IndaverID;
            lblINDAVER_Value.Text = wdt.IndaverReferentie;
            ADR_ID.Value = wdt.ADRID;
            lblADR_Value.Text = wdt.ADR;
            if (wdt.ADR == "Niet van toepassing")
            {
                checkNVT.Checked = true;
                NoADRLabels();
            }
            else
            {
                lblADRIcons.Visible = false;
            }
            if (wdt.Product.Equals("Andere"))
            {
                row_ProductOmschrijving.Visible = true;
            }
            UN_ID.Value = wdt.UNID;
            lblUN_Value.Text = wdt.UN;
            txtUN_Value.Text = wdt.UN;
            txtOpmerkingen_Producent.Text = wdt.OpmerkingProducent;
            LoadIndaverLabel();
        }

        private void NoADRLabels()
        {
            lblADRIcons.Visible = true;
            pnlADRIcons.Controls.Clear();
            badgeADR.InnerText = string.Empty;
        }

        private void LoadIndaverLabel()
        {
            if (!string.IsNullOrEmpty(INDAVER_ID.Value))
            {
                AddIndaverLabel(Convert.ToInt32(INDAVER_ID.Value));
                if (pnlIndaverLabel.Controls.Count > 0)
                    lblIndaverLabel.Visible = false;
            }
        }

        private void LoadLocatie(Ticket ticket)
        {
            WasteDisposalTicket wdt = (WasteDisposalTicket)ticket;
            string locatieafvalparking = wdt.LocatieAfvalparking;
            if (locatieafvalparking.Equals("Directe belading"))
            {
                row_locatieAfvalparking.Visible = false;
                row_palletNummer.Visible = false;
                row_locatieAfvalparkingNVT.Visible = true;
            }
            else
            {
                Utilities.LoadLocaties(dropLocatie1, dropLocatie2, Constants.Config[Constants.drop_Message_Locatie]);
                if (!string.IsNullOrEmpty(locatieafvalparking))
                {
                    dropLocatie1.SelectedValue = locatieafvalparking.Split('-')[0];
                    dropLocatie2.SelectedValue = locatieafvalparking.Split('-')[1];
                }
                if (!string.IsNullOrEmpty(wdt.PalletNummer))
                    txtPalletNummer.Text = wdt.PalletNummer;
                row_palletNummer.Visible = true;
                row_locatieAfvalparking.Visible = true;
                row_locatieAfvalparkingNVT.Visible = false;
            }
        }
       
        public override void EditMode(Ticket ticket)
        {
            WasteDisposalTicket wdt = (WasteDisposalTicket)ticket;
            if ((wdt.Status.Equals(Constants.Status_Geïnitieerd)) && Utilities.IsWaste())
            {
                if (!wdt.LocatieAfvalparking.Equals("Directe belading"))
                {
                    dropLocatie1.Enabled = true;
                    dropLocatie2.Enabled = true;
                    rfvLocatie1.Enabled = true;
                    rfvLocatie2.Enabled = true;
                }
            }
            if (wdt.ADR == "Niet van toepassing")
            {
                checkADR.Enabled = false;
                txtUN_Value.Enabled = false;
                ADR_ID.Value = string.Empty;
                rfvADR.Enabled = false;
                rfvUN.Enabled = false;
                regexUN.Enabled = false;
            }
            if (wdt.Product.Equals("Andere"))
            {
                row_ProductOmschrijving.Visible = true;
                rfvProductOmschrijving.Enabled = true;
                dropVolumes.Enabled = true;
                rfvVolume.Enabled = true;
                lblADR_Value.Visible = false;
                checkADR.Visible = true;
                checkNVT.Visible = true;
                lblUN_Value.Visible = false;
                txtUN_Value.Visible = true;
            }
            else
            {
                dropVolumes.Enabled = false;
                rfvVolume.Enabled = false;
                lblADR_Value.Visible = true;
                checkADR.Visible = false;
                checkNVT.Visible = false;
                lblUN_Value.Visible = true;
                txtUN_Value.Visible = false;
            }
            if(ticket.Status.Equals(Constants.Status_Uitgeschreven))
                DisplayMode(ticket);
            else if (Utilities.IsWaste())
            {
                Utilities.LoadADR(dropProduct.SelectedItem.Value, checkADR);
                string[] adrs = wdt.ADR.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string adr in adrs)
                    foreach (ListItem li in checkADR.Items)
                        if (li.Text.Equals(adr.Trim()))
                            li.Selected = true;
            }
            else if (Utilities.IsDO())
            {
                DisableControls();
            }
            else
            {
                if ((ticket.Status.Equals(Constants.Status_TerugNaarProducent)|| ticket.Status.Equals(Constants.Status_LabelsAfhaling))&& lblAanvrager.Text.Equals(SPContext.Current.Web.CurrentUser.Name))
                    DisableLocatie();
                else
                    DisplayMode(ticket);
            }
        }

        private void ResetProductInfo()
        {
            row_ProductOmschrijving.Visible = false;
            txtProductOmschrijving.Text = string.Empty;
            rfvProductOmschrijving.Enabled = false;
            dropVolumes.SelectedIndex = -1;
            dropVolumes.Enabled = false;
            rfvVolume.Enabled = false;
            lblEC_Value.Text = string.Empty;
            lblSAP_Value.Text = string.Empty;
            lblINDAVER_Value.Text = string.Empty;
            lblUN_Value.Text = string.Empty;
            lblUN_Value.Visible = true;
            txtUN_Value.Text = string.Empty;
            txtUN_Value.Visible = false;
            lblADR_Value.Text = string.Empty;
            NoADRLabels();
            lblADR_Value.Visible = true;
            checkADR.Visible = false;
            checkADR.Items.Clear();
            checkNVT.Visible = false;
            lblIndaverLabel.Visible = true;
            pnlIndaverLabel.Controls.Clear();
            badgeINDAVER.InnerText = string.Empty;
            rfvADR.Enabled = false;
            rfvUN.Enabled = false;
            regexUN.Enabled = false;
        }

        protected void dropAfdeling_SelectedIndexChanged(object sender, EventArgs e)
        {
            dropProduct.Items.Clear();
            ResetProductInfo();
            if (dropAfdeling.SelectedIndex > 0)
                Utilities.LoadProducts(dropAfdeling.SelectedItem.Value, dropProduct, Constants.Config[Constants.drop_Message_Product]);
        }

        protected void dropProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetProductInfo();
            if (dropProduct.SelectedIndex > 0)
            {
                Utilities.LoadADR(dropProduct.SelectedItem.Value, checkADR);
                if (dropProduct.SelectedItem.Text.Equals("Andere"))
                {
                    row_ProductOmschrijving.Visible = true;
                    rfvProductOmschrijving.Enabled = true;
                    dropVolumes.Enabled = true;
                    rfvVolume.Enabled = true;
                    lblSAP_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
                    lblUN_Value.Visible = false;
                    txtUN_Value.Visible = true;
                    lblADR_Value.Visible = false;
                    checkADR.Visible = true;
                    checkNVT.Visible = true;
                    if (!checkNVT.Checked)
                    {
                        rfvADR.Enabled = true;
                        rfvUN.Enabled = true;
                        regexUN.Enabled = true;
                    }
                }
                LoadProductData(Convert.ToInt32(dropProduct.SelectedValue));
            }
        }

        protected void checkADR_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblADRIcons.Visible = true;
            pnlADRIcons.Controls.Clear();
            bool isItemSelected = false;
            string outputIDs = string.Empty;
            string outputValues = string.Empty;
            foreach (ListItem li in ((CheckBoxList)sender).Items)
            {
                if (li.Selected)
                {
                    outputIDs = string.Concat(outputIDs, li.Value, ", ");
                    outputValues = string.Concat(outputValues, li.Text, ", ");
                    AddADRIcon(Convert.ToInt32(li.Value));
                    isItemSelected = true;
                }
            }
            outputIDs = outputIDs.TrimEnd(new char[] { ',', ' ' });
            outputValues = outputValues.TrimEnd(new char[] { ',', ' ' });
            lblADR_Value.Text = outputValues;
            ADR_ID.Value = outputIDs;
            if (isItemSelected)
                lblADRIcons.Visible = false;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "RequestEnded();", true);
        }

        protected void checkNVT_CheckedChanged(object sender, EventArgs e)
        {
            if (checkNVT.Checked)
            {
                checkADR.Enabled = false;
                txtUN_Value.Enabled = false;
                txtUN_Value.Text = "Niet van toepassing";
                foreach (ListItem li in checkADR.Items)
                    if (li.Selected)
                        li.Selected = false;
                lblADR_Value.Text = string.Empty;
                NoADRLabels();
                ADR_ID.Value = string.Empty;
                rfvADR.Enabled = false;
                rfvUN.Enabled = false;
                regexUN.Enabled = false;
            }
            else
            {
                checkADR.Enabled = true;
                txtUN_Value.Enabled = true;
                txtUN_Value.Text = string.Empty;;
                rfvADR.Enabled = true;
                rfvUN.Enabled = true;
                regexUN.Enabled = true;
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "RequestEnded();", true);
        }

        protected void rfvADR_ServerValidate(object sender, ServerValidateEventArgs e)
        {
            bool isItemSelected = false;
            foreach (ListItem li in checkADR.Items)
                if (li.Selected){
                    isItemSelected = true;
                    break;
                }
            e.IsValid = isItemSelected;
        }

        private void LoadProductData(int productID)
        {
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Producten]).GetItemById(productID);
                LoadProduct_Volume(Convert.ToString(item["Volume"]));
                LoadProduct_EC(Convert.ToString(item["EC"]));
                LoadProduct_SAP(Convert.ToString(item["SAP"]));
                LoadProduct_Indaver(Convert.ToString(item["INDAVER"]));
                LoadProduct_UN(Convert.ToString(item["UN"]));
                var flvc_ADR = item["ADR"] as SPFieldLookupValueCollection;
                if (flvc_ADR != null)
                {
                    if (flvc_ADR.Count > 0)
                    {
                        string outputIDs = string.Empty;
                        string outputValues = string.Empty;
                        foreach (SPFieldLookupValue flv_ADR in flvc_ADR)
                        {
                            if (flv_ADR != null)
                            {
                                foreach (ListItem li in checkADR.Items)
                                    if (li.Text.Equals(flv_ADR.LookupValue))
                                        li.Selected = true;
                                outputIDs = string.Concat(outputIDs, flv_ADR.LookupId, ", ");
                                outputValues = string.Concat(outputValues, flv_ADR.LookupValue, ", ");
                                AddADRIcon(flv_ADR.LookupId);
                            }
                        }
                        outputIDs = outputIDs.TrimEnd(new char[] { ',', ' ' });
                        outputValues = outputValues.TrimEnd(new char[] { ',', ' ' });
                        lblADR_Value.Text = outputValues;
                        ADR_ID.Value = outputIDs;
                        lblADRIcons.Visible = false;
                    }
                    else
                    {
                        lblADR_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
                    }
                }
                else
                {
                    lblADR_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        private void LoadProduct_Volume(string volume) 
        {
            if (!string.IsNullOrEmpty(volume))
            {
                SPFieldLookupValue flv = new SPFieldLookupValue(volume);
                Volume_ID.Value = flv.LookupId.ToString();
                dropVolumes.SelectedValue = flv.LookupId.ToString();
            }
        }

        private void LoadProduct_EC(string ec) 
        {
            if (!string.IsNullOrEmpty(ec))
            {
                SPFieldLookupValue flv = new SPFieldLookupValue(ec);
                lblEC_Value.Text = flv.LookupValue;
                EC_ID.Value = flv.LookupId.ToString();
            }
            else
            {
                lblEC_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
            }
        }

        private void LoadProduct_SAP(string sap) 
        {
            if (!string.IsNullOrEmpty(sap))
            {
                SPFieldLookupValue flv = new SPFieldLookupValue(sap);
                lblSAP_Value.Text = flv.LookupValue;
                SAP_ID.Value = flv.LookupId.ToString();
            }
            else
            {
                lblSAP_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
            }
        }

        private void LoadProduct_Indaver(string indaver) 
        {
            if (!string.IsNullOrEmpty(indaver))
            {
                SPFieldLookupValue flv = new SPFieldLookupValue(indaver);
                lblINDAVER_Value.Text = flv.LookupValue;
                INDAVER_ID.Value = flv.LookupId.ToString();
                AddIndaverLabel(flv.LookupId);
                if (pnlIndaverLabel.Controls.Count > 0)
                    lblIndaverLabel.Visible = false;
            }
            else
            {
                lblINDAVER_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
            }
        }

        private void LoadProduct_UN(string un)
        {
            if (!string.IsNullOrEmpty(un))
            {
                SPFieldLookupValue flv = new SPFieldLookupValue(un);
                lblUN_Value.Text = flv.LookupValue;
                UN_ID.Value = flv.LookupId.ToString();
            }
            else
            {
                lblUN_Value.Text = Constants.Config[Constants.str_NietVanToepassing];
            }
        }

        private void AddADRIcon(int ADR_ID)
        {
            string imgsrc = Utilities.GetADRIcon(ADR_ID);
            if (!string.IsNullOrEmpty(imgsrc))
            {
                HtmlImage img = new HtmlImage();
                img.Src = imgsrc;
                img.Attributes.Add("class", "adricon");
                pnlADRIcons.Controls.Add(img);
                badgeADR.InnerText = pnlADRIcons.Controls.Count.ToString();
            }
        }

        private void AddIndaverLabel(int INDAVER_ID)
        {
            string imgsrc = Utilities.GetIndaverLookup(INDAVER_ID);
            if (!string.IsNullOrEmpty(imgsrc))
            {
                HtmlImage img = new HtmlImage();
                img.Src = imgsrc;
                img.Attributes.Add("class", "indaverlabel");
                pnlIndaverLabel.Controls.Add(img);
                badgeINDAVER.InnerText = pnlIndaverLabel.Controls.Count.ToString();
            }
        }

        public void SaveProducent(SPListItem item)
        {
            if (item != null)
            {
                try
                {
                    item["AfdelingID"] = dropAfdeling.SelectedItem.Value;
                    item["Afdeling"] = dropAfdeling.SelectedItem.Text;
                    item["ProductID"] = dropProduct.SelectedItem.Value;
                    item["Product"] = dropProduct.SelectedItem.Text;
                    if (!string.IsNullOrEmpty(txtProductOmschrijving.Text))
                        item["Product_x0020_Omschrijving"] = txtProductOmschrijving.Text;
                    item["Locatie_x0020_afvalvaten"] = txtLocatieAfvalvaten.Text;
                    item["Aantal_x0020_paletten"] = Convert.ToInt32(txtPaletten.Text);
                    item["Aantal_x0020_vaten"] = Convert.ToInt32(txtVaten.Text);
                    SaveProduct_Volume(item);
                    SaveProduct_EC(item);
                    SaveProduct_SAP(item);
                    SaveProduct_Indaver(item);
                    SaveProduct_UN(item);
                    if (!string.IsNullOrEmpty(lblADR_Value.Text))
                    {
                        item["ADRID"] = ADR_ID.Value;
                        item["ADR"] = lblADR_Value.Text;
                    }
                    if (dropProduct.SelectedItem.Text.Equals("Andere"))
                    {
                        string adr_ids = string.Empty;
                        string adr_values = string.Empty;
                        foreach (ListItem adritem in checkADR.Items)
                            if (adritem.Selected)
                            {
                                adr_ids = string.Concat(adr_ids, adritem.Value, ", ");
                                adr_values = string.Concat(adr_values, adritem.Text, ", "); ;
                            }
                        item["ADRID"] = adr_ids.Trim(new char[] { ',', ' ' });
                        item["ADR"] = adr_values.Trim(new char[] { ',', ' ' });
                    }
                    if (!string.IsNullOrEmpty(ADR_ID.Value))
                    {
                        SPFieldMultiLineText mlt = item.Fields.GetField("ADR_x0020_Pictogrammen") as SPFieldMultiLineText;
                        mlt.RichTextMode = SPRichTextMode.FullHtml;
                        item["ADR_x0020_Pictogrammen"] = BuildADRPictogrammen();
                    }
                    item["Opmerkingen_x0020_Producent"] = txtOpmerkingen_Producent.Text;
                    item.Update();
                    SaveAttachments(item);
                }
                catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            }
        }

        private void SaveProduct_Volume(SPListItem item)
        {
            if (dropProduct.SelectedItem.Text.Equals("Andere"))
            {
                item["VolumeID"] = dropVolumes.SelectedItem.Value;
                item["Volume_x0020_per_x0020_vat"] = dropVolumes.SelectedItem.Text;
            }
            else
            {
                item["VolumeID"] = Volume_ID.Value;
                item["Volume_x0020_per_x0020_vat"] = dropVolumes.SelectedItem.Text;
            }
        }

        private void SaveProduct_EC(SPListItem item)
        {
            if (!string.IsNullOrEmpty(lblEC_Value.Text))
            {
                item["ECID"] = EC_ID.Value;
                item["EC_x0020_code"] = lblEC_Value.Text;
            }
        }

        private void SaveProduct_SAP(SPListItem item)
        {
            if (!string.IsNullOrEmpty(lblSAP_Value.Text))
            {
                item["SAPID"] = SAP_ID.Value;
                item["SAP_x0020_nr"] = lblSAP_Value.Text;
            }
        }

        private void SaveProduct_Indaver(SPListItem item)
        {
            if (!string.IsNullOrEmpty(lblINDAVER_Value.Text))
            {
                item["INDAVERID"] = INDAVER_ID.Value;
                item["INDAVER_x0020_referentie"] = lblINDAVER_Value.Text;
            }
        }

        private void SaveProduct_UN(SPListItem item)
        {
            if (!string.IsNullOrEmpty(lblUN_Value.Text))
            {
                item["UNID"] = UN_ID.Value;
                item["UN"] = lblUN_Value.Text;
            }
            if (dropProduct.SelectedItem.Text.Equals("Andere"))
            {
                item["UN"] = txtUN_Value.Text;
            }
        }

        private string BuildADRPictogrammen()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<div style='width:500px;'>");
            string[] ids = ADR_ID.Value.Split(',');
            foreach (string adrid in ids)
            {
                string fileurl = Utilities.GetADRIcon(Convert.ToInt32(adrid.Trim()));
                sb.Append("<span style='margin-right:10px;'><img width=80 height=80 src='" + fileurl + "'/></span>");
            }
            sb.Append("</div>");
            return sb.ToString();
        }

        public void SaveLocatieParking(SPListItem item)
        {
            item["Locatie_x0020_afvalparking"] = string.Concat(dropLocatie1.SelectedValue, "-", dropLocatie2.SelectedValue);
            item["Pallet_x0020_nummer"] = txtPalletNummer.Text;
        }

        private void SaveAttachments(SPListItem item)
        {
            List<Attachment> uploads = ((AttachmentControl)attachmentCtrl).GetAttachments();
            List<string> fileNames_ToDelete = new List<string>();
            if (uploads.Count > 0)
            {
                for (int i = 0; i < uploads.Count; i++)
                {
                    if (!string.IsNullOrEmpty(uploads[i].FileName)&&uploads[i].FileStatus.Equals("Ready for upload"))
                    {
                        SPAttachmentCollection attachments = item.Attachments;
                        string fileName = Path.GetFileName(uploads[i].FileName);
                        attachments.Add(fileName, uploads[i].FileContent);
                    }
                }
                foreach (Attachment att in uploads)
                    if(att.FileStatus.Equals("Deleted"))
                        fileNames_ToDelete.Add(att.FileName);
                foreach (string fileName in fileNames_ToDelete)
                    item.Attachments.Delete(fileName);
                try
                {
                    item.Update();
                }
                catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            }
        }

        /**** CONTROL PROPERTIES ****/
        public string GetAanvragerName()
        {
            return lblAanvrager.Text;
        }

        public string GetAanvragerID()
        {
            return Aanvrager_ID.Value;
        }
    }
}