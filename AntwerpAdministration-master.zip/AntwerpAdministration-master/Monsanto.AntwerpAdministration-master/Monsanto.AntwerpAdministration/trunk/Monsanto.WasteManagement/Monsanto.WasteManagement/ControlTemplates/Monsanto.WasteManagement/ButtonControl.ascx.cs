﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Microsoft.SharePoint;
using System.Reflection;
using Microsoft.SharePoint.WebControls;
using Monsanto.WasteManagement.WM.Enums;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class ButtonControl : UserControl
    {
        public TicketControl tc { get; set; }

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        private string GetAanvrager()
        {
            string aanvrager = string.Empty;
            if (tc != null) 
                aanvrager = tc.GetAanvragerName();
            return aanvrager;
        }

        private string GetAanvragerID()
        {
            string aanvragerID = string.Empty;
            if (tc != null)
                aanvragerID = tc.GetAanvragerID();
            return aanvragerID;
        }

        private string GetStatus()
        {
            string status = string.Empty;
            if (tc != null)
                status = tc.GetStatus();
            return status;
        }
        
        private string GetTicketID()
        {
            string ticketID = string.Empty;
            if(tc!=null)
                ticketID = tc.GetTicketID();
            return ticketID;
        }

        public void LoadButtons(SPControlMode controlmode, Status status,RequestType requestType)
        {
            switch (controlmode)
            {
                case SPControlMode.New:
                    LoadButtons_NEW();
                    break;
                case SPControlMode.Display:
                    LoadButtons_DISPLAY(status,requestType);
                    btnPrint_text.InnerText = Constants.Config[Constants.Button_Print];
                    btnPrint.Visible = true;
                    break;
                case SPControlMode.Edit:
                    LoadButtons_EDIT(status, requestType);
                    btnPrint_text.InnerText = Constants.Config[Constants.Button_Print];
                    btnPrint.Visible = true;
                    break;
            }
            btnClose_text.InnerText = Constants.Config[Constants.Button_Sluiten];
            btnClose.Visible = true;
        }

        private void LoadButtons_NEW()
        {
            btnSend_text.InnerText = Constants.Config[Constants.Button_AanvraagVerzenden];
            btnSend.Visible = true;
        }

        private void LoadButtons_DISPLAY(Status status, RequestType requestType)
        {
            string aanvrager = GetAanvrager();
            switch (status)
            {
                case Status.Geïnitieerd:
                case Status.Afgewerkt:
                    if (Utilities.IsWaste())
                    {
                        btnEdit_text.InnerText = Constants.Config[Constants.Button_Editeer];
                        btnEdit.Visible = true;
                    }
                    break;
                case Status.In_Behandeling:
                    if (Utilities.IsDO())
                    {
                        btnEdit_text.InnerText = Constants.Config[Constants.Button_Editeer];
                        btnEdit.Visible = true;
                    }
                    break;
                case Status.Terug_Naar_Producent:
                case Status.LabelsAfhaling:
                    if (aanvrager.Equals(SPContext.Current.Web.CurrentUser.Name) || Utilities.HasAdminPermission())
                    {
                        btnEdit_text.InnerText = Constants.Config[Constants.Button_Editeer];
                        btnEdit.Visible = true;
                    }
                    break;
            }
        }

        private void LoadButtons_EDIT(Status status, RequestType requestType)
        {
            string aanvrager = GetAanvrager();
            switch (status)
            {
                case Status.Geïnitieerd:
                    if (Utilities.IsWaste())
                    {
                        if (requestType.Equals(RequestType.WDT))
                        {
                            btnSend_text.InnerText = Constants.Config[Constants.Button_LabelsAfhaling];
                            if (tc.GetChangeLog().Count > 1)
                            {
                                btnProceed_text.InnerText = Constants.Config[Constants.Button_StuurDO];
                                btnProceed.Visible = true;
                            }
                        }
                        else if (requestType.Equals(RequestType.ERT))
                        {
                            btnSend_text.InnerText = Constants.Config[Constants.Button_StuurDO];
                        }
                        if (tc.GetChangeLog().Count <= 1)
                        {
                            btnDirecteBelading_text.InnerText = Constants.Config[Constants.Button_DirecteBelading];
                            btnDirecteBelading.Visible = true;
                        }
                        btnSend.Visible = true;
                        btnReject_text.InnerText = Constants.Config[Constants.Button_TerugNaarProducent];
                        btnReject.Visible = true;
                        btnSave_text.InnerText = Constants.Config[Constants.Button_Opslaan];
                        btnSave.Visible = true;
                    }
                    break;
                case Status.LabelsAfhaling:
                    if ((!Utilities.IsDO() && aanvrager.Equals(SPContext.Current.Web.CurrentUser.Name)) || Utilities.HasAdminPermission())
                    {
                        btnSend_text.InnerText = Constants.Config[Constants.Button_LabelsBevestiging];
                        btnSend.Visible = true;
                    }
                    break;
                case Status.In_Behandeling:
                    if (Utilities.IsDO())
                    {
                        btnSend_text.InnerText = Constants.Config[Constants.Button_Afgewerkt];
                        btnSend.Visible = true;
                        btnReject_text.InnerText = Constants.Config[Constants.Button_TerugNaarWaste];
                        btnReject.Visible = true;
                    }
                    if (Utilities.IsWaste() || Utilities.IsDO())
                    {
                        btnSave_text.InnerText = Constants.Config[Constants.Button_Opslaan];
                        btnSave.Visible = true;
                    }
                    break;
                case Status.Afgewerkt:
                case Status.Directe_Belading:
                    if (Utilities.IsWaste())
                    {
                        btnSend_text.InnerText = Constants.Config[Constants.Button_Afsluiten];
                        btnSend.Visible = true;
                        btnReject.Visible = false;
                        btnSave_text.InnerText = Constants.Config[Constants.Button_Opslaan];
                        btnSave.Visible = true;
                    }
                    break;
                case Status.Uitgeschreven:
                    btnSend.Visible = false;
                    btnReject.Visible = false;
                    btnProceed.Visible = false;
                    btnSave.Visible = false;
                    break;
                case Status.Terug_Naar_Producent:
                    if ((!Utilities.IsDO() && aanvrager.Equals(SPContext.Current.Web.CurrentUser.Name)) || Utilities.HasAdminPermission())
                    {
                        btnSend_text.InnerText = Constants.Config[Constants.Button_AanvraagVerzenden];
                        btnSend.Visible = true;
                    }
                    break;
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.Url.ToString().Replace("display", "edit"), false);
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            string button = ((HtmlGenericControl)((HtmlButton)sender).Controls[1]).InnerText;
            if (button.Equals(Constants.Config[Constants.Button_Afsluiten]))
            {
                if (GetStatus().Equals(Status.Afgewerkt.ToString()))
                    Response.Redirect(string.Concat(SPContext.Current.Web.Url,"/_layouts/Monsanto.WasteManagement/Uitschrijven.aspx?REQUESTTYPE=", tc.GetRequestType(), "&TICKETID=", GetTicketID()), false);
                else
                    Response.Redirect(string.Concat(SPContext.Current.Web.Url, "/_layouts/Monsanto.WasteManagement/Uitschrijven.aspx?REQUESTTYPE=", tc.GetRequestType(), "&TICKETID=", GetTicketID(), "&DIRECTEBELADING=TRUE"), false);
            }
            else
            {
                if (button.Equals(Constants.Config[Constants.Button_AanvraagVerzenden]) && string.IsNullOrEmpty(GetStatus()))
                    SubmitNewItem();
                else
                    SubmitExistingItem(button);
                ShowConfirmation(ButtonAction.Submit, button);
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), "BindCollapser();", true);
            }
        }

        protected void btnReject_Click(object sender, EventArgs e)
        {
            string button = string.Empty, status = string.Empty,oldstatus=string.Empty;
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(tc.GetListName(tc.GetRequestType())).GetItemById(Convert.ToInt32(GetTicketID()));
                if (item != null)
                {
                    oldstatus = GetStatus();
                    if (oldstatus.Equals(Constants.Status_Geïnitieerd))
                    {
                        status = Constants.Status_TerugNaarProducent;
                        item[Constants.Col_Status] = status;
                        button = "Waste";
                        SaveWaste(item, ButtonAction.Return);
                    }
                    else if (oldstatus.Equals(Constants.Status_InBehandeling))
                    {
                        if(tc.GetRequestType()==RequestType.WDT)
                            status = Constants.Status_Geïnitieerd;
                        else if (tc.GetRequestType() == RequestType.ERT)
                            status = Constants.Status_Geïnitieerd;
                        item[Constants.Col_Status] = status;
                        button = "DO";
                        SaveDO(item, ButtonAction.Return);
                    }
                    item.Update();
                    SaveChangeLog(item, ButtonAction.Return, oldstatus, status);
                    SendMail(item.ID, status);
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            ShowConfirmation(ButtonAction.Return, button);
        }

        protected void btnDirecteBelading_Click(object sender, EventArgs e)
        {
            string oldstatus = GetStatus();
            string status = Constants.Status_DirecteBelading;
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(tc.GetListName(tc.GetRequestType())).GetItemById(Convert.ToInt32(Request.QueryString["ITEMID"]));
                SaveWaste(item, ButtonAction.Submit);
                CreateTransaction(TicketTransaction.DirecteBelading);
                item[Constants.Col_Status] = status;
                item.Update();
                SaveChangeLog(item, ButtonAction.Submit, oldstatus, status);
                SendMail(item.ID, status);
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(tc.GetListName(tc.GetRequestType())).GetItemById(Convert.ToInt32(GetTicketID()));
                if (item != null)
                {
                    string status = GetStatus();
                    if (status.Equals(Constants.Status_Geïnitieerd) || status.Equals(Constants.Status_Afgewerkt))
                        SaveWaste(item, ButtonAction.Save);
                    else if (status.Equals(Constants.Status_InBehandeling))
                    {
                        if (Utilities.IsWaste())
                            SaveWaste(item, ButtonAction.Save);
                        SaveDO(item, ButtonAction.Save);
                    }
                    else if (status.Equals(Constants.Status_LabelsAfhaling))
                        SaveProducent(item);
                    item.Update();
                    SaveChangeLog(item, ButtonAction.Save, status, status);
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            ShowConfirmation(ButtonAction.Save, string.Empty);
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url, false);
            Context.ApplicationInstance.CompleteRequest();
        }

        private void SubmitNewItem()
        {
            try
            {
                RequestType rt = tc.GetRequestType();
                string listname = tc.GetListName(rt);
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(listname).Items.Add();
                if (item != null)
                {
                    string oldstatus = "-";
                    string status = Constants.Status_Geïnitieerd;
                    item[Constants.Col_Status] = status;
                    item[Constants.Col_Verantwoordelijke] = Utilities.SetSharePointUserField_Aanvrager(GetAanvrager(), GetAanvragerID());
                    item["Datum_x0020_Aanvraag"] = DateTime.Now;
                    item.Update();
                    int maxticketnumber = 0;
                    string title = string.Empty;
                    string wf = string.Empty;
                    bool wfenabled = false;
                    switch (rt)
                    {
                        case RequestType.WDT:
                            maxticketnumber = Constants.max_ticket_nr_WDT;
                            title = Constants.Config[Constants.title_WDT];
                            wf = Constants.Config["Workflow_WDT_Name"];
                            wfenabled = Constants.Config["Workflow_WDT_Enabled"] == "true";
                            break;
                        case RequestType.ERT:
                            maxticketnumber = Constants.max_ticket_nr_ERT;
                            title = Constants.Config[Constants.title_ERT];
                            wf = Constants.Config["Workflow_ERT_Name"];
                            wfenabled = Constants.Config["Workflow_ERT_Enabled"] == "true";
                            item["Ticket_x0020_Type"] = tc.GetERTType().ToString();
                            break;
                    }
                    int ticketnr = Utilities.GetMaxTicketNr(listname, maxticketnumber);
                    item[Constants.Col_Title] = string.Concat(title, Constants.Str_Dash_Separator, ticketnr);
                    item[Constants.Col_TicketNr] = ticketnr;
                    SPFieldMultiLineText mlt = item.Fields.GetField("Actions") as SPFieldMultiLineText;
                    mlt.RichTextMode = SPRichTextMode.FullHtml;
                    item["Actions"] = Utilities.GetActionIcons(item.ID, rt);
                    item.Update();
                    SaveProducent(item);
                    Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("New item - producent saved, proceed with log, ID:", item.ID));
                    Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("New item - producent saved, proceed with log, ID:", item.ID));
                    SaveChangeLog(item, ButtonAction.Submit, oldstatus, status);
                    int itemID = item.ID;
                    SendMail(itemID, status);
                    if(wfenabled)
                        Utilities.StartWF(listname, itemID, wf);
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        private void SubmitExistingItem(string button)
        {
            string status = string.Empty;
            string oldstatus = GetStatus();
            try
            {
                SPListItem item = SPContext.Current.Web.Lists.TryGetList(tc.GetListName(tc.GetRequestType())).GetItemById(Convert.ToInt32(Request.QueryString["ITEMID"]));
                if (item != null)
                {
                    if (button.Equals(Constants.Config[Constants.Button_AanvraagVerzenden]))
                    {
                        status = Constants.Status_Geïnitieerd;
                        SaveProducent(item);
                    }
                    else if (button.Equals(Constants.Config[Constants.Button_LabelsAfhaling]))
                    {
                        status = Constants.Status_LabelsAfhaling;
                        SaveWaste(item, ButtonAction.Submit);
                    }
                    else if (button.Equals(Constants.Config[Constants.Button_LabelsBevestiging]))
                    {
                        status = Constants.Status_InBehandeling; 
                        SaveProducent(item);
                    }
                    else if (button.Equals(Constants.Config[Constants.Button_StuurDO]))
                    {
                        status = Constants.Status_InBehandeling;
                        SaveWaste(item, ButtonAction.Submit);
                    }
                    else if (button.Equals(Constants.Config[Constants.Button_Afgewerkt]))
                    {
                        status = Constants.Status_Afgewerkt;
                        SaveDO(item, ButtonAction.Submit);
                        CreateTransaction(TicketTransaction.Parking);
                    }
                    else if (button.Equals(Constants.Config[Constants.Button_Afsluiten]))
                    {
                        status = Constants.Status_Uitgeschreven;
                        SaveWaste(item, ButtonAction.Submit);
                    }
                    item[Constants.Col_Status] = status;
                    item.Update();
                    Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("Existing item - producent saved, proceed with log, ID:", item.ID));
                    Microsoft.Office.Server.Diagnostics.PortalLog.LogString(Constants.LogString, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), string.Concat("Existing item - producent saved, proceed with log, ID:", item.ID));
                   
                    SaveChangeLog(item, ButtonAction.Submit, oldstatus, status);
                    SendMail(item.ID, status);
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        private void SaveProducent(SPListItem item)
        {
            tc.SaveProducent(item);
        }

        private void SaveWaste(SPListItem item, ButtonAction action)
        {
            tc.SaveProducent(item);
            tc.SaveWaste(item, action);
        }

        private void SaveDO(SPListItem item, ButtonAction action)
        {
            tc.SaveDO(item, action);
        }

        private void SaveChangeLog(SPListItem item, ButtonAction action, string oldstatus, string newstatus)
        {
            tc.SaveChangeLog(item, action, oldstatus, newstatus);
        }

        private void ShowConfirmation(ButtonAction action, string button)
        {
            tc.wmuc.ShowConfirmation(action, button);
        }

        private void SendMail(int ID,string status)
        {
            tc.SendMail(ID,status);
        }

        private void CreateTransaction(TicketTransaction tickettransaction)
        {
            tc.CreateTransaction(tickettransaction);
        }
    }
}