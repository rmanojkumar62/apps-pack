﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using Microsoft.SharePoint.WebControls;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public class ControlBase: UserControl
    {
        public virtual void LoadForm(SPControlMode controlmode, RequestType requesttype) { }

        public virtual void LoadForm(SPControlMode controlmode, RequestType requesttype, string itemID) { }

        public virtual void LoadForm(SPControlMode controlmode, Ticket ticket) { }

        public virtual void DisplayMode(Ticket ticket) { }

        public virtual void EditMode(Ticket ticket) { }

        public virtual void DisableControls() { }
    }
}
