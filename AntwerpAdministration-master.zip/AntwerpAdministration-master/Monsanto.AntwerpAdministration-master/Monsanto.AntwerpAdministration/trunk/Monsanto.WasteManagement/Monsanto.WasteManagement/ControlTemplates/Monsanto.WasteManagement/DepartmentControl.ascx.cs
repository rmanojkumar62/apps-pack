﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class DepartmentControl : ControlBase
    {
        public void LoadControl(Afdeling afdeling)
        {
            switch (afdeling)
            {
                case Afdeling.Waste:
                    headerDepartment.InnerText = Constants.Config[Constants.Department_WasteManagement_Header];
                    lblDepartment.InnerText = Constants.Config[Constants.Department_WasteManagement_Responsible];
                    lblDate.InnerText = Constants.Config[Constants.Department_WasteManagement_Date];
                    lblOpmerkingen.InnerText = Constants.Config[Constants.Department_WasteManagement_Remarks];
                    break;
                case Afdeling.DO:
                    headerDepartment.InnerText = Constants.Config[Constants.Department_DO_Header];
                    lblDepartment.InnerText = Constants.Config[Constants.Department_DO_Responsible];
                    lblDate.InnerText = Constants.Config[Constants.Department_DO_Date];
                    lblOpmerkingen.InnerText = Constants.Config[Constants.Department_DO_Remarks];
                    break;
            }
            rfvOpmerkingen.ErrorMessage = Constants.Config[Constants.Department_RFV_Opmerkingen];
        }

        public void LoadData(Afdeling afdeling,string responsible,DateTime date,string remarks,string status)
        {
            if (!string.IsNullOrEmpty(responsible))
            {
                peopleDepartment.Text = responsible;
                dateDepartment.Text = date.ToString(Constants.Format_Date);
                row_Department_Responsible.Visible = true;
                row_Department_Date.Visible = true;
            }
            if (!string.IsNullOrEmpty(remarks))
                txtOpmerkingen.Text = remarks;
            switch (afdeling)
            {
                case Afdeling.Waste:
                    if (status.Equals(Constants.Status_Geïnitieerd))
                    {
                        txtOpmerkingen.Enabled = true;
                        rfvOpmerkingen.Enabled = true;
                    }
                    break;
                case Afdeling.DO:
                    if (status.Equals(Constants.Status_InBehandeling))
                    {
                        txtOpmerkingen.Enabled = true;
                        rfvOpmerkingen.Enabled = true;
                    }
                    break;
            }
            this.pnlDepartment.Visible = true;
        }

        public override void DisableControls()
        {
            txtOpmerkingen.Enabled = false;
            rfvOpmerkingen.Enabled = false;
        }

        public string GetRemarks()
        {
            return txtOpmerkingen.Text;
        }
    }
}
