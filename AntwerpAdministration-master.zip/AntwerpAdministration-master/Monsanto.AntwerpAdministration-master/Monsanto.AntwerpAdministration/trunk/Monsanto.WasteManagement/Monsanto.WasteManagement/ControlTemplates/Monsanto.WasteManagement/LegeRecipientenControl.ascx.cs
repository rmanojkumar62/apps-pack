﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using Microsoft.SharePoint.WebControls;
using System.Data;
using System.Linq;
using System.Collections;
using System.Web;
using System.IO;
using Monsanto.WasteManagement.WasteManagementWebPart;
using System.Text;
using Monsanto.WasteManagement.WM.Enums;
using System.Reflection;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement
{
    public partial class LegeRecipientenControl : ControlBase, IPostBackEventHandler
    {
        public WasteManagementUserControl wmuc { get; set; }
        public TicketControl tc { get; set; }

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e) 
        {
            headerProducent.InnerText = Constants.Config[Constants.Control_Heading_Producent];
            headerAfvalparking.InnerText = Constants.Config[Constants.Control_Heading_AfvalParking_DO];
            ((AttachmentControl)attachmentCtrl).tc = tc;
        }

        private void LoadParentControl_ERT()
        {
            ((AttachmentControl)attachmentCtrl).tc = tc;
        }

        public override void LoadForm(SPControlMode controlmode, RequestType requesttype)
        {
            lblAanvrager.Text = SPContext.Current.Web.CurrentUser.Name;
            Aanvrager_ID.Value = SPContext.Current.Web.CurrentUser.ID.ToString();
            lblDatumAanvraag.Text = DateTime.Now.ToString(Constants.Format_Date);
            Utilities.LoadMasterValues(dropAfdeling, Constants.Config[Constants.List_Afdelingen], Constants.Config[Constants.CAML_Afdelingen], Constants.Config[Constants.drop_Message_Afdeling]);
            LoadParentControl_ERT();
            ((AttachmentControl)attachmentCtrl).LoadAttachments(controlmode, string.Empty, -1, Constants.Config[Constants.List_EmptyRecipientTicket]);
            BindProducts();
        }

        public override void LoadForm(SPControlMode controlmode, Ticket ticket)
        {
            try
            {
                LoadProducent(ticket);
                LoadParentControl_ERT();
                ((AttachmentControl)attachmentCtrl).LoadAttachments(controlmode, ticket.Status, ticket.ID, Constants.Config[Constants.List_EmptyRecipientTicket]);
                pnlAfvalParking.Visible = true;
                switch (controlmode)
                {
                    case SPControlMode.Display:
                        DisplayMode(ticket);
                        break;
                    case SPControlMode.Edit:
                        EditMode(ticket);
                        break;
                }
            }
            catch (Exception ex) { Utilities.LogErrorMessage(ex, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
        }

        public override void DisplayMode(Ticket ticket)
        {
            ((AttachmentControl)attachmentCtrl).DisplayMode(ticket);
            DisableControls();
        }

        public override void DisableControls()
        {
            DisableProducent();
        }
       
        private void DisableProducent()
        {
            dropAfdeling.Enabled = false;
            rfvAfdeling.Enabled = false;
            gvProducts.Enabled = false;
            txtOpmerkingen_Producent.Enabled = false;
        }

        private void LoadProducent(Ticket ticket)
        {
            EmptyRecipientTicket ert = (EmptyRecipientTicket)ticket;
            Utilities.LoadMasterValues(dropAfdeling, Constants.Config[Constants.List_Afdelingen], Constants.Config[Constants.CAML_Afdelingen], Constants.Config[Constants.drop_Message_Afdeling]);
            lblAanvrager.Text = ert.VerantwoordelijkeProducent;
            lblDatumAanvraag.Text = ert.DatumAanvraag.ToString(Constants.Format_Date);
            dropAfdeling.SelectedValue = ert.AfdelingID;
            txtOpmerkingen_Producent.Text = ert.OpmerkingProducent;
            SetProductList(ert.Products);
            BindProducts();
        }
        
        public override void EditMode(Ticket ticket)
        {
            if (ticket.Status.Equals(Constants.Status_Afgewerkt))
                btnEditItems.Visible = false;
            else
            {
                if (Utilities.IsWaste())
                {
                    btnEditItems.Visible = true;
                }
                else if (Utilities.IsDO())
                {
                    DisableProducent();
                    btnEditItems.Visible = true;
                }
                else
                {
                    if ((ticket.Status.Equals(Constants.Status_TerugNaarProducent) || ticket.Status.Equals(Constants.Status_LabelsAfhaling)) && lblAanvrager.Text.Equals(SPContext.Current.Web.CurrentUser.Name)) { }
                    else
                    {
                        DisplayMode(ticket);
                    }
                }
            }
        }

        protected void dropADR_SelectedIndexChanged(object sender, EventArgs e)
        {
            Control ctrl=null;
            string dropID = ((DropDownList)sender).ID;
            switch (dropID)
            {
                case "dropADREmpty":
                    ctrl = Utilities.FindChildControl(gvProducts, "txtUNEmpty");
                    break;
                case "dropADR":
                    ctrl = Utilities.FindChildControl(gvProducts, "txtUN");
                    break;
                case "dropADRNew":
                    ctrl = Utilities.FindChildControl(gvProducts, "txtUNNew");
                    break;
            }
            if (ctrl != null)
            {
                TextBox txtBox = ((TextBox)ctrl);
                if (((DropDownList)sender).SelectedItem.ToString().Equals("geen"))
                {
                    txtBox.Text = string.Empty;
                    txtBox.Enabled = false;
                }
                else
                {
                    txtBox.Enabled = true;
                }
            }
        }

        public void SaveProducent(SPListItem item)
        {
            if (item != null)
            {
                try
                {
                    item["AfdelingID"] = dropAfdeling.SelectedItem.Value;
                    item["Afdeling"] = dropAfdeling.SelectedItem.Text;
                    item["Opmerkingen_x0020_Producent"] = txtOpmerkingen_Producent.Text;
                    item.Update();
                    SaveProducten(item);
                    SaveAttachments(item);
                }
                catch (Exception ex) { Utilities.LogErrorMessage(ex,MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString()); }
            }
        }

        private void SaveProducten(SPListItem item)
        {
            List<Product> products = GetProductList();
            item["Producten"] = Utilities.DataToXML_Product(products);
            if (tc.GetERTType() == ERT_Type.Ongereinigd)
            {
                StringBuilder sb = new StringBuilder();
                foreach (Product p in products)
                    sb.AppendLine(string.Concat("Product: ", p.ProductName, " - ADR: ", p.ADR));
                item["Product_x0020_Info"] = sb.ToString();
            }
            item.Update();
        }

        private void SaveAttachments(SPListItem item)
        {
            List<Attachment> uploads = ((AttachmentControl)attachmentCtrl).GetAttachments();
            List<string> fileNames_ToDelete = new List<string>();
            if (uploads.Count > 0)
            {
                for (int i = 0; i < uploads.Count; i++)
                {
                    if (!string.IsNullOrEmpty(uploads[i].FileName) && uploads[i].FileStatus.Equals("Ready for upload"))
                    {
                        SPAttachmentCollection attachments = item.Attachments;
                        string fileName = Path.GetFileName(uploads[i].FileName);
                        attachments.Add(fileName, uploads[i].FileContent);
                    }
                }
                foreach (Attachment att in uploads)
                    if (att.FileStatus.Equals("Deleted"))
                        fileNames_ToDelete.Add(att.FileName);
                foreach (string fileName in fileNames_ToDelete)
                    item.Attachments.Delete(fileName);
                item.Update();
            }
        }

        public void RaisePostBackEvent(string eventArgument)
        {
            Product product;
            string[] events = eventArgument.Split(',');
            string action = events[0].Trim();
            switch (action)
            {
                case "ADDEMPTYPRODUCT":
                case "ADDPRODUCT":
                    product = CreateProduct(action);
                    if (product != null)
                        if (!CheckEmptyFields(product, null))
                            InsertRow(product);
                    break;
                case "EDITPRODUCT":
                    gvProducts.EditIndex = Convert.ToInt32(events[1]);
                    BindProducts();
                    break;
                case "UPDATEPRODUCT":
                    product = CreateProduct(action);
                    if (product != null)
                    {
                        List<Product> productsToUpdate = GetProductList();
                        if (!CheckEmptyFields(product, productsToUpdate))
                        {
                            UpdateRow(product, Convert.ToInt32(events[1]), productsToUpdate);
                            gvProducts.EditIndex = -1;
                        }
                    }
                    BindProducts();
                    break;
                case "CANCELPRODUCT":
                    gvProducts.EditIndex = -1;
                    BindProducts();
                    break;
                case "DELETEPRODUCT":
                    List<Product> products = GetProductList();
                    products.RemoveAt(Convert.ToInt32(events[1]));
                    SetProductList(products);
                    if (gvProducts.EditIndex > -1)
                        gvProducts.EditIndex = -1;
                    BindProducts();
                    break;
            }
        }

        private Product CreateProduct(string action)
        {
            Product product=null;
            int aantal = 0;
            string str_aantal = string.Empty, productname = string.Empty, adr = string.Empty, un = string.Empty, verpakkingswijze = string.Empty;
            switch (action)
            {
                case "ADDEMPTYPRODUCT":
                case "ADDPRODUCT":
                    str_aantal = ((TextBox)Utilities.FindChildControl(gvProducts, (action == "ADDEMPTYPRODUCT") ? "txtAantalEmpty" : "txtaantal")).Text;
                    if (string.IsNullOrEmpty(str_aantal))
                        aantal = -1;
                    else
                    {
                        try
                        {
                            aantal = Convert.ToInt32(str_aantal);
                        }
                        catch (FormatException fex) { }
                    }
                    productname = ((TextBox)Utilities.FindChildControl(gvProducts, (action == "ADDEMPTYPRODUCT") ? "txtProductEmpty" : "txtProductNew")).Text;
                    if (tc.GetERTType() == ERT_Type.Gereinigd)
                        productname = "Item " + GetProductList().Count + 1;
                    un = ((TextBox)Utilities.FindChildControl(gvProducts, (action == "ADDEMPTYPRODUCT") ? "txtUNEmpty" : "txtUNNew")).Text;
                    adr = ((DropDownList)Utilities.FindChildControl(gvProducts, (action == "ADDEMPTYPRODUCT") ? "dropADREmpty" : "dropADRNew")).SelectedItem.Text;
                    verpakkingswijze = ((DropDownList)Utilities.FindChildControl(gvProducts, (action == "ADDEMPTYPRODUCT") ? "dropVerpakkingEmpty" : "dropVerpakkingNew")).SelectedItem.Text;
                    product = new Product(aantal, productname, adr, un, verpakkingswijze);
                    break;
                case "UPDATEPRODUCT":
                    str_aantal = ((TextBox)Utilities.FindChildControl(gvProducts, "txtAantal")).Text;
                    if (string.IsNullOrEmpty(str_aantal))
                        aantal = -1;
                    else
                    {
                        try
                        {
                            aantal = Convert.ToInt32(str_aantal);
                        }
                        catch (FormatException fex) { }
                    }
                    productname = ((TextBox)Utilities.FindChildControl(gvProducts, "txtProduct")).Text;
                    un = ((TextBox)Utilities.FindChildControl(gvProducts, "txtUN")).Text;
                    adr = ((DropDownList)Utilities.FindChildControl(gvProducts, "dropADR")).SelectedItem.Text;
                    verpakkingswijze = ((DropDownList)Utilities.FindChildControl(gvProducts, "dropVerpakking")).SelectedItem.Text;
                    product = new Product(aantal, productname, adr, un, verpakkingswijze);
                    break;
            }
            return product;
        }

        //private void HandleLocationActions(string action,int rowIndex)
        //{
        //    switch (action)
        //    {
        //        case "EDITLOCATIE":
        //            gvLocaties.EditIndex = rowIndex;
        //            BindLocaties();
        //            break;
        //        case "UPDATELOCATIE":
        //            GridViewRow row = gvLocaties.Rows[rowIndex];
        //            List<Product> products = GetProductList();
        //            Product product = products[rowIndex];
        //            string afvalparking = ((Label)Utilities.FindChildControl(gvLocaties, "lblAfvalparking")).Text;
        //            string baan = ((DropDownList)Utilities.FindChildControl(gvLocaties, "dropBaan")).SelectedItem.Text;
        //            product.Afvalparking = afvalparking;
        //            product.Baan = baan;
        //            if (!CheckEmptyFields(product, products))
        //            {
        //                UpdateRow(product, rowIndex, products);
        //                gvLocaties.EditIndex = -1;
        //            }
        //            BindLocaties();
        //            break;
        //        case "CANCELLOCATIE":
        //            gvLocaties.EditIndex = -1;
        //            BindLocaties();
        //            break;
        //    }
        //}

        /***** PRODUCT GRID *****/

        protected void BindProducts()
        {
            List<Product> products = GetProductList();
            if (products == null)
            {
                SetProductList(new List<Product>());
                products = GetProductList();
            }
            if (tc.GetERTType() == ERT_Type.Gereinigd)
            {
                int counter = 1;
                foreach (Product p in products)
                {
                    p.ProductName = "Item " + counter;
                    counter++;
                }
            }
            gvProducts.DataSource = products;
            gvProducts.DataBind();
            BindLocaties();
        }

        protected void gvProducts_OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            HtmlButton btn;
            if (tc.GetERTType() == ERT_Type.Gereinigd)
            {
                gvProducts.Columns[1].Visible = false;
                gvProducts.Columns[2].Visible = false;
                gvProducts.Columns[3].Visible = false;
            }
            if (Request.QueryString["FORM"] == "display" || tc.GetStatus() == Constants.Status_Afgewerkt || (Request.QueryString["FORM"] == "edit" && Utilities.IsDO()) || (Request.QueryString["FORM"] == "edit" && !Utilities.IsDO() && !Utilities.IsWaste()))
            {
                gvProducts.Columns[5].Visible = false;
            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if ((e.Row.RowState & DataControlRowState.Edit) > 0)
                {
                    BuildEditRow(e.Row);
                }
                if (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate)
                {
                    string adr = ((Label)e.Row.FindControl("lblADR")).Text;
                    if (!string.IsNullOrEmpty(adr))
                    {
                        Image imgADR = (Image)e.Row.FindControl("imgADR");
                        imgADR.ImageUrl = Utilities.GetADRIconByTitle(adr);
                        if (adr == "geen")
                            ((Label)Utilities.FindChildControl(gvProducts, "lblUN")).Text = "geen";
                    }
                    btn = (HtmlButton)e.Row.FindControl("btnEditProduct");
                    btn.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('EDITPRODUCT," + ((Product)e.Row.DataItem).ID + "');");
                    btn = (HtmlButton)e.Row.FindControl("btnDeleteProduct");
                    btn.Attributes.Add("onclick", "javascript:dopostbackwithconfirm('DELETEPRODUCT," + ((Product)e.Row.DataItem).ID + "');");
                }
            }
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                BuildFooterRow(e.Row);
            }
            if (e.Row.RowType == DataControlRowType.EmptyDataRow)
            {
                BuildEmptyDataRow(e.Row);
            }
        }

        private void BuildEditRow(GridViewRow row)
        {
            DropDownList dropADR = (DropDownList)row.FindControl("dropADR");
            Utilities.LoadMasterValues(dropADR, Constants.Config[Constants.List_ADR], Constants.Config[Constants.CAML_ADR_ERT], "geen");
            string adr = ((Product)row.DataItem).ADR;
            if (!string.IsNullOrEmpty(adr))
            {
                dropADR.Items.FindByText(adr).Selected = true;
                if (adr == "geen")
                    ((TextBox)Utilities.FindChildControl(gvProducts, "txtUN")).Enabled = false;
                else
                    ((TextBox)Utilities.FindChildControl(gvProducts, "txtUN")).Enabled = true;
            }
            DropDownList dropVerpakking = (DropDownList)row.FindControl("dropVerpakking");
            Utilities.LoadMasterValues(dropVerpakking, Constants.Config[Constants.List_Volumes], Constants.Config[Constants.CAML_Volumes], string.Empty);
            string verpakking = ((Product)row.DataItem).Verpakkingswijze;
            dropVerpakking.Items.FindByText(verpakking).Selected = true;
            HtmlButton btnUpdate = (HtmlButton)row.FindControl("btnUpdateProduct");
            btnUpdate.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('UPDATEPRODUCT," + ((Product)row.DataItem).ID + "');");
            HtmlButton btnCancel = (HtmlButton)row.FindControl("btnCancelProduct");
            btnCancel.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('CANCELPRODUCT," + ((Product)row.DataItem).ID + "');");
        }

        private void BuildFooterRow(GridViewRow row)
        {
            if (Request.QueryString["FORM"] == "display" || tc.GetStatus() == Constants.Status_Afgewerkt || (Request.QueryString["FORM"] == "edit" && Utilities.IsDO()) || (Request.QueryString["FORM"] == "edit" && !Utilities.IsDO() && !Utilities.IsWaste()))
                row.Visible = false;
            else
            {
                DropDownList dropADR = (row.FindControl("dropADRNew") as DropDownList);
                Utilities.LoadMasterValues(dropADR, Constants.Config[Constants.List_ADR], Constants.Config[Constants.CAML_ADR_ERT], "geen");
                DropDownList dropVerpakking = (row.FindControl("dropVerpakkingNew") as DropDownList);
                Utilities.LoadMasterValues(dropVerpakking, Constants.Config[Constants.List_Volumes], Constants.Config[Constants.CAML_Volumes], Constants.Config[Constants.drop_Message_Verpakking]);
                HtmlButton btn = (HtmlButton)row.FindControl("btnAddProduct");
                btn.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('ADDPRODUCT,-1');");
            }
        }

        private void BuildEmptyDataRow(GridViewRow row)
        {
            if (tc.GetStatus() == Constants.Status_Afgewerkt)
                row.Visible = false;
            else
            {
                DropDownList dropADR = (row.FindControl("dropADREmpty") as DropDownList);
                Utilities.LoadMasterValues(dropADR, Constants.Config[Constants.List_ADR], Constants.Config[Constants.CAML_ADR_ERT], "geen");
                DropDownList dropVerpakking = (row.FindControl("dropVerpakkingEmpty") as DropDownList);
                Utilities.LoadMasterValues(dropVerpakking, Constants.Config[Constants.List_Volumes], Constants.Config[Constants.CAML_Volumes], Constants.Config[Constants.drop_Message_Verpakking]);
                HtmlButton btn = (HtmlButton)row.FindControl("btnAddProductEmpty");
                btn.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('ADDEMPTYPRODUCT,-1');");
                if (tc.GetERTType() == ERT_Type.Gereinigd)
                {
                    ((TableHeaderCell)row.FindControl("emptyhead_product")).Visible = false;
                    ((TableHeaderCell)row.FindControl("emptyhead_un")).Visible = false;
                    ((TableHeaderCell)row.FindControl("emptyhead_adr")).Visible = false;
                    ((TableCell)row.FindControl("emptycol_product")).Visible = false;
                    ((TableCell)row.FindControl("emptycol_un")).Visible = false;
                    ((TableCell)row.FindControl("emptycol_adr")).Visible = false;
                }
            }
        }

        protected void gvProducts_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvProducts.EditIndex = e.NewEditIndex;
            BindProducts();
        }

        protected void gvProducts_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvProducts.EditIndex = -1;
            BindProducts();
        }

        protected void gvProducts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvProducts.PageIndex = e.NewPageIndex;
            BindProducts();
        }

        protected void gvProducts_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvProducts.Rows[e.RowIndex];
            int aantal = Convert.ToInt32(((TextBox)Utilities.FindChildControl(gvProducts, "txtAantal")).Text);
            string productname = ((DropDownList)Utilities.FindChildControl(gvProducts, "dropProduct")).SelectedItem.Text;
            string adr = ((TextBox)Utilities.FindChildControl(gvProducts, "txtADR")).Text;
            string un = ((TextBox)Utilities.FindChildControl(gvProducts, "txtUN")).Text;
            string verpakkingswijze = ((DropDownList)Utilities.FindChildControl(gvProducts, "dropVerpakking")).SelectedItem.Text;
            List<Product> products = GetProductList();
            Product product = new Product(aantal, productname, adr, un, verpakkingswijze);
            if (!CheckEmptyFields(product, products))
            {
                UpdateRow(product, e.RowIndex, products);
                gvProducts.EditIndex = -1;
            }
            BindProducts();
        }

        protected void gvProducts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            List<Product> products = GetProductList();
            products.RemoveAt(e.RowIndex);
            SetProductList(products);
            if (gvProducts.EditIndex > -1)
                gvProducts.EditIndex = -1;
            BindProducts();
        }

        private void InsertRow(Product product)
        {
            List<Product> products = GetProductList();
            if (!CheckEmptyFields(product, products))
            {
                product.ID = products.Count;
                products.Add(product);
                SetProductList(products);
            }
            if (gvProducts.EditIndex > -1)
                gvProducts.EditIndex = -1;
            BindProducts();
        }

        private void UpdateRow(Product product, int index, List<Product> products)
        {
            products[index] = product;
            SetProductList(products);
        }

        public void SetProductList(List<Product> products)
        {
            ViewState["ProductList"] = products;
        }

        public List<Product> GetProductList()
        {
            return (List<Product>)ViewState["ProductList"];
        }

        private bool CheckEmptyFields(Product product, List<Product> products)
        {
            lblErrorMessage.Text = string.Empty;
            if (tc.GetERTType() == ERT_Type.Gereinigd)
            {
                //string.IsNullOrEmpty(product.ProductName)
                if (product.Aantal <= 0 || (string.IsNullOrEmpty(product.Verpakkingswijze) || product.Verpakkingswijze.Equals(Constants.Config[Constants.drop_Message_Verpakking])))
                {
                    lblErrorMessage.Text = "Vul een geldig product in!<br/>-Aantal: cijfer groter dan 0<br/>-Verpakkingswijze: selectie uit lijst";
                    return true;
                }
            }
            else
            {
                if (product.ADR == "geen")
                {
                    if (product.Aantal <= 0 || string.IsNullOrEmpty(product.ProductName) ||
                    (string.IsNullOrEmpty(product.Verpakkingswijze) || product.Verpakkingswijze.Equals(Constants.Config[Constants.drop_Message_Verpakking])))
                    {
                        lblErrorMessage.Text = "Vul een geldig product in!<br/>-Aantal: cijfer groter dan 0<br/>-Product: mag niet leeg zijn<br/>-UN: enkel van toepassing als ADR gekozen is<br/>-Verpakkingswijze: selectie uit lijst";
                        return true;
                    }
                }
                else
                {
                    if (product.Aantal <= 0 || string.IsNullOrEmpty(product.ProductName) ||
                        string.IsNullOrEmpty(product.UN) || string.IsNullOrEmpty(product.ADR) ||
                        (string.IsNullOrEmpty(product.Verpakkingswijze) || product.Verpakkingswijze.Equals(Constants.Config[Constants.drop_Message_Verpakking])))
                    {
                        lblErrorMessage.Text = "Vul een geldig product in!<br/>-Aantal: cijfer groter dan 0<br/>-Product: mag niet leeg zijn<br/>-UN: enkel van toepassing als ADR gekozen is<br/>-Verpakkingswijze: selectie uit lijst";
                        return true;
                    }
                }
            }
            /*if (products.Where(p => p.ProductName.Equals(product.ProductName)).Count() > 0)
            {
                //lblErrorMessage.Text = "Stopover already added, enter a different stopover!";
                return true;
            }*/
            return false;
        }

        /***** END PRODUCT GRID *****/

        /**** CONTROL PROPERTIES ****/
        public string GetAanvragerName()
        {
            return lblAanvrager.Text;
        }

        public string GetAanvragerID()
        {
            return Aanvrager_ID.Value;
            //return Convert.ToInt32(Aanvrager_ID.Value);
        }

        /***** LOCATIONS GRID *****/

        protected void BindLocaties()
        {
            List<Product> products = GetProductList();
            if (products == null)
            {
                SetProductList(new List<Product>());
                products = GetProductList();
            }
            gvLocaties.DataSource = products;
            gvLocaties.DataBind();
            //btnEditItems.Visible = true;
            //btnSaveItems.Visible = false;
            //btnCancelItems.Visible = false;
        }

        protected void gvLocaties_OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            //HtmlButton btn;

            gvLocaties.Columns[3].Visible = false;
                
            /*if (Request.QueryString["FORM"] == "display" || 
                (Request.QueryString["FORM"] == "edit" && Utilities.IsDO() && !tc.GetStatus().Equals(Constants.Status_InBehandeling)) || 
                (!Utilities.IsDO() && !Utilities.IsWaste()))
            {
                gvLocaties.Columns[3].Visible = false;
                //gvLocaties.Columns[4].Visible = false;
            }*/
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //if ((e.Row.RowState & DataControlRowState.Edit) > 0)
                //{
                    DropDownList dropBaan = (DropDownList)e.Row.FindControl("dropBaan");
                    string adr = ((Product)e.Row.DataItem).ADR;
                    string baan = ((Product)e.Row.DataItem).Baan;
                    if (tc.GetERTType() == ERT_Type.Gereinigd || adr.Equals("geen"))
                        Utilities.LoadBanen(dropBaan, "Gereinigd", string.Empty);
                    else
                        Utilities.LoadBanen(dropBaan, "Ongereinigd", adr);
                    if (!string.IsNullOrEmpty(baan))
                        dropBaan.Items.FindByText(baan).Selected = true;
                //    btn = (HtmlButton)e.Row.FindControl("btnUpdateLocatie");
                //    btn.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('UPDATELOCATIE," + ((Product)e.Row.DataItem).ID + "');");
                //    btn = (HtmlButton)e.Row.FindControl("btnCancelLocatie");
                //    btn.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('CANCELLOCATIE," + ((Product)e.Row.DataItem).ID + "');");
                //}
                //if (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate)
                //{
                //    btn = (HtmlButton)e.Row.FindControl("btnEditLocatie");
                //    btn.Attributes.Add("onclick", "javascript:dopostbackwithoutconfirm('EDITLOCATIE," + ((Product)e.Row.DataItem).ID + "');");
                //}
            }
        }

        protected void btnEditItems_Click(object sender, EventArgs e)
        {
            EditLocationsGrid(true);
        }

        protected void btnSaveItems_Click(object sender, EventArgs e)
        {
            //SAVE CHANGES + UPDATE GRID
            List<Product> products = GetProductList();
            int rowIndex = 0;
            foreach (GridViewRow row in gvLocaties.Rows)
            {
                //GridViewRow row = gvLocaties.Rows[rowIndex];
                Product product = products[rowIndex];
                string afvalparking = row.Cells[1].Controls.OfType<Label>().FirstOrDefault().Text;
                //string afvalparking = ((Label)Utilities.FindChildControl(gvLocaties, "lblAfvalparking")).Text;
                string baan = row.Cells[2].Controls.OfType<DropDownList>().FirstOrDefault().SelectedItem.Text;
                //string baan = ((DropDownList)Utilities.FindChildControl(gvLocaties, "dropBaan")).SelectedItem.Text;
                product.Afvalparking = afvalparking;
                product.Baan = baan;
                if (!CheckEmptyFields(product, products))
                    UpdateRow(product, rowIndex, products);
                rowIndex++;
            }
            EditLocationsGrid(false);
            BindLocaties();
        }

        protected void btnCancelItems_Click(object sender, EventArgs e)
        {
            EditLocationsGrid(false);
            BindLocaties();
        }

        private void EditLocationsGrid(bool edit)
        {
            int counter = 0;
            foreach (GridViewRow row in gvLocaties.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    if (edit)
                        row.RowState = DataControlRowState.Edit;
                    else
                    {
                        if (counter % 2 == 0)
                            row.RowState = DataControlRowState.Normal;
                        else
                            row.RowState = DataControlRowState.Alternate;
                    }
                    row.Cells[2].Controls.OfType<Label>().FirstOrDefault().Visible = !edit;
                    if (row.Cells[2].Controls.OfType<DropDownList>().ToList().Count > 0)
                    {
                        row.Cells[2].Controls.OfType<DropDownList>().FirstOrDefault().Visible = edit;
                    }
                    counter++;
                }
            }
            btnEditItems.Visible = !edit;
            btnSaveItems.Visible = edit;
            btnCancelItems.Visible = edit;
        }

        /***** END LOCATIONS GRID *****/

        protected void OnCheckedChanged(object sender, EventArgs e)
        {
            bool isUpdateVisible = false;
            //Label1.Text = string.Empty;

            //Loop through all rows in GridView
            foreach (GridViewRow row in gvLocaties.Rows)
            {
                if (row.RowType == DataControlRowType.DataRow)
                {
                    bool isChecked = row.Cells[0].Controls.OfType<CheckBox>().FirstOrDefault().Checked;
                    if (isChecked)
                        row.RowState = DataControlRowState.Edit;
                    row.Cells[3].Controls.OfType<Label>().FirstOrDefault().Visible = !isChecked;
                    if (row.Cells[3].Controls.OfType<DropDownList>().ToList().Count > 0)
                    {
                        row.Cells[3].Controls.OfType<DropDownList>().FirstOrDefault().Visible = isChecked;
                    }
                    if (isChecked && !isUpdateVisible)
                    {
                        isUpdateVisible = true;
                    }
                    /*for (int i = 3; i < row.Cells.Count; i++)
                    {
                        //row.Cells[i].Controls.OfType<Label>().FirstOrDefault().Visible = !isChecked;
                        //if (row.Cells[i].Controls.OfType<TextBox>().ToList().Count > 0)
                        //{
                        //    row.Cells[i].Controls.OfType<TextBox>().FirstOrDefault().Visible = isChecked;
                        //}
                        if (isChecked && !isUpdateVisible)
                        {
                            isUpdateVisible = true;
                        }
                    }*/
                }
            }
            //btnUpdate.Visible = isUpdateVisible;
        }
    }
}