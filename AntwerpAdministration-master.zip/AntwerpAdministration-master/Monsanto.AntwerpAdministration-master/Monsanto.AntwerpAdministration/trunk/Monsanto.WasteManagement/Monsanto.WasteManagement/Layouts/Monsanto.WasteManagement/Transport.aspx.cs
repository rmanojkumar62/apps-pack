﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Monsanto.WasteManagement.WM.Enums;
using Microsoft.SharePoint.Utilities;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Collections;
using Monsanto.WasteManagement.WM.Domain;
using System.Web.UI.HtmlControls;

namespace Monsanto.WasteManagement.Layouts.Monsanto.WasteManagement
{
    public partial class Transport : LayoutsPageBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            wastedisposalheaderimg.Src = Constants.Config[Constants.Header_Image];
            wastedisposalheaderimg.Alt = "WM";
            wastedisposalheader.InnerText = Constants.Config[Constants.Header_Text];
            if (!IsPostBack)
            {
                txtDatumUIT.Text = DateTime.Now.ToString(Constants.Format_Date);
                Utilities.LoadAfvalstromen(dropAfvalstroom, Constants.Config[Constants.drop_Message_Afvalstroom]);
                Utilities.LoadFirmas_ByType(dropVerwerver, FirmaType.Verwerver, Constants.Config[Constants.drop_Message_Verwerver]);
                Utilities.LoadFirmas_ByType(dropVervoerder, FirmaType.Vervoerder, Constants.Config[Constants.drop_Message_Vervoerder]);
                Utilities.LoadFirmas_ByType(dropVerwerker, FirmaType.Verwerker, Constants.Config[Constants.drop_Message_Verwerker]);
            }
        }
       
        protected void dropFirma_SelectedIndexChanged(object sender, EventArgs e)
        {
            int firmaID = Convert.ToInt32(((DropDownList)sender).SelectedValue);
            Firma firma = Utilities.LoadFirma(firmaID);
            Panel pnl=null;
            switch (((DropDownList)sender).ID)
            {
                case "dropVerwerver":
                    pnl = pnlVerwerver;
                    break;
                case "dropVervoerder":
                    pnl = pnlVervoerder;
                    break;
                case "dropVerwerker":
                    pnl = pnlVerwerker;
                    break;
            }
            if (pnl != null)
            {
                pnl.Controls.Clear();
                if (firmaID > 0 && firma != null)
                {
                    HtmlGenericControl ctrl = new HtmlGenericControl();
                    if (!string.IsNullOrEmpty(firma.Straat))
                        ctrl.InnerHtml += "<p>" + firma.Straat + "</p>";
                    if (!string.IsNullOrEmpty(firma.Postcode) && !string.IsNullOrEmpty(firma.Gemeente))
                        ctrl.InnerHtml += "<p>" + firma.Postcode + " - " + firma.Gemeente + "</p>";
                    if (!string.IsNullOrEmpty(firma.Land))
                        ctrl.InnerHtml += "<p>" + firma.Land + "</p>";
                    pnl.Controls.Add(ctrl);
                    pnl.Visible = true;
                }
                else
                    pnl.Visible = false;
            }
        }

        protected void btnOpslaan_Click(object sender, EventArgs e) 
        {
            SPListItem item = SPContext.Current.Web.Lists.TryGetList(Constants.Config[Constants.List_Transport]).Items.Add();
            if (item != null)
            {
                string[] str_dateUIT = txtDatumUIT.Text.Split('/');
                DateTime dateUIT = new DateTime(Convert.ToInt32(str_dateUIT[2]), Convert.ToInt32(str_dateUIT[1]), Convert.ToInt32(str_dateUIT[0]));
                string afvalstroom = dropAfvalstroom.SelectedItem.Text;
                item[Constants.Col_Title] = afvalstroom.Split(new string[]{" --- "},StringSplitOptions.RemoveEmptyEntries)[1];
                item["Afdeling"] = afvalstroom.Split(new string[]{" --- "},StringSplitOptions.RemoveEmptyEntries)[0];
                item["Specificatie"] = txtSpecificatie.Text;
                item["Datum"] = dateUIT;
                item["Gewicht"] = txtGewicht.Text;
                item["CMR"] = txtCMR.Text;
                item["Verwerver"] = dropVerwerver.SelectedItem.Text;
                item["Vervoerder"] = dropVervoerder.SelectedItem.Text;
                item["Verwerker"] = dropVerwerker.SelectedItem.Text;
                item.Update();
            }
            Response.Redirect(string.Concat(SPContext.Current.Web.Url,"/_layouts/Monsanto.WasteManagement/Historiek.aspx?TICKETTYPE=TR&OVERVIEWTYPE="), false);
            Context.ApplicationInstance.CompleteRequest();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(string.Concat(SPContext.Current.Web.Url,"/_layouts/Monsanto.WasteManagement/Historiek.aspx?TICKETTYPE=TR&OVERVIEWTYPE="), false);
            Context.ApplicationInstance.CompleteRequest();
        }
    }
}
