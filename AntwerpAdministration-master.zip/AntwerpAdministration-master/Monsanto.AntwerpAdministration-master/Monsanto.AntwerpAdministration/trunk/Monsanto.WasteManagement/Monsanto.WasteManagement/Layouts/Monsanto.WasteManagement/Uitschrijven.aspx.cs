﻿using System;
using System.Linq;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Monsanto.WasteManagement.WM.Enums;
using System.Collections.Generic;
using Monsanto.WasteManagement.WM.Domain;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace Monsanto.WasteManagement.Layouts.Monsanto.WasteManagement
{
    public partial class Uitschrijven : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(Request.QueryString["REQUESTTYPE"])&&!string.IsNullOrEmpty(Request.QueryString["TICKETID"]))
                {
                    RequestType rt = Utilities.GetRequestType(Request.QueryString["REQUESTTYPE"]);
                    SetPanelHeaders();
                    SetControls(rt);
                }
            }
        }

        private void SetPanelHeaders()
        {
            if (!string.IsNullOrEmpty(Request.QueryString["DIRECTEBELADING"]))
            {
                headerLeftCol.InnerText = "Product info";
                headerRightCol.InnerText = "Directe belading";
            }
            else
            {
                headerLeftCol.InnerText = "Parking IN";
                headerRightCol.InnerText = "Parking UIT";
            }
        }

        private void SetControls(RequestType rt)
        {
            switch (rt)
            {
                case RequestType.WDT:
                    row_product.Visible = true;
                    row_volume.Visible = true;
                    row_eccode.Visible = true;
                    row_adr.Visible = true;
                    row_indaver.Visible = true;
                    row_palettenIN.Visible = true;
                    LoadControls(rt,GetWasteDisposalTicket());
                    break;
                case RequestType.ERT:
                    row_product.Visible = false;
                    row_volume.Visible = false;
                    row_eccode.Visible = false;
                    row_adr.Visible = false;
                    row_indaver.Visible = false;
                    row_palettenIN.Visible = false;
                    LoadControls(rt,GetEmptyRecipientTicket());
                    break;
            }
            if (!string.IsNullOrEmpty(Request.QueryString["DIRECTEBELADING"]))
            {
                row_datumIN.Visible = false;
                row_locatieParking.Visible = false;
                txtAantalVatenOUT.Enabled = false;
                rfvAantalVatenOUT.Enabled = false;
                regexVaten.Enabled = false;
                rangeAantalVatenOUT.Enabled = false;
            }
            else
            {
                row_datumIN.Visible = true;
                row_locatieParking.Visible = true;
            }
        }

        private void LoadControls(RequestType rt, WasteDisposalTicket ticket)
        {
            LoadControls(rt, ticket.ID.ToString(), ticket.TicketNumber, ticket.Afdeling, ticket.Product, ticket.Volume, ticket.AantalVaten,ticket.AantalPaletten, ticket.IndaverReferentie, ticket.EC, ticket.ADR, ticket.GetSmallADR_Pics(ticket.ADR_Pics));
        }

        private void LoadControls(RequestType rt, EmptyRecipientTicket ticket)
        {
            string aantalvaten = ticket.Products.Sum(p => p.Aantal).ToString();
            LoadControls(rt, ticket.ID.ToString(), ticket.TicketNumber, ticket.Afdeling, string.Empty, string.Empty, aantalvaten,string.Empty, string.Empty, string.Empty, string.Empty, string.Empty);
        }

        private void LoadControls(RequestType requestType,string ticketID,string ticketNumber, string afdeling, string product, string volume, string aantalVaten,string aantalPaletten, string indaverReferentie, string ec, string adr, string adr_pics)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["DIRECTEBELADING"]))
            {
                txtAantalVatenOUT.Text = aantalVaten;
                rangeAantalVatenOUT.MaximumValue = aantalVaten;
                if (requestType.Equals(RequestType.WDT))
                {
                    FillPanel_ParkingIN(ticketNumber, afdeling, product, volume, aantalVaten, aantalPaletten, ec, adr, adr_pics);
                    FillPanel_ParkingOUT(ticketID, indaverReferentie);
                }
                else if (requestType.Equals(RequestType.ERT))
                {
                    FillPanel_ParkingIN(ticketNumber, afdeling, aantalVaten, string.Empty);
                    FillPanel_ParkingOUT(ticketID);
                }
            }
            else
            {
                List<ParkingTransactie> transacties = null;
                if (requestType.Equals(RequestType.WDT))
                    transacties = GetTransactions(ticketNumber, RequestType.WDT);
                else if (requestType.Equals(RequestType.ERT))
                    transacties = GetTransactions(ticketNumber, RequestType.ERT);
                
                if (transacties.Count > 0)
                {
                    ParkingTransactie parking_IN = GetParking_IN(transacties);
                    List<ParkingTransactie> parking_OUTS = GetParking_OUT(transacties);
                    int volume_IN = GetVolume_IN(parking_IN);
                    int volume_OUT = GetVolume_OUT(parking_OUTS);
                    int volumedifference = volume_IN - volume_OUT;
                    rangeAantalVatenOUT.MaximumValue = volumedifference.ToString();
                    currentParkingOutVolume.Value = volume_OUT.ToString();
                    if (requestType.Equals(RequestType.WDT))
                        FillPanel_ParkingIN(parking_IN.TicketNumber, parking_IN.Datum, parking_IN.Afdeling, parking_IN.Product, parking_IN.Volume, parking_IN.AantalVaten.ToString(), parking_IN.AantalPaletten.ToString(), parking_IN.LocatieAfvalvaten, ec, adr, adr_pics);
                    else if (requestType.Equals(RequestType.ERT))
                        FillPanel_ParkingIN(parking_IN.TicketNumber, parking_IN.Datum, parking_IN.Afdeling, parking_IN.Product, parking_IN.Volume, parking_IN.AantalVaten.ToString(), string.Empty, parking_IN.LocatieAfvalvaten, string.Empty,string.Empty,string.Empty);
                    foreach (ParkingTransactie parking_OUT in parking_OUTS)
                        CreatePanel_ParkingOUT(parking_OUT);
                    if (volume_IN > volume_OUT)
                    {
                        if (requestType.Equals(RequestType.WDT))
                            FillPanel_ParkingOUT(ticketID, indaverReferentie);
                        else if (requestType.Equals(RequestType.ERT))
                            FillPanel_ParkingOUT(ticketID);
                    }
                }
            }
        }

        private WasteDisposalTicket GetWasteDisposalTicket()
        {
            Ticket ticket = Utilities.LoadTicket(RequestType.WDT, Request.QueryString["TICKETID"], Constants.Config[Constants.List_WasteDisposalTicket]);
            return (WasteDisposalTicket)ticket;
        }

        private EmptyRecipientTicket GetEmptyRecipientTicket()
        {
            Ticket ticket = Utilities.LoadTicket(RequestType.ERT, Request.QueryString["TICKETID"], Constants.Config[Constants.List_EmptyRecipientTicket]);
            return (EmptyRecipientTicket)ticket;
        }

        private List<ParkingTransactie> GetTransactions(string ticketnumber,RequestType requestType)
        {
            return Utilities.LoadParkingTransacties(ticketnumber, requestType);
        }

        private ParkingTransactie GetParking_IN(List<ParkingTransactie> transactions)
        {
            return transactions.Where(t => t.TransactionCode.Equals("IN")).First();
        }

        private List<ParkingTransactie> GetParking_OUT(List<ParkingTransactie> transactions)
        {
            return transactions.Where(t => t.TransactionCode.Equals("UIT")).ToList();
        }

        private int GetVolume_IN(ParkingTransactie transaction)
        {
            return transaction.AantalVaten;
        }

        private int GetVolume_OUT(List<ParkingTransactie> transactions)
        {
            return transactions.Sum(t => t.AantalVaten);
        }

        private void FillPanel_ParkingIN(string ticketnr, string afdeling, string aantalvaten, string aantalpaletten)
        {
            FillPanel_ParkingIN(ticketnr, afdeling, string.Empty, string.Empty, aantalvaten, aantalpaletten, string.Empty, string.Empty, string.Empty);
        }

        private void FillPanel_ParkingIN(string ticketnr, string afdeling, string product, string volume, string aantalvaten, string aantalpaletten, string eccode, string adr, string adr_pics)
        {
            FillPanel_ParkingIN(ticketnr, DateTime.MinValue, afdeling, product, volume, aantalvaten, aantalpaletten, string.Empty, eccode, adr, adr_pics);
        }

        private void FillPanel_ParkingIN(string ticketnr, DateTime datumIN, string afdeling, string product, string volume, string aantalvaten, string aantalpaletten, string locatie, string eccode, string adr, string adr_pics)
        {
            if(!string.IsNullOrEmpty(ticketnr))
                lblTicketNr.Text = ticketnr;
            if(datumIN!=DateTime.MinValue)
                lblDatumIN.Text = datumIN.ToString(Constants.Format_Date);
            if (!string.IsNullOrEmpty(afdeling))
                lblAfdeling.Text = afdeling;
            if (!string.IsNullOrEmpty(product))
                lblProduct.Text = product;
            if (!string.IsNullOrEmpty(volume))
                lblVolume.Text = volume;
            if (!string.IsNullOrEmpty(aantalvaten))
                lblAantalVaten.Text = aantalvaten;
            if (!string.IsNullOrEmpty(aantalpaletten))
                lblAantalPaletten.Text = aantalpaletten;
            if (!string.IsNullOrEmpty(locatie))
                lblParking.Text = locatie;
            if (!string.IsNullOrEmpty(eccode))
                lblECCode.Text = eccode;
            if (!string.IsNullOrEmpty(adr))
            {
                if (adr.Equals("Niet van toepassing"))
                    lblADR.Text = adr;
                else
                    lblADR.Text = adr_pics;
            }
        }

        private void CreatePanel_ParkingOUT(ParkingTransactie parking_OUT)
        {
            LiteralControl lc = new LiteralControl();
            lc.Text = "<div class=\"panel panel-success\">" +
                        "<div class=\"panel-heading panel-heading-block\"><h2 class=\"formheader headerProducent\">Parking UIT</h2></div>" +
                        "<div class=\"panel-body\">" +
                            "<div class=\"container-fluid\">" +
                                "<div class=\"row no-margin\">" +
                                    "<div class=\"col-xs-12 col-sm-3 col-md-3 col-lg-4 leftcol\"><label>Datum UIT</label></div>" +
                                    "<div class=\"col-xs-12 col-sm-9 col-md-9 col-lg-7 rightcol\">" + parking_OUT.Datum.ToString("dd/MM/yyyy") + "</div>" +
                                "</div>" +
                                "<div class=\"row no-margin\">" +
                                    "<div class=\"col-xs-12 col-sm-3 col-md-3 col-lg-4 leftcol\"><label>INDAVER referentie</label></div>" +
                                    "<div class=\"col-xs-12 col-sm-9 col-md-9 col-lg-7 rightcol\">" + parking_OUT.IndaverReferentie + "</div>" +
                                "</div>" +
                                "<div class=\"row no-margin\">" +
                                    "<div class=\"col-xs-12 col-sm-3 col-md-3 col-lg-4 leftcol\"><label>Verwerker</label></div>" +
                                    "<div class=\"col-xs-12 col-sm-9 col-md-9 col-lg-7 rightcol\">" + parking_OUT.Verwerker + "</div>" +
                                "</div>" +
                                "<div class=\"row no-margin\">" +
                                    "<div class=\"col-xs-12 col-sm-3 col-md-3 col-lg-4 leftcol\"><label>Aantal vaten UIT</label></div>" +
                                    "<div class=\"col-xs-12 col-sm-9 col-md-9 col-lg-7 rightcol\">" + parking_OUT.AantalVaten + "</div>" +
                                "</div>" +
                            "</div>" +
                        "</div>" +
                    "</div>";
            pnlParkingOUT.Controls.Add(lc);
        }

        private void FillPanel_ParkingOUT(string itemID)
        {
            FillPanel_ParkingOUT(itemID, string.Empty);
        }

        private void FillPanel_ParkingOUT(string itemID, string indaverreferentie)
        {
            ticketID.Value = itemID;
            txtDatumUIT.Text = DateTime.Now.ToString(Constants.Format_Date);
            if(!string.IsNullOrEmpty(indaverreferentie))
                txtIndaver.Text = indaverreferentie;
            Utilities.LoadFirmas_ByType(dropVerwerker, FirmaType.Verwerker, Constants.Config[Constants.drop_Message_Firma]);
            btnUitschrijven_text.InnerText = "Uitschrijven";
            pnlParkingOUTNew.Visible = true;
        }

        protected void dropFirma_SelectedIndexChanged(object sender, EventArgs e)
        {
            int firmaID = Convert.ToInt32(((DropDownList)sender).SelectedValue);
            Firma firma = Utilities.LoadFirma(firmaID);
            pnlVerwerker.Controls.Clear();
            if (firmaID > 0 && firma!=null)
            {
                HtmlGenericControl ctrl = new HtmlGenericControl();
                if(!string.IsNullOrEmpty(firma.Straat))
                    ctrl.InnerHtml += "<p>" + firma.Straat + "</p>";
                if(!string.IsNullOrEmpty(firma.Postcode)&&!string.IsNullOrEmpty(firma.Gemeente))
                    ctrl.InnerHtml += "<p>" + firma.Postcode + " - " + firma.Gemeente + "</p>";
                if(!string.IsNullOrEmpty(firma.Land))
                    ctrl.InnerHtml += "<p>" + firma.Land + "</p>";
                pnlVerwerker.Controls.Add(ctrl);
                pnlVerwerker.Visible = true;
            }
            else
                pnlVerwerker.Visible = false;
        }

        protected void btnUitschrijven_Click(object sender, EventArgs e)
        {
            string requesttype = Request.QueryString["REQUESTTYPE"];
            if (!string.IsNullOrEmpty(requesttype))
            {
                if (!string.IsNullOrEmpty(Request.QueryString["DIRECTEBELADING"]))
                    SaveDirecteBelading(Utilities.GetRequestType(requesttype));
                else
                    SaveParking(Utilities.GetRequestType(requesttype));
            }
        }

        private void SaveParking(RequestType requestType)
        {
            int volume_IN = Convert.ToInt32(lblAantalVaten.Text);
            int current_volume_OUT = Convert.ToInt32(currentParkingOutVolume.Value);
            int input_aantalvaten = Convert.ToInt32(txtAantalVatenOUT.Text);
            string[] str_dateUIT = txtDatumUIT.Text.Split('/');
            DateTime dateUIT = new DateTime(Convert.ToInt32(str_dateUIT[2]), Convert.ToInt32(str_dateUIT[1]), Convert.ToInt32(str_dateUIT[0]));
            ParkingTransactie pt=null;
            if(requestType.Equals(RequestType.WDT))
                pt = new ParkingTransactie(
                    TransactionType.UIT.ToString(),
                    lblTicketNr.Text,
                    dateUIT,
                    lblAfdeling.Text,
                    lblProduct.Text,
                    lblVolume.Text,
                    input_aantalvaten,
                    Convert.ToInt32(lblAantalPaletten.Text),
                    lblParking.Text,
                    txtIndaver.Text,
                    dropVerwerker.SelectedItem.Text,
                    lblECCode.Text,
                    requestType);
            else if(requestType.Equals(RequestType.ERT))
                pt = new ParkingTransactie(
                    TransactionType.UIT.ToString(),
                    lblTicketNr.Text,
                    dateUIT,
                    lblAfdeling.Text,
                    string.Empty,
                    string.Empty,
                    input_aantalvaten,
                    0,
                    string.Empty,
                    txtIndaver.Text,
                    dropVerwerker.SelectedItem.Text,
                    lblECCode.Text,
                    requestType);
            Utilities.SaveParkingTransaction(pt);
            if (volume_IN <= (current_volume_OUT + input_aantalvaten))
            {
                SaveTicket(requestType, false);
            }
        }

        private void SaveDirecteBelading(RequestType requestType)
        {
            string[] str_dateUIT = txtDatumUIT.Text.Split('/');
            DateTime dateUIT = new DateTime(Convert.ToInt32(str_dateUIT[2]), Convert.ToInt32(str_dateUIT[1]), Convert.ToInt32(str_dateUIT[0]));
            DirecteBeladingTransactie dbt = null;
            if (requestType.Equals(RequestType.WDT))
                dbt = new DirecteBeladingTransactie(
                    TransactionType.UIT.ToString(),
                    lblTicketNr.Text,
                    dateUIT,
                    lblAfdeling.Text,
                    lblProduct.Text,
                    lblVolume.Text,
                    Convert.ToInt32(lblAantalVaten.Text),
                    Convert.ToInt32(lblAantalPaletten.Text),
                    lblECCode.Text,
                    txtIndaver.Text,
                    dropVerwerker.SelectedItem.Text,
                    requestType);
            else if (requestType.Equals(RequestType.ERT))
                dbt = new DirecteBeladingTransactie(
                    TransactionType.UIT.ToString(),
                    lblTicketNr.Text,
                    dateUIT,
                    lblAfdeling.Text,
                    string.Empty,
                    string.Empty,
                    Convert.ToInt32(lblAantalVaten.Text),
                    0,
                    lblECCode.Text,
                    txtIndaver.Text,
                    dropVerwerker.SelectedItem.Text,
                    requestType);
            Utilities.SaveDirecteBeladingTransaction(dbt);
            SaveTicket(requestType, true);
        }

        private void SaveTicket(RequestType requestType, bool directebelading)
        {
            string oldstatus = string.Empty, newstatus = string.Empty;
            Ticket ticket = null;
            if (requestType.Equals(RequestType.WDT))
                ticket = GetWasteDisposalTicket();
            else if (requestType.Equals(RequestType.ERT))
                ticket = GetEmptyRecipientTicket();
            List<ChangeLog> logs = ticket.Logs;
            SPListItem item = Utilities.GetTicketByID(ticketID.Value, requestType);
            item[Constants.Col_Status] = Constants.Status_Uitgeschreven;
            if (directebelading)
            {
                item["Locatie_x0020_afvalparking"] = "Directe belading";
                oldstatus = Status.Directe_Belading.ToString();
                newstatus = Status.Uitgeschreven.ToString();
            }
            else
            {
                oldstatus = Status.Afgewerkt.ToString();
                newstatus = Status.Uitgeschreven.ToString();
            }
            logs.Add(new ChangeLog(SPContext.Current.Web.CurrentUser.Name, "Waste", DateTime.Now, ButtonAction.Submit, oldstatus, newstatus));
            item["Changelog"] = Utilities.DataToXML_ChangeLog(logs);
            item.Update();
        }
    }
}