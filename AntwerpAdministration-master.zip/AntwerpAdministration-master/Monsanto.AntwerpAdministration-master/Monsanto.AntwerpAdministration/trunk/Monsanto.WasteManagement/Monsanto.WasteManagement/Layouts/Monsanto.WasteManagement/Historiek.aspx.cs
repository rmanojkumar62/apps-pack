﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Monsanto.WasteManagement.WM.Domain;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint.Utilities;
using System.Web.UI;
using System.Linq;
using TransportDomain = Monsanto.WasteManagement.WM.Domain.Transport;

namespace Monsanto.WasteManagement.Layouts.Monsanto.WasteManagement
{
    public partial class Historiek : LayoutsPageBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            wastedisposalheaderimg.Src = Constants.Config[Constants.Header_Image];
            wastedisposalheaderimg.Alt = "WM";
            wastedisposalheader.InnerText = Constants.Config[Constants.Header_Text];
            btnFilter_text.InnerText = "Filter";
            if (!IsPostBack)
            {
                string tickettype = Request.QueryString["TICKETTYPE"];
                if (!string.IsNullOrEmpty(tickettype))
                {
                    DateTime currentDate = DateTime.Now;
                    switch (tickettype)
                    {
                        case "WDT":
                            txtVan.Text = new DateTime(currentDate.Year, 1, 1).ToString(Constants.Format_Date);
                            txtTot.Text = new DateTime(currentDate.Year, 12, 31).ToString(Constants.Format_Date);
                            Utilities.LoadLocaties(dropParking, dropBaan, Constants.Config[Constants.drop_Message_Locatie]);
                            colParking.Visible = true;
                            colBaan.Visible = true;
                            colECcode.Visible = true;
                            colAfvalstroom.Visible = false;
                            break;
                        case "ERT":
                            txtVan.Text = new DateTime(currentDate.Year, 1, 1).ToString(Constants.Format_Date);
                            txtTot.Text = new DateTime(currentDate.Year, 12, 31).ToString(Constants.Format_Date);
                            colParking.Visible = false;
                            colBaan.Visible = false;
                            colECcode.Visible = false;
                            colAfvalstroom.Visible = false;
                            break;
                        case "TR":
                            txtVan.Text = new DateTime(currentDate.Year, currentDate.Month, 1).ToString(Constants.Format_Date);
                            txtTot.Text = new DateTime(currentDate.Year, currentDate.Month, DateTime.DaysInMonth(currentDate.Year, currentDate.Month)).ToString("dd/MM/yyyy");
                            colParking.Visible = false;
                            colBaan.Visible = false;
                            colECcode.Visible = false;
                            colAfvalstroom.Visible = true;
                            Utilities.LoadAfvalstromen(dropAfvalstroom, Constants.Config[Constants.drop_Message_Afvalstroom]);
                            break;
                    }
                    LoadTransactions();
                    if (tickettype == "WDT")
                    {
                        dropECcode.Items.Add(new ListItem("--- Select EC code ---", Constants.drop_Zero_Value));
                        List<string> eccodes = Utilities.LoadTransactionECcodes();
                        foreach (string str_eccode in eccodes)
                            if (!string.IsNullOrEmpty(str_eccode))
                                dropECcode.Items.Add(new ListItem(str_eccode));
                    }
                    pnlHistoryMenu.Visible = false;
                    pnlHistoriek.Visible = true;
                }
                else
                {
                    pnlHistoryMenu.Visible = true;
                    pnlHistoriek.Visible = false;
                }
            }
            else
            {
                pnlHistoryMenu.Visible = false;
                pnlHistoriek.Visible = true;
            }
        }

        private void LoadWDTERTHistory(string ticketType)
        {
            string locatie = string.Empty, eccode=string.Empty;
            string[] str_dateVan = txtVan.Text.Split('/');
            string[] str_dateTot = txtTot.Text.Split('/');
            DateTime dateVan = new DateTime(Convert.ToInt32(str_dateVan[2]), Convert.ToInt32(str_dateVan[1]), Convert.ToInt32(str_dateVan[0]));
            DateTime dateTot = new DateTime(Convert.ToInt32(str_dateTot[2]), Convert.ToInt32(str_dateTot[1]), Convert.ToInt32(str_dateTot[0]));
            if (ticketType.Equals("WDT"))
            {
                if (dropParking.SelectedValue != Constants.drop_Zero_Value && dropBaan.SelectedValue != Constants.drop_Zero_Value)
                    locatie = string.Concat(dropParking.SelectedValue, "-", dropBaan.SelectedValue);
                if (dropECcode.SelectedValue != Constants.drop_Zero_Value)
                    eccode = dropECcode.SelectedValue;
            }
            string overviewtype = Request.QueryString["OVERVIEWTYPE"];
            if(!string.IsNullOrEmpty(overviewtype))
            {
                List<Transaction> transacties = null;
                if (overviewtype.Equals("Parking"))
                    transacties = Utilities.LoadParkingTransacties(dateVan, dateTot, locatie, ticketType, eccode);
                else if (overviewtype.Equals("DirecteBelading"))
                    transacties = Utilities.LoadDirecteBeladingTransacties(dateVan, dateTot, ticketType, eccode);
                if (transacties.Count > 0)
                {
                    CreatePanel_IN(transacties.Where(t => t.TransactionCode.Equals("IN")).ToList(), ticketType, overviewtype);
                    CreatePanel_OUT(transacties.Where(t => t.TransactionCode.Equals("UIT")).ToList(), ticketType, overviewtype);
                }
                else
                {
                    CreatePanel_IN(null, string.Empty, string.Empty);
                    CreatePanel_OUT(null, string.Empty, string.Empty);
                }
            }
            else
            {
                CreatePanel_IN(null, string.Empty, string.Empty);
                CreatePanel_OUT(null, string.Empty, string.Empty);
            }
        }

        private void LoadTransportHistory()
        {
            string afvalstroom = string.Empty;
            string[] str_dateVan = txtVan.Text.Split('/');
            string[] str_dateTot = txtTot.Text.Split('/');
            DateTime dateVan = new DateTime(Convert.ToInt32(str_dateVan[2]), Convert.ToInt32(str_dateVan[1]), Convert.ToInt32(str_dateVan[0]));
            DateTime dateTot = new DateTime(Convert.ToInt32(str_dateTot[2]), Convert.ToInt32(str_dateTot[1]), Convert.ToInt32(str_dateTot[0]));
            if (dropAfvalstroom.SelectedValue != Constants.drop_Zero_Value)
                afvalstroom = dropAfvalstroom.SelectedItem.Text.Split(new string[] { " --- " }, StringSplitOptions.RemoveEmptyEntries)[1];
            List<TransportDomain> transporten = Utilities.LoadTransportTransacties(dateVan, dateTot, afvalstroom);
            if (transporten.Count > 0)
                CreatePanel_Transport(transporten);
            else
                CreatePanel_Transport(null);
        }

        private void LoadTransactions()
        {
            string tickettype = Request.QueryString["TICKETTYPE"];
            if (!string.IsNullOrEmpty(tickettype))
            {
                switch (tickettype)
                {
                    case "WDT":
                    case "ERT":
                        LoadWDTERTHistory(tickettype);
                        break;
                    case "TR":
                        LoadTransportHistory();
                        break;
                }
            }
        }
  
        protected void btnFilter_Click(object sender, EventArgs e) 
        {
            LoadTransactions();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.UrlReferrer.ToString().Split('?')[0], false);
        }

        private void CreatePanel_IN(List<Transaction> transactionsIN, string ticketType, string overviewtype)
        {
            LiteralControl lc = new LiteralControl();
            string outputcontent, total;
            if (transactionsIN == null)
            {
                outputcontent = "Geen data gevonden";
                total = Constants.drop_Zero_Value;
            }
            else if (transactionsIN.Count <= 0)
            {
                outputcontent = "Geen data gevonden";
                total = Constants.drop_Zero_Value;
            }
            else
            {
                string output = "<table class=\"table table-striped\"><thead>";
                if (overviewtype.Equals("Parking"))
                {
                    output += "<tr>"+
                        "<th>Datum</th>"+
                        "<th>Ticket nr</th>"+
                        "<th>Afdeling</th>"+
                        "<th>Hoeveelheid</th>"+
                        (ticketType.Equals("WDT")?"<th># paletten</th><th>EC code</th>":"")+
                        "</tr></thead><tbody>";
                    foreach (ParkingTransactie pt in transactionsIN)
                        output += "<tr>"+
                            "<td>" + pt.Datum.ToString(Constants.Format_Date) + "</td>"+
                            "<td>" + pt.TicketNumber + "</td>"+
                            "<td>" + pt.Afdeling + "</td>"+
                            "<td>" + string.Concat("<strong>", pt.AantalVaten, "</strong> "+(ticketType.Equals("WDT")?"("+pt.Volume+")":"")) + "</td>"+
                            (ticketType.Equals("WDT")?"<td>"+pt.AantalPaletten+"</td><td>"+pt.ECCode+"</td>":"")+
                            "</tr>";
                }
                else
                {
                    output += "<tr>" +
                        "<th>Datum</th>" +
                        "<th>Ticket nr</th>" +
                        "<th>Afdeling</th>" +
                        "<th>Hoeveelheid</th>" +
                        (ticketType.Equals("WDT") ? "<th># paletten</th><th>EC code</th>" : "") +
                        "</tr></thead><tbody>"; 
                    foreach (DirecteBeladingTransactie db in transactionsIN)
                        output += "<tr>" +
                            "<td>" + db.Datum.ToString("dd/MM/yyyy") + "</td>" +
                            "<td>" + db.TicketNumber + "</td>" +
                            "<td>" + db.Afdeling + "</td>" +
                            "<td>" + string.Concat("<strong>", db.AantalVaten, "</strong> " + (ticketType.Equals("WDT") ? "(" + db.Volume + ")" : "")) + "</td>" +
                            (ticketType.Equals("WDT") ? "<td>" + db.AantalPaletten + "</td><td>" + db.ECCode + "</td>" : "") +
                            "</tr>";
                }
                output += "</tbody></table>";
                outputcontent = output;
                total = transactionsIN.Sum(p => p.AantalVaten).ToString();
            }
            lc.Text = "<div class=\"col-xs-12 col-sm-6\"><div class=\"panel panel-success\">"+
                "<div class=\"panel-heading panel-heading-block\"><h2 class=\"formheader headerProducent\">" + (ticketType.Equals("WDT") ? "Waste disposal" : "Lege recipienten") + " - IN</h2></div>" +
                "<div class=\"panel-body\">" + outputcontent + "</div>" +
                "<div class=\"panel-footer\">Totaal aantal vaten IN: <strong>" + total + "</strong></div>" +
                "</div></div>";
            pnlOutput.Controls.Add(lc);
        }

        private void CreatePanel_OUT(List<Transaction> transactionsOUT, string ticketType, string overviewtype)
        {
            LiteralControl lc = new LiteralControl();
            string outputcontent, total;
            if (transactionsOUT == null)
            {
                outputcontent = "Geen data gevonden";
                total = Constants.drop_Zero_Value;
            }
            else if (transactionsOUT.Count <= 0)
            {
                outputcontent = "Geen data gevonden";
                total = Constants.drop_Zero_Value;
            }
            else
            {
                string output = "<table class=\"table table-striped\"><thead><tr><th>Datum</th><th>Ticket nr</th><th>Bestemming</th><th>Hoeveelheid</th>"+(ticketType.Equals("WDT")?"<th># paletten</th>":"")+"<th>INDAVER ref</th></tr></thead><tbody>";
                foreach (Transaction pt in transactionsOUT)
                        output += "<tr><td>" + pt.Datum.ToString(Constants.Format_Date) + "</td><td>" + pt.TicketNumber + "</td><td>" + pt.Verwerker + "</td><td>" + string.Concat("<strong>", pt.AantalVaten, "</strong> " + (ticketType.Equals("WDT") ? "(" + pt.Volume + ")" : "")) + "</td>"+(ticketType.Equals("WDT")?"<td>"+pt.AantalPaletten+"</td>":"")+"<td>" + pt.IndaverReferentie + "</td></tr>";
                output += "</tbody></table>";
                outputcontent = output;
                total = transactionsOUT.Sum(p => p.AantalVaten).ToString();
            }
            lc.Text = "<div class=\"col-xs-12 col-sm-6\"><div class=\"panel panel-success\">" +
                "<div class=\"panel-heading panel-heading-block\"><h2 class=\"formheader headerProducent\">"+(ticketType.Equals("WDT") ? "Waste disposal":"Lege recipienten")+" - OUT</h2></div>" +
                "<div class=\"panel-body\">" + outputcontent + "</div>" +
                "<div class=\"panel-footer\">Totaal aantal vaten OUT: <strong>" + total + "</strong></div>" +
                "</div></div>";
            pnlOutput.Controls.Add(lc);
        }

        private void CreatePanel_Transport(List<TransportDomain> transporten)
        {
            LiteralControl lc = new LiteralControl();
            string outputcontent, total;
            if (transporten == null)
            {
                outputcontent = "Geen data gevonden";
                total = Constants.drop_Zero_Value;
            }
            else if (transporten.Count <= 0)
            {
                outputcontent = "Geen data gevonden";
                total = Constants.drop_Zero_Value;
            }
            else
            {
                string output = "<table class=\"table table-striped\"><thead><tr><th>Datum</th><th>Afvalstroom</th><th>Specificatie</th><th>Gewicht (Kg)</th><th>CMR</th><th>Verwerver</th><th>Vervoerder</th><th>Verwerker</th></tr></thead><tbody>";
                foreach (TransportDomain tp in transporten)
                    output += "<tr><td>" + tp.Datum.ToString(Constants.Format_Date) + "</td><td>" + tp.Afvalstroom + "</td><td>" + tp.Specificatie + "</td><td>" + tp.Gewicht + "</td><td>" + tp.CMR + "</td><td>" + tp.Verwerver + "</td><td>" + tp.Vervoerder + "</td><td>" + tp.Verwerker + "</td></tr>";
                output += "</tbody></table>";
                outputcontent = output;
                total = transporten.Count().ToString();
            }
            lc.Text = "<div class=\"col-xs-12 col-sm-12 col-md-12 col-lg-12\"><div class=\"panel panel-success\">" +
                "<div class=\"panel-heading panel-heading-block\"><h2 class=\"formheader headerProducent\">TRANSPORTEN</h2></div>" +
                "<div class=\"panel-body\">" + outputcontent + "</div>" +
                "<div class=\"panel-footer\">Totaal aantal transporten: <strong>" + total + "</strong></div>" +
                "</div></div>";
            pnlOutput.Controls.Add(lc);
        }
    }
}
