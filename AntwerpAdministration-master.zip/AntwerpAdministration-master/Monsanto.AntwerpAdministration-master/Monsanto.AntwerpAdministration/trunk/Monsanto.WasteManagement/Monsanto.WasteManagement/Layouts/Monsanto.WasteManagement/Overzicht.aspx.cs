﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using Monsanto.WasteManagement.WM.Enums;
using System.Collections.Generic;
using System.Web.UI;
using System.Linq;

namespace Monsanto.WasteManagement.Layouts.Monsanto.WasteManagement
{
    public partial class Overzicht : LayoutsPageBase
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            wastedisposalheaderimg.Src = Constants.Config[Constants.Header_Image];
            wastedisposalheaderimg.Alt = "WM";
            wastedisposalheader.InnerText = Constants.Config[Constants.Header_Text];
            if (!IsPostBack)
            {
                string overviewtype = Request.QueryString["OVERVIEWTYPE"];
                if (!string.IsNullOrEmpty(overviewtype))
                {
                    switch (overviewtype)
                    {
                        case "Parking":
                            LoadOverzichtTickets(Status.Afgewerkt);
                            break;
                        case "DirecteBelading":
                            LoadOverzichtTickets(Status.Directe_Belading);
                            break;
                    }
                    pnlOverzichtMenu.Visible = false;
                    pnlOverzicht.Visible = true;
                }
                else
                {
                    pnlOverzichtMenu.Visible = true;
                    pnlOverzicht.Visible = false;
                }
            }
            else
            {
                pnlOverzichtMenu.Visible = false;
                pnlOverzicht.Visible = true;
            }
        }

        private void LoadOverzichtTickets(Status status)
        {
            List<WasteDisposalTicket> tickets = Utilities.LoadOverzichtTickets(status);
            CreatePanel_Overzicht(status, tickets);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect(Request.UrlReferrer.ToString().Split('?')[0], false);
        }

        protected bool IsWasteMgt()
        {
            return Utilities.IsWaste() || Utilities.HasAdminPermission();
        }

        private void CreatePanel_Overzicht(Status status, List<WasteDisposalTicket> tickets)
        {
            LiteralControl lc = new LiteralControl();
            string outputcontent;
            if (tickets == null)
                outputcontent = "Geen data gevonden";
            else if (tickets.Count <= 0)
                outputcontent = "Geen data gevonden";
            else
            {
                string output = "<table class=\"table table-striped\"><thead><tr>"+
                    "<th>Ticket nr</th>"+
                    "<th>Datum</th>"+
                    "<th>Afdeling</th>"+
                    "<th>Product</th>"+
                    "<th>Volume</th>"+
                    "<th>Aantal vaten</th>"+
                    "<th>Aantal paletten</th>"+
                    "<th>UN</th>"+
                    "<th>ADR</th>" +
                    "<th></th>" +(IsWasteMgt()?"<th></th>":"")+
                    "</tr></thead><tbody>";
                if (status.Equals(Status.Afgewerkt))
                {
                    var groupedList = tickets.GroupBy(t => new { t.LocatieAfvalparking, t.EC }).Select(t => t.ToList()).ToList();
                    string locatie = string.Empty, eccode = string.Empty;
                    foreach (var group in groupedList)
                    {
                        foreach (var ticket in group)
                        {
                            if(locatie!=ticket.LocatieAfvalparking)
                                output += "<tr class=\"parking-main-group\"><td colspan=\"" + (IsWasteMgt() ? "11" : "10") + "\">" + ticket.LocatieAfvalparking + "</td></tr>";
                            if(eccode!=ticket.EC||locatie!=ticket.LocatieAfvalparking)
                                output += "<tr class=\"parking-sub-group\"><td colspan=\"" + (IsWasteMgt() ? "11" : "10") + "\">" + ticket.EC + "</td></tr>";
                            output += GetTicketRow(ticket,false);
                            locatie=ticket.LocatieAfvalparking;
                            eccode=ticket.EC;
                        }
                    }
                }
                else if (status.Equals(Status.Directe_Belading))
                {
                    foreach (var ticket in tickets)
                        output += GetTicketRow(ticket,true);
                }
                output += "</tbody></table>";
                outputcontent = output;
            }
            lc.Text = "<div class=\"col-xs-12 col-sm-12 col-md-12 col-lg-12\"><div class=\"panel panel-success\">" +
                "<div class=\"panel-heading panel-heading-block\"><h2 class=\"formheader headerProducent\">Waste Disposal Tickets - "+(status.Equals(Status.Afgewerkt)?"Afvalparking overzicht":"Directe belading overzicht")+"</h2></div>" +
                "<div class=\"panel-body\">" + outputcontent + "</div>" +
                "</div></div>";
            pnlOutput.Controls.Add(lc);
        }

        private string GetTicketRow(WasteDisposalTicket ticket, bool directebelading)
        {
            return "<tr><td>" + ticket.TicketNumber + "</td><td>" + ticket.DatumDO.ToString(Constants.Format_Date) + "</td><td>" + ticket.Afdeling + "</td>" +
                    "<td>" + ticket.Product + "</td><td>" + ticket.Volume + "</td><td>" + ticket.AantalVaten + "</td>" +
                    "<td>" + ticket.AantalPaletten + "</td><td>" + ticket.UN + "</td><td>" + ticket.GetSmallADR_Pics(ticket.ADR_Pics) + "</td>" +
                    "<td>" +
                    "<a class=\"btnView hideprint\" href=\""+SPContext.Current.Web.Url+"/SitePages/WasteManagement.aspx?REQUESTTYPE=WDT&FORM=display&ITEMID=" + ticket.ID + "\"><i class=\"fa fa-eye fa-2x\"></i></a>" +
                    "</td>"+
                    (IsWasteMgt() ? "<td><a class=\"btnOut hideprint\"href=\"" + SPContext.Current.Web.Url + "/_layouts/Monsanto.WasteManagement/Uitschrijven.aspx?REQUESTTYPE=WDT&TICKETID=" + ticket.ID + (directebelading ? "&DIRECTEBELADING=TRUE" : "") + "\"><i class=\"fa fa-truck fa-flip-horizontal fa-2x\"></i></a></td>" : "") +
                    "</tr>";
        }
    }
}
