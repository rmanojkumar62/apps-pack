﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement
{
    public class Constants
    {
        public static int max_ticket_nr_WDT = 11353;
        public static int max_ticket_nr_ERT = 1;
        
        public const string LogString="MONSANTO WASTEDISPOSAL ---- {0}:{1} ---- {2}";
        public static readonly char CHAR_Slash = '/';
        public const string Str_Dash_Separator = " - ";
        public static readonly string drop_Zero_Value = "0";
        
        public const string Status_Geïnitieerd = "Geïnitieerd";
        public const string Status_InBehandeling = "In behandeling";
        public const string Status_Afgewerkt = "Afgewerkt";
        public const string Status_Uitgeschreven = "Uitgeschreven";
        public const string Status_TerugNaarProducent = "Terug naar producent";
        public const string Status_LabelsAfhaling = "Labels klaar voor afhaling";
        public const string Status_DirecteBelading = "Directe belading";
        //public const string Status_LabelsBevestiging = "Labels bevestigd";

        public const string MailTemplate_WDT = "MailTemplate_WDT";
        public const string MailTemplate_ERT = "MailTemplate_ERT";
        
        public const string Format_Date = "dd/MM/yyyy";
        public const string Format_Timestamp = "dd/MM/yyyy hh:mm";

        public const string List_Configuration = "Configuration";

        public const string Col_ID = "ID";
        public const string Col_Title = "Title";
        public const string Col_Value = "Value";
        public const string Col_Label = "Label";
        public const string Col_Status = "Status";
        public const string Col_TicketNr = "Ticket_x0020_nr";
        public const string Col_Baan = "Baan";
        public const string Col_Verantwoordelijke = "Verantwoordelijke";

        /**** CONFIGURATION PARAMETERS ****/

        /**** WASTE MANAGEMENT USER CONTROL ****/
        public const string Header_Image = "Header_Image";
        public const string Header_Text = "Header_Text";
        public const string ERT_header = "ERT_header";
        public const string ERT_gereinigd_header = "ERT_gereinigd_header";
        public const string ERT_ongereinigd_header = "ERT_ongereinigd_header";
        public const string ERT_gereinigd_title = "ERT_gereinigd_title";
        public const string ERT_ongereinigd_title = "ERT_ongereinigd_title";
        public const string ERT_gereinigd_ListItems = "ERT_gereinigd_ListItems";
        public const string ERT_ongereinigd_ListItems = "ERT_ongereinigd_ListItems";
        public const string Button_Gereinigd = "Button_Gereinigd";
        public const string Button_Ongereinigd = "Button_Ongereinigd";
        public const string Button_ConfirmationClose = "Button_ConfirmationClose";

        public static readonly string title_WDT = "title_WDT";
        public static readonly string title_ERT = "title_ERT";
        public static readonly string str_NietVanToepassing = "str_NietVanToepassing";

        public const string Group_WasteMembers = "Group_WasteMembers";
        public const string Group_DOMembers = "Group_DOMembers";

        public const string Button_Editeer = "Button_Editeer";
        public const string Button_Opslaan = "Button_Opslaan";
        public const string Button_Sluiten = "Button_Sluiten";
        public const string Button_Print = "Button_Print";
        public const string Button_AanvraagVerzenden = "Button_AanvraagVerzenden";
        public const string Button_LabelsAfhaling = "Button_LabelsAfhaling";
        public const string Button_LabelsBevestiging = "Button_LabelsBevestiging";
        public const string Button_StuurDO = "Button_StuurDO";
        public const string Button_DirecteBelading = "Button_DirecteBelading";
        public const string Button_Afgewerkt = "Button_Afgewerkt";
        public const string Button_Afsluiten = "Button_Afsluiten";
        public const string Button_TerugNaarProducent = "Button_TerugNaarProducent";
        public const string Button_TerugNaarWaste = "Button_TerugNaarWaste";
        
        public const string List_WasteDisposalTicket = "List_WasteDisposalTicket";
        public const string List_EmptyRecipientTicket = "List_EmptyRecipientTicket";
        public const string List_Afdelingen = "List_Afdelingen";
        public const string List_Producten = "List_Producten";
        public const string List_Volumes = "List_Volumes";
        public const string List_ADR = "List_ADR";
        public const string List_INDAVER = "List_INDAVER";
        public const string List_Afvalparking = "List_Afvalparking";
        public const string List_INDAVER_Labels = "List_INDAVER_Labels";
        public const string List_ADR_Baan = "List_ADR_Baan";
        public const string List_Firmas = "List_Firmas";
        public const string List_Parking = "List_Parking";
        public const string List_DirecteBelading = "List_DirecteBelading";
        public const string List_Transport = "List_Transport";

        public const string CAML_Afdelingen = "CAML_Afdelingen";
        public const string CAML_Volumes = "CAML_Volumes";
        public const string CAML_ADR = "CAML_ADR";
        public const string CAML_ADR_ERT = "CAML_ADR_ERT";
        public const string CAML_Producten = "CAML_Producten";
        public const string CAML_Producten_Andere = "CAML_Producten_Andere";
        public const string CAML_Locaties_1 = "CAML_Locaties_1";
        public const string CAML_Locaties_2 = "CAML_Locaties_2";
        public const string CAML_Banen_Gereinigd = "CAML_Banen_Gereinigd";
        public const string CAML_Banen_Ongereinigd = "CAML_Banen_Ongereinigd";
        public const string CAML_ADRLabel = "CAML_ADRLabel";
        public const string CAML_IndaverLabel = "CAML_IndaverLabel";
        public const string CAML_MaxTicketNr = "CAML_MaxTicketNr";
        public const string CAML_Firmas_ByType = "CAML_Firmas_ByType";
        public const string CAML_Parking = "CAML_Parking";
        public const string CAML_Afvalstromen = "CAML_Afvalstromen";
        public const string CAML_Overzicht_Parking = "CAML_Overzicht_Parking";
        public const string CAML_Overzicht_DirecteBelading = "CAML_Overzicht_DirecteBelading";
        public const string CAML_Transacties_Parking_WithLocAndEC = "CAML_Transacties_Parking_WithLocAndEC";
        public const string CAML_Transacties_Parking_WithLoc = "CAML_Transacties_Parking_WithLoc";
        public const string CAML_Transacties_Parking_WithEC = "CAML_Transacties_Parking_WithEC";
        public const string CAML_Transacties_Parking_WithoutLocAndEC = "CAML_Transacties_Parking_WithoutLocAndEC";
        public const string CAML_Transacties_DirecteBelading_WithEC = "CAML_Transacties_DirecteBelading_WithEC";
        public const string CAML_Transacties_DirecteBelading_WithoutEC = "CAML_Transacties_DirecteBelading_WithoutEC";
        public const string CAML_Transacties_Transport_WithStroom = "CAML_Transacties_Transport_WithStroom";
        public const string CAML_Transacties_Transport_WithoutStroom = "CAML_Transacties_Transport_WithoutStroom";

        public static readonly string drop_Message_Afdeling = "drop_Message_Afdeling";
        public static readonly string drop_Message_Product = "drop_Message_Product";
        public static readonly string drop_Message_Volume = "drop_Message_Volume";
        public static readonly string drop_Message_Locatie = "drop_Message_Locatie";
        public static readonly string drop_Message_Verpakking = "drop_Message_Verpakking";
        public static readonly string drop_Message_Afvalstroom = "drop_Message_Afvalstroom";
        public static readonly string drop_Message_Verwerver = "drop_Message_Verwerver";
        public static readonly string drop_Message_Vervoerder = "drop_Message_Vervoerder"; 
        public static readonly string drop_Message_Verwerker = "drop_Message_Verwerker";
        public static readonly string drop_Message_Firma = "drop_Message_Firma";

        public const string PageURL = "PageURL";
        public const string SiteRootURL = "SiteRootURL";
        public const string MailLogoPath = "MailLogoPath";
        public const string WDT_EmailApp = "WDT_EmailApp";
        public const string ERT_EmailApp = "ERT_EmailApp";
        public const string MailSMTP = "MailSMTP";
        public const string WasteMailbox = "WasteMailbox";
        public const string DO_DistributionList = "DO_DistributionList";
        public const string Mail_Subject_WDT = "Mail_Subject_WDT";
        public const string Mail_Subject_ERT = "Mail_Subject_ERT";

        public const string Message_Confirmation_Aanvraagverzenden = "Message_Confirmation_Aanvraagverzenden";
        public const string Message_Confirmation_StuurDO = "Message_Confirmation_StuurDO";
        public const string Message_Confirmation_Afgewerkt = "Message_Confirmation_Afgewerkt";
        public const string Message_Confirmation_Afsluiten = "Message_Confirmation_Afsluiten";
        public const string Message_Confirmation_Save = "Message_Confirmation_Save";
        public const string Message_Confirmation_Producent = "Message_Confirmation_Producent";
        public const string Message_Confirmation_Waste = "Message_Confirmation_Waste";
        public const string Message_Required_Fields = "Message_Required_Fields";

        public const string ACTION_Save_Icon = "ACTION_Save_Icon";
        public const string ACTION_Submit_Icon = "ACTION_Submit_Icon";
        public const string ACTION_Return_Icon = "ACTION_Return_Icon"; 
        public const string Disp_Edit_Icons = "Disp_Edit_Icons";

        /**** WASTE DISPOSAL & LEGE RECIPIENTEN USER CONTROL ****/
        public const string Control_Heading_Producent = "Control_Heading_Producent";
        public const string Control_Heading_AfvalParking_DO = "Control_Heading_AfvalParking_DO";
        public const string Control_Heading_AfvalParking_Waste = "Control_Heading_AfvalParking_Waste";
        public const string Control_Heading_ADR = "Control_Heading_ADR";
        public const string Control_Heading_INDAVER = "Control_Heading_INDAVER";

        /**** DEPARTMENT USER CONTROL ****/
        public const string Department_WasteManagement_Header = "Department_WasteManagement_Header";
        public const string Department_WasteManagement_Responsible = "Department_WasteManagement_Responsible";
        public const string Department_WasteManagement_Date = "Department_WasteManagement_Date";
        public const string Department_WasteManagement_Remarks = "Department_WasteManagement_Remarks";
        public const string Department_DO_Header = "Department_DO_Header";
        public const string Department_DO_Responsible = "Department_DO_Responsible";
        public const string Department_DO_Date = "Department_DO_Date";
        public const string Department_DO_Remarks = "Department_DO_Remarks";
        public const string Department_RFV_Opmerkingen = "Department_RFV_Opmerkingen";

        /**** ATTACHMENT USER CONTROL ****/
        public const string Control_Heading_Attachment = "Control_Heading_Attachment";
        public const string Button_AddAttachment = "Button_AddAttachment";
        public const string Button_Browse = "Button_Browse";
        public const string Button_Upload = "Button_Upload";
        public const string Button_Cancel = "Button_Cancel";
        public const string Label_NoAttachments = "Label_NoAttachments";

        /**** CHANGE LOG USER CONTROL ****/
        public const string Control_Heading_ChangeLog = "Control_Heading_ChangeLog";
        

        public static Dictionary<string, string> _Config;
        public static Dictionary<string, string> Config
        {
            get
            {
                if (_Config == null)
                    _Config = Utilities.GetConfigValues();
                return _Config;
            }
        }

        private Constants() { }
    }
}
