﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement.WM.Domain
{
    public abstract class Transaction
    {
        private string _transactioncode;
        private string _ticketnr;
        private DateTime _datum;
        private string _afdeling;
        private string _product;
        private string _volume;
        private int _aantalvaten;
        private int _aantalpaletten;
        private string _eccode;
        private string _indaverreferentie;
        private string _verwerker;
        private RequestType _tickettype;

        public Transaction() { }

        public Transaction(string transactioncode, string ticketnumber, DateTime datum, string afdeling, 
            int aantalvaten, int aantalpaletten, RequestType tickettype)
        {
            this._transactioncode = transactioncode;
            this._ticketnr = ticketnumber;
            this._datum = datum;
            this._afdeling = afdeling;
            this._aantalvaten = aantalvaten;
            this._aantalpaletten = aantalpaletten;
            this._tickettype = tickettype;
        }

        public Transaction(string transactioncode, string ticketnumber, DateTime datum, string afdeling,
            string product, string volume, int aantalvaten, int aantalpaletten, string eccode, RequestType tickettype)
        {
            this._transactioncode = transactioncode;
            this._ticketnr = ticketnumber;
            this._datum = datum;
            this._afdeling = afdeling;
            this._product = product;
            this._volume = volume;
            this._aantalvaten = aantalvaten;
            this._aantalpaletten = aantalpaletten;
            this._eccode = eccode;
            this._tickettype = tickettype;
        }

        public Transaction(string transactioncode, string ticketnumber, DateTime datum, string afdeling,
            string product, string volume, int aantalvaten, int aantalpaletten, string eccode, string indaverreferentie,
            string verwerker, RequestType tickettype)
        {
            this._transactioncode = transactioncode;
            this._ticketnr = ticketnumber;
            this._datum = datum;
            this._afdeling = afdeling;
            this._product = product;
            this._volume = volume;
            this._aantalvaten = aantalvaten;
            this._aantalpaletten = aantalpaletten;
            this._indaverreferentie = indaverreferentie;
            this._verwerker = verwerker;
            this._eccode = eccode;
            this._tickettype = tickettype;
        }

        public string TransactionCode { get { return _transactioncode; } set { _transactioncode = value; } }
        public string TicketNumber { get { return _ticketnr; } set { _ticketnr = value; } }
        public DateTime Datum { get { return _datum; } set { _datum = value; } }
        public string Afdeling { get { return _afdeling; } set { _afdeling = value; } }
        public string Product { get { return _product; } set { _product = value; } }
        public string Volume { get { return _volume; } set { _volume = value; } }
        public int AantalVaten { get { return _aantalvaten; } set { _aantalvaten = value; } }
        public int AantalPaletten { get { return _aantalpaletten; } set { _aantalpaletten = value; } }
        public string IndaverReferentie { get { return _indaverreferentie; } set { _indaverreferentie = value; } }
        public string Verwerker { get { return _verwerker; } set { _verwerker = value; } }
        public string ECCode { get { return _eccode; } set { _eccode = value; } }
        public RequestType TicketType { get { return _tickettype; } set { _tickettype = value; } }
    }
}
