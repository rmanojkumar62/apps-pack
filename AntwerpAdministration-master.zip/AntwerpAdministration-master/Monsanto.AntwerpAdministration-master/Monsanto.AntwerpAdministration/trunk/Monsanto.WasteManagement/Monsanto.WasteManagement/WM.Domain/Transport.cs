﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement.WM.Domain
{
    public class Transport
    {
        private string _afvalstroom;
        private string _specificatie;
        private DateTime _datum;
        private string _afdeling;
        private int _gewicht;
        private string _cmr;
        private string _verwerver;
        private string _vervoerder;
        private string _verwerker;

        public Transport() { }

        public Transport(string afvalstroom, string specificatie, DateTime datum, string afdeling, int gewicht, string cmr,string verwerver,string vervoerder,string verwerker)
        {
            this._afvalstroom = afvalstroom;
            this._specificatie = specificatie;
            this._datum = datum;
            this._afdeling = afdeling;
            this._gewicht = gewicht;
            this._cmr = cmr;
            this._verwerver = verwerver;
            this._vervoerder = vervoerder;
            this._verwerker = verwerker;
        }

        public string Afvalstroom { get { return _afvalstroom; } set { _afvalstroom = value; } }
        public string Specificatie { get { return _specificatie; } set { _specificatie = value; } }
        public DateTime Datum { get { return _datum; } set { _datum = value; } }
        public string Afdeling { get { return _afdeling; } set { _afdeling = value; } }
        public int Gewicht { get { return _gewicht; } set { _gewicht = value; } }
        public string CMR { get { return _cmr; } set { _cmr = value; } }
        public string Verwerver { get { return _verwerver; } set { _verwerver = value; } }
        public string Vervoerder { get { return _vervoerder; } set { _vervoerder = value; } }
        public string Verwerker { get { return _verwerker; } set { _verwerker = value; } }
    }
}
