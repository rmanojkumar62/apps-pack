﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement
{
    [Serializable]
    public class Product
    {
        private int _id;
        private int _aantal;
        private string _product;
        private string _adr;
        private string _un;
        private string _verpakkingswijze;
        private string _afvalparking;
        private string _baan;

        public Product() { }

        public Product(int aantal, string product, string adr, string un, string verpakkingswijze)
        {
            this._aantal = aantal;
            this._product = product;
            this._adr = adr;
            this._un = un;
            this._verpakkingswijze = verpakkingswijze;
        }

        public Product(int id, int aantal, string product, string adr, string un, string verpakkingswijze)
        {
            this._id = id;
            this._aantal = aantal;
            this._product = product;
            this._adr = adr;
            this._un = un;
            this._verpakkingswijze = verpakkingswijze;
        }

        public int ID { get { return _id; } set { _id = value; } }
        public int Aantal { get { return _aantal; } set { _aantal = value; } }
        public string ProductName { get { return _product; } set { _product = value; } }
        public string ADR { get { return string.IsNullOrEmpty(_adr) ? "geen" : _adr; } set { _adr = value; } }
        public string UN { get { return (string.IsNullOrEmpty(_un)) ? "geen" : _un; } set { _un = value; } }
        public string Verpakkingswijze { get { return _verpakkingswijze; } set { _verpakkingswijze = value; } }
        public string Afvalparking { get { return _afvalparking; } set { _afvalparking = value; } }
        public string Baan { get { return _baan; } set { _baan = value; } }
    }
}
