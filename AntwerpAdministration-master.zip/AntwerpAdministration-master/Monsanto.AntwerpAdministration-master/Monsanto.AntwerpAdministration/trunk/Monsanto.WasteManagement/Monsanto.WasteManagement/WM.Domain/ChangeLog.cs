﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement
{
    [Serializable]
    public class ChangeLog
    {
        private string _verantwoordelijke;
        private string _afdeling;
        private DateTime _datum;
        private ButtonAction _action;
        private string _oldstatus;
        private string _newstatus;

        public ChangeLog() { }

        public ChangeLog(string verantwoordelijke, string afdeling, DateTime datum, ButtonAction action, string oldstatus, string newstatus)
        {
            this._verantwoordelijke = verantwoordelijke;
            this._afdeling = afdeling;
            this._datum = datum;
            this._action = action;
            this._oldstatus = oldstatus;
            this._newstatus = newstatus;
        }

        public string Verantwoordelijke { get { return _verantwoordelijke; } set { _verantwoordelijke = value; } }
        public string Afdeling { get { return _afdeling; } set { _afdeling = value; } }
        public DateTime Datum { get { return _datum; } set { _datum = value; } }
        public ButtonAction Action { get { return _action; } set { _action = value; } }
        public string OldStatus { get { return _oldstatus; } set { _oldstatus = value; } }
        public string NewStatus { get { return _newstatus; } set { _newstatus = value; } }
    }
}
