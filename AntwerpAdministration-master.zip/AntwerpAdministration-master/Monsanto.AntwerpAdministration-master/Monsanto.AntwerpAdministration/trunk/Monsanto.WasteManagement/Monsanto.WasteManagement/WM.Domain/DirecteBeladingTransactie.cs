﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement.WM.Domain
{
    public class DirecteBeladingTransactie : Transaction
    {
        public DirecteBeladingTransactie() { }

        /*ERT CUNSTRUCTOR*/
        public DirecteBeladingTransactie(string transactioncode, string ticketnumber, DateTime datum, string afdeling, 
            int aantalvaten, int aantalpaletten, RequestType tickettype) :
            base(transactioncode, ticketnumber, datum, afdeling, aantalvaten, aantalpaletten, tickettype) { }

        /*WDT CUNSTRUCTOR*/
        public DirecteBeladingTransactie(string transactioncode, string ticketnumber, DateTime datum, string afdeling,
            string product, string volume, int aantalvaten, int aantalpaletten, string ec, RequestType tickettype) :
            base(transactioncode, ticketnumber, datum, afdeling, product, volume, aantalvaten, aantalpaletten, ec, tickettype) { }

        /*SAVE CONSTRUCTOR*/
        public DirecteBeladingTransactie(string transactioncode, string ticketnumber, DateTime datum, string afdeling,
            string product, string volume, int aantalvaten, int aantalpaletten, string ec, string indaverreferentie, string verwerker, RequestType tickettype) :
            base(transactioncode, ticketnumber, datum, afdeling, product, volume, aantalvaten, aantalpaletten, ec, indaverreferentie, verwerker, tickettype) { }
    }
}
