﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement.WM.Domain
{
    public class Firma
    {
        private int _id;
        private string _naam;
        private string _straat;
        private string _postcode;
        private string _gemeente;
        private string _land;
        private bool _verwerver;
        private bool _vervoerder;
        private bool _verwerker;

        public Firma() { }

        public Firma(int id, string naam, string straat, string postcode, string gemeente, string land)
        {
            this._id = id;
            this._naam = naam;
            this._straat = straat;
            this._postcode = postcode;
            this._gemeente = gemeente;
            this._land = land;
        }

        public Firma(int id, string naam, string straat, string postcode, string gemeente, string land, bool verwerver, bool vervoerder, bool verwerker)
        {
            this._id = id;
            this._naam = naam;
            this._straat = straat;
            this._postcode = postcode;
            this._gemeente = gemeente;
            this._land = land;
            this._verwerver = verwerver;
            this._vervoerder = vervoerder;
            this._verwerker = verwerker;
        }

        public int ID { get { return _id; } set { _id = value; } }
        public string Naam { get { return _naam; } set { _naam = value; } }
        public string Straat { get { return _straat; } set { _straat = value; } }
        public string Postcode { get { return _postcode; } set { _postcode = value; } }
        public string Gemeente { get { return _gemeente; } set { _gemeente = value; } }
        public string Land { get { return _land; } set { _land = value; } }
        public bool Verwerver { get { return _verwerver; } set { _verwerver = value; } }
        public bool Vervoerder { get { return _vervoerder; } set { _vervoerder = value; } }
        public bool Verwerker { get { return _verwerker; } set { _verwerker = value; } }
    }
}
