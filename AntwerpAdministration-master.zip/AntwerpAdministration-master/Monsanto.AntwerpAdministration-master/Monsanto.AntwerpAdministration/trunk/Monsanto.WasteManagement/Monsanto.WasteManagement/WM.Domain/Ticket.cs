﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement
{
    public class Ticket
    {
        private int _attachmentcount;
        private int _id;
        private string _status;
        private string _ticketid;
        private string _ticketnumber;
        private string _ticketname;
        private string _afdelingid;
        private string _afdeling;
        private string _opmerkingproducent;
        private string _opmerkingwaste;
        private string _opmerkingdo;
        private string _verantwoordelijkeproducent;
        private string _verantwoordelijkewaste;
        private string _verantwoordelijkedo;
        private DateTime _datumaanvraag;
        private DateTime _datumwaste;
        private DateTime _datumdo;
        private List<ChangeLog> _logs;

        public Ticket() { }

        public Ticket(int attachmentcount, int id, string status, string ticketid, string ticketnumber, string ticketname,
            string afdelingid, string afdeling,
            string opmerkingproducent, string opmerkingwaste, string opmerkingdo,
            string verantwoordelijkeproducent, string verantwoordelijkewaste, string verantwoordelijkedo,
            DateTime datumaanvraag, DateTime datumwaste, DateTime datumdo, List<ChangeLog> logs)
        {
            this._attachmentcount = attachmentcount;
            this._id = id;
            this._status = status;
            this._ticketid = ticketid;
            this._ticketnumber = ticketnumber;
            this._ticketname = ticketname;
            this._afdelingid = afdelingid;
            this._afdeling = afdeling;
            this._opmerkingproducent = opmerkingproducent;
            this._opmerkingwaste = opmerkingwaste;
            this._opmerkingdo = opmerkingdo;
            this._verantwoordelijkeproducent = verantwoordelijkeproducent;
            this._verantwoordelijkewaste = verantwoordelijkewaste;
            this._verantwoordelijkedo = verantwoordelijkedo;
            this._datumaanvraag = datumaanvraag;
            this._datumwaste = datumwaste;
            this._datumdo = datumdo;
            this._logs = logs;
        }
        public int AttachmentCount { get { return _attachmentcount; } set { _attachmentcount = value; } }
        public int ID { get { return _id; } set { _id = value; } }
        public string Status { get { return _status; } set { _status = value; } }
        public string TicketID { get { return _ticketid; } set { _ticketid = value; } }
        public string TicketNumber { get { return _ticketnumber; } set { _ticketnumber = value; } }
        public string TicketName { get { return _ticketname; } set { _ticketname = value; } }
        public string AfdelingID { get { return _afdelingid; } set { _afdelingid = value; } }
        public string Afdeling { get { return _afdeling; } set { _afdeling = value; } }
        public string OpmerkingProducent { get { return _opmerkingproducent; } set { _opmerkingproducent = value; } }
        public string OpmerkingWaste { get { return _opmerkingwaste; } set { _opmerkingwaste = value; } }
        public string OpmerkingDO { get { return _opmerkingdo; } set { _opmerkingdo = value; } }
        public string VerantwoordelijkeProducent { get { return _verantwoordelijkeproducent; } set { _verantwoordelijkeproducent = value; } }
        public string VerantwoordelijkeWaste { get { return _verantwoordelijkewaste; } set { _verantwoordelijkewaste = value; } }
        public string VerantwoordelijkeDO { get { return _verantwoordelijkedo; } set { _verantwoordelijkedo = value; } }
        public DateTime DatumAanvraag { get { return _datumaanvraag; } set { _datumaanvraag = value; } }
        public DateTime DatumWaste { get { return _datumwaste; } set { _datumwaste = value; } }
        public DateTime DatumDO { get { return _datumdo; } set { _datumdo = value; } }
        public List<ChangeLog> Logs { get { return _logs; } set { _logs = value; } }

        public string GetTicketLink(string requesttype)
        {
            return string.Concat(Constants.Config[Constants.PageURL], "?REQUESTTYPE=", requesttype, "&FORM=display&ITEMID=", ID);
        }

        public string GetTicketLinkDisplay(string requesttype)
        {
            return string.Concat(requesttype, " ", TicketNumber);
        }
    }
}
