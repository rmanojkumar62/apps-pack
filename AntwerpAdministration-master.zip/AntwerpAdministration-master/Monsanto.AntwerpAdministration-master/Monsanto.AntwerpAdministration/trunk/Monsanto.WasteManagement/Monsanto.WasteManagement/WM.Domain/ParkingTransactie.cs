﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Monsanto.WasteManagement.WM.Enums;

namespace Monsanto.WasteManagement.WM.Domain
{
    public class ParkingTransactie : Transaction
    {
        private string _locatieafvalvaten;

        public ParkingTransactie() { }

        /*ERT CUNSTRUCTOR*/
        public ParkingTransactie(string transactioncode, string ticketnumber, DateTime datum, string afdeling, 
            int aantalvaten, int aantalpaletten, RequestType tickettype)
            : base(transactioncode, ticketnumber, datum, afdeling, aantalvaten, aantalpaletten, tickettype) { }

        /*WDT CUNSTRUCTOR*/
        public ParkingTransactie(string transactioncode, string ticketnumber, DateTime datum, string afdeling,
            string product, string volume, int aantalvaten, int aantalpaletten, string locatieafvalvaten, string eccode, RequestType tickettype)
            : base(transactioncode, ticketnumber, datum, afdeling, product, volume, aantalvaten, aantalpaletten, eccode, tickettype)
        {
            this._locatieafvalvaten = locatieafvalvaten;
        }

        /*SAVE CONSTRUCTOR*/
        public ParkingTransactie(string transactioncode, string ticketnumber, DateTime datum, string afdeling, 
            string product, string volume, int aantalvaten, int aantalpaletten, string locatieafvalvaten, string indaverreferentie, string verwerker, string eccode, RequestType tickettype)
            : base(transactioncode, ticketnumber, datum, afdeling, product, volume, aantalvaten, aantalpaletten, eccode, indaverreferentie, verwerker, tickettype)
        {
            this._locatieafvalvaten = locatieafvalvaten;
        }

        public string LocatieAfvalvaten { get { return _locatieafvalvaten; } set { _locatieafvalvaten = value; } }
    }
}
