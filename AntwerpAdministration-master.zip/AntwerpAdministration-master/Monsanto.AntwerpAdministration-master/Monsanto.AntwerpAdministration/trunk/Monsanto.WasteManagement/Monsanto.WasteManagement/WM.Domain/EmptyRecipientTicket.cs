﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement
{
    public class EmptyRecipientTicket : Ticket
    {
        private string _tickettype;
        private List<Product> _products;

        public EmptyRecipientTicket() { }

        public EmptyRecipientTicket(int attachmentcount, int id, string status, string ticketid, string ticketnumber, string ticket, string tickettype, string afdelingid, string afdeling,
            string opmerkingproducent, string opmerkingwaste,
            string opmerkingdo, string verantwoordelijkeproducent, string verantwoordelijkewaste, string verantwoordelijkedo,
            DateTime datumaanvraag, DateTime datumwaste, DateTime datumdo, List<ChangeLog> logs, List<Product> products)
        {
            this.AttachmentCount = attachmentcount;
            this.ID = id;
            this.Status = status;
            this.TicketID = ticketid;
            this.TicketNumber = ticketnumber;
            this.TicketName = ticket;
            this._tickettype = tickettype;
            this.AfdelingID = afdelingid;
            this.Afdeling = afdeling;
            this.OpmerkingProducent = opmerkingproducent;
            this.OpmerkingWaste = opmerkingwaste;
            this.OpmerkingDO = opmerkingdo;
            this.VerantwoordelijkeProducent = verantwoordelijkeproducent;
            this.VerantwoordelijkeWaste = verantwoordelijkewaste;
            this.VerantwoordelijkeDO = verantwoordelijkedo;
            this.DatumAanvraag = datumaanvraag;
            this.DatumWaste = datumwaste;
            this.DatumDO = datumdo;
            this.Logs = logs;
            this._products = products;
        }

        public string TicketType { get { return _tickettype; } set { _tickettype = value; } }
        public List<Product> Products { get { return _products; } set { _products = value; } }
    }
}
