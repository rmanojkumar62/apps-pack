﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement
{
    public class WasteDisposalTicket : Ticket
    {
        private string _productid;
        private string _product;
        private string _productomschrijving;
        private string _locatieafvalvaten;
        private string _aantalpaletten;
        private string _aantalvaten;
        private string _volumeid;
        private string _volume;
        private string _ecid;
        private string _ec;
        private string _sapid;
        private string _sap;
        private string _indaverid;
        private string _indaverreferentie;
        private string _unid;
        private string _un;
        private string _adrid;
        private string _adr;
        private string _adr_pics;
        private string _locatieafvalparking;
        private string _palletnummer;

        public WasteDisposalTicket() { }

        public WasteDisposalTicket(int attachmentcount, int id, string status,string ticketid,string ticketnumber, string ticket, string afdelingid, string afdeling, 
            string productid, string product, string productomschrijving, string locatieafvalvaten, string aantalpaletten, 
            string aantalvaten, string volumeid, string volume, string ecid, string ec, string sapid, string sap, string indaverid, 
            string indaverref, string unid, string un, string adrid, string adr, string adr_pics, string locatieafvalparking,
            string palletnummer, string opmerkingproducent, string opmerkingwaste, string opmerkingdo, 
            string verantwoordelijkeproducent, string verantwoordelijkewaste, string verantwoordelijkedo,
            DateTime datumaanvraag, DateTime datumwaste, DateTime datumdo, List<ChangeLog> logs)
        {
            this.AttachmentCount = attachmentcount;
            this.ID = id;
            this.Status = status;
            this.TicketID = ticketid;
            this.TicketNumber = ticketnumber;
            this.TicketName = ticket;
            this.AfdelingID = afdelingid;
            this.Afdeling = afdeling;
            this._productid = productid;
            this._product = product;
            this._productomschrijving = productomschrijving;
            this._locatieafvalvaten = locatieafvalvaten;
            this._aantalpaletten = aantalpaletten;
            this._aantalvaten = aantalvaten;
            this._volumeid = volumeid;
            this._volume = volume;
            this._ecid = ecid;
            this._ec = ec;
            this._sapid = sapid;
            this._sap = sap;
            this._indaverid = indaverid;
            this._indaverreferentie = indaverref;
            this._unid = unid;
            this._un = un;
            this._adrid = adrid;
            this._adr = adr;
            this._adr_pics = adr_pics;
            this._locatieafvalparking = locatieafvalparking;
            this._palletnummer = palletnummer;
            this.OpmerkingProducent = opmerkingproducent;
            this.OpmerkingWaste = opmerkingwaste;
            this.OpmerkingDO = opmerkingdo;
            this.VerantwoordelijkeProducent = verantwoordelijkeproducent;
            this.VerantwoordelijkeWaste = verantwoordelijkewaste;
            this.VerantwoordelijkeDO = verantwoordelijkedo;
            this.DatumAanvraag = datumaanvraag;
            this.DatumWaste = datumwaste;
            this.DatumDO = datumdo;
            this.Logs = logs;
        }

        public string ProductID { get { return _productid; } set { _productid = value; } }
        public string Product { get { return _product; } set { _product = value; } }
        public string ProductOmschrijving { get { return _productomschrijving; } set { _productomschrijving = value; } }
        public string LocatieAfvalvaten { get { return _locatieafvalvaten; } set { _locatieafvalvaten = value; } }
        public string AantalPaletten { get { return _aantalpaletten; } set { _aantalpaletten = value; } }
        public string AantalVaten { get { return _aantalvaten; } set { _aantalvaten = value; } }
        public string VolumeID { get { return _volumeid; } set { _volumeid = value; } }
        public string Volume { get { return _volume; } set { _volume = value; } }
        public string ECID { get { return _ecid; } set { _ecid = value; } }
        public string EC { get { return _ec; } set { _ec = value; } }
        public string SAPID { get { return _sapid; } set { _sapid = value; } }
        public string SAP { get { return _sap; } set { _sap = value; } }
        public string IndaverID { get { return _indaverid; } set { _indaverid = value; } }
        public string IndaverReferentie { get { return _indaverreferentie; } set { _indaverreferentie = value; } }
        public string UNID { get { return _unid; } set { _unid = value; } }
        public string UN
        {
            get
            {
                if (ADR == "Niet van toepassing")
                    return "Niet van toepassing";
                else
                    return _un;
            }
            set { _un = value; }
        }
        public string ADRID { get { return _adrid; } set { _adrid = value; } }
        public string ADR
        {
            get
            {
                if (string.IsNullOrEmpty(_adr))
                    return "Niet van toepassing";
                else
                    return _adr;
            }
            set { _adr = value; }
        }
        public string ADR_Pics
        {
            get { 
                if(string.IsNullOrEmpty(_adr_pics)||!_adr_pics.Contains("img"))
                    return string.Empty;
                else
                    return _adr_pics;
            }
            set { _adr_pics = value; }
        }
        public string LocatieAfvalparking { get { return _locatieafvalparking; } set { _locatieafvalparking = value; } }

        public string PalletNummer { get { return _palletnummer; } set { _palletnummer = value; } }

        public List<string> MailValues(string requeststype)
        {
            return new List<string> { Status, GetTicketLink(requeststype),GetTicketLinkDisplay(requeststype), Afdeling, Product, LocatieAfvalvaten, AantalPaletten, AantalVaten, Volume, EC, SAP, IndaverReferentie, ADR, UN };
        }

        public string GetSmallADR_Pics(string adr_pics)
        {
            return adr_pics.Replace("500px", "100%").Replace("80", "40");
        }
    }
}
