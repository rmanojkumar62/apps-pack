﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement
{
    [Serializable]
    public class Attachment
    {
        private string _filename;
        private byte[] _filecontent;
        private double _size;
        private string _status;
        private string _url;

        public Attachment() { }

        public Attachment(string filename, byte[] filecontent, double size, string status)
        {
            this._filename = filename;
            this._filecontent = filecontent;
            this._size = size;
            this._status = status;
        }
        public Attachment(string filename, byte[] filecontent, double size, string status, string url)
        {
            this._filename = filename;
            this._filecontent = filecontent;
            this._size = size;
            this._status = status;
            this._url = url;
        }

        public string FileName
        {
            get
            {
                return _filename;
            }
            set { _filename = value; }
        }
        public byte[] FileContent
        {
            get
            {
                return _filecontent;
            }
            set { _filecontent = value; }
        }
        public double FileSize
        {
            get
            {
                if (_size / 1024 / 1024 < 0.01)
                    return Math.Round(_size / 1024, 2);
                else
                    return Math.Round(_size / 1024 / 1024, 2);
            }
            set { _size = value; }
        }
        public string FileSizeString
        {
            get
            {
                if (_size / 1024 / 1024 < 0.01) 
                    return string.Concat(FileSize, "KB"); 
                else 
                    return string.Concat(FileSize, "MB");
            }
        }
        public string FileStatus
        {
            get
            {
                return _status;
            }
            set { _status = value; }
        }
        public string FileURL
        {
            get
            {
                return _url;
            }
            set { _url = value; }
        }
    }
}
