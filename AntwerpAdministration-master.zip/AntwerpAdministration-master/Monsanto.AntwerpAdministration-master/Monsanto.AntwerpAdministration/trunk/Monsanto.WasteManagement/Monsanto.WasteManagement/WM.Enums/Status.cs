﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.WasteManagement.WM.Enums
{
    public enum Status
    {
        Geïnitieerd,
        LabelsAfhaling,
        In_Behandeling,
        Afgewerkt,
        Uitgeschreven,
        Terug_Naar_Producent,
        Directe_Belading,
        Empty
    }
}
