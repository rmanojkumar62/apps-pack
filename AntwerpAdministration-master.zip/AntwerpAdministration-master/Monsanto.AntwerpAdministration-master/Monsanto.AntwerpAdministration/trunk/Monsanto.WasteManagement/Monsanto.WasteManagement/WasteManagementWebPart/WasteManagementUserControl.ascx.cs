﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.Web.UI.HtmlControls;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;
using System.Collections;
using System.Web;
using System.IO;
using System.Text;
using Monsanto.WasteManagement.ControlTemplates.Monsanto.WasteManagement;
using Monsanto.WasteManagement.ControlTemplates;
using Monsanto.WasteManagement.WM.Enums;
using Microsoft.SharePoint.Utilities;

namespace Monsanto.WasteManagement.WasteManagementWebPart
{
    public partial class WasteManagementUserControl : UserControl
    {
        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            try
            {
                base.OnLoad(e);
                if (!IsPostBack)
                {
                    if (!string.IsNullOrEmpty(Request.QueryString["REQUESTTYPE"]))
                    {
                        RequestType rqt = Utilities.GetRequestType(Request.QueryString["REQUESTTYPE"]);
                        LoadUserControl(rqt);
                    }
                }
            }
            catch (Exception ex) { }
        }
        
        private void LoadUserControl(RequestType requesttype)
        {
            TicketControl tc = (TicketControl)ticketCtrl;
            tc.SetRequestType(requesttype);
            if (!string.IsNullOrEmpty(Request.QueryString["FORM"]))
            {
                switch (Request.QueryString["FORM"])
                {
                    case "new":
                        if (requesttype == RequestType.ERT)
                        {
                            pnlSelectie.Visible = true;
                            pnlConfirmationWrapper.Visible = false;
                            ticketCtrl.Visible = false;
                        }
                        else
                        {
                            tc.LoadForm(SPControlMode.New, requesttype);
                            tc.Visible = true;
                        }
                        break;
                    case "edit":
                        if (string.IsNullOrEmpty(Request.QueryString["ITEMID"]))
                            RedirectToURL(Request.Url.ToString().Replace("edit", "new"));
                        else
                        {
                            tc.LoadForm(SPControlMode.Edit, requesttype, Request.QueryString["ITEMID"]);
                            tc.Visible = true;
                        }
                        break;
                    case "display":
                        if (string.IsNullOrEmpty(Request.QueryString["ITEMID"]))
                            RedirectToURL(Request.Url.ToString().Replace("display", "new"));
                        else
                        {
                            tc.LoadForm(SPControlMode.Display, requesttype, Request.QueryString["ITEMID"]);
                            tc.Visible = true;
                        }
                        break;
                }
            }
            else
            {
                string URL = Request.Url.ToString().Split('?')[0];
                if (Convert.ToInt32(Request.QueryString["ITEMID"]) > 0)
                    RedirectToURL(string.Concat(URL, "?REQUESTTYPE=", requesttype, "&FORM=display&ITEMID=", Request.QueryString["ITEMID"]));
                else
                    RedirectToURL(string.Concat(URL, "?REQUESTTYPE=", requesttype, "&FORM=new&ITEMID=-1"));
            }
        }
        
        public void Page_Load(object sender, EventArgs e) 
        {
            ((TicketControl)ticketCtrl).wmuc = this;
            wastedisposalheaderimg.Src = Constants.Config[Constants.Header_Image];
            wastedisposalheaderimg.Alt = "WM";
            wastedisposalheader.InnerText= Constants.Config[Constants.Header_Text];
            ERT_header.InnerText = Constants.Config[Constants.ERT_header];
            ERT_gereinigd_header.InnerText = Constants.Config[Constants.ERT_gereinigd_header];
            ERT_ongereinigd_header.InnerText = Constants.Config[Constants.ERT_ongereinigd_header];
            ERT_gereinigd_title.InnerText = Constants.Config[Constants.ERT_gereinigd_title];
            ERT_ongereinigd_title.InnerText = Constants.Config[Constants.ERT_ongereinigd_title];
            ERT_gereinigd_list.InnerHtml = Constants.Config[Constants.ERT_gereinigd_ListItems];
            ERT_ongereinigd_list.InnerHtml = Constants.Config[Constants.ERT_ongereinigd_ListItems];
            btnGereinigd_text.InnerHtml = Constants.Config[Constants.Button_Gereinigd];
            btnOngereinigd_text.InnerHtml = Constants.Config[Constants.Button_Ongereinigd];
        }

        protected void btnGereinigd_Click(object sender, EventArgs e)
        {
            TicketControl tc = (TicketControl)ticketCtrl;
            tc.SetERTType(ERT_Type.Gereinigd);
            tc.LoadForm(SPControlMode.New, RequestType.ERT);
            tc.Visible = true;
            pnlSelectie.Visible = false;
            pnlConfirmationWrapper.Visible = false;
        }

        protected void btnOngereinigd_Click(object sender, EventArgs e)
        {
            TicketControl tc = (TicketControl)ticketCtrl;
            tc.SetERTType(ERT_Type.Ongereinigd);
            tc.LoadForm(SPControlMode.New, RequestType.ERT);
            tc.Visible = true;
            pnlSelectie.Visible = false;
            pnlConfirmationWrapper.Visible = false;
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            RedirectToURL(SPContext.Current.Web.Url);
        }

        public void ShowConfirmation(ButtonAction action, string button)
        {
            string message = string.Empty;
            switch (action)
            {
                case ButtonAction.Submit:
                    if (button.Equals(Constants.Config[Constants.Button_AanvraagVerzenden]))
                        message = Constants.Config[Constants.Message_Confirmation_Aanvraagverzenden];
                    if (button.Equals(Constants.Config[Constants.Button_StuurDO]))
                        message = Constants.Config[Constants.Message_Confirmation_StuurDO];
                    if (button.Equals(Constants.Config[Constants.Button_Afgewerkt]))
                        message = Constants.Config[Constants.Message_Confirmation_Afgewerkt];
                    if (button.Equals(Constants.Config[Constants.Button_Afsluiten]))
                        message = Constants.Config[Constants.Message_Confirmation_Afsluiten];
                    break;
                case ButtonAction.Save:
                    message = Constants.Config[Constants.Message_Confirmation_Save];
                    break;
                case ButtonAction.Return:
                    if (button.Equals("Waste"))
                        message = Constants.Config[Constants.Message_Confirmation_Producent];
                    if (button.Equals("DO"))
                        message = Constants.Config[Constants.Message_Confirmation_Waste];
                    break;
            }
            lblConfirmationMessage.Text = message;
            btnCloseConfirmation_text.InnerHtml = Constants.Config[Constants.Button_ConfirmationClose];
            ticketCtrl.Visible = false;
            pnlSelectie.Visible = false;
            pnlConfirmationWrapper.Visible = true;
        }

        public void RedirectToURL(string url)
        {
            Response.Redirect(url, false);
            Context.ApplicationInstance.CompleteRequest();
        }
    }
}