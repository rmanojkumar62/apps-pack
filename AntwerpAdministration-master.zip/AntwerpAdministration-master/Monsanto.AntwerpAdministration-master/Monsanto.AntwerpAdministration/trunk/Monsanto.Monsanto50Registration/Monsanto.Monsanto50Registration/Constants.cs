﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Monsanto.Monsanto50
{
    public class Constants
    {
        public const string ConfigList = "Configuration";
        public const string Col_Title = "Title";
        public const string Col_Value = "Value";

        public const char SplitEmail = '.';

        public const string CompanyTrigger = "Monsanto Antwerp";
        public const string DepartmentTrigger = "Other";
        public const string PersonsTrigger = "2";
        public const string PresenceTrigger = "Niet aanwezig";

        public const string EndRequestMethod="RequestEnded();";
        public const string EndRequestMethodValidation = "RequestEndedValidation();";
        public const string EndRequestMethodNoSelection = "RequestEndedNoSelection();";

        public const string LinkedResourceType_PNG = "image/png";
        public const string LinkedResourceType_JPEG = "image/jpeg";

        public const string chkboxSelectAll = "chkboxSelectAll";
        public const string chkBxRegistrationItem = "chkBxRegistrationItem";

        public const string RegistrationList = "Registraties";

        #region REGISTRATION LIST COLUMNS
        public const string Registration_ID = "ID";
        public const string Registration_Status = "Status";
        public const string Registration_Firstname = "Firstname";
        public const string Registration_Lastname = "Lastname";
        public const string Registration_Mobile = "Mobile";
        public const string Registration_Email_Monsanto = "Email_Monsanto";
        public const string Registration_Email_Personal = "Email_Personal";
        public const string Registration_Email_Personal_Check = "Email_Personal_Check";
        public const string Registration_Company = "Company";
        public const string Registration_Department = "Department";
        public const string Registration_OtherDepartment = "Other_x0020_Department";
        public const string Registration_Presence = "Presence";
        public const string Registration_NumberPersons = "Number_x0020_persons";
        public const string Registration_FirstnamePartner = "Firstname_x0020_Partner";
        public const string Registration_LastnamePartner = "Lastname_x0020_Partner";
        public const string Registration_Specialties = "Specialties";
        public const string Registration_Barcode = "Barcode";
        #endregion

        public static Dictionary<string, string> _Config;
        public static Dictionary<string, string> Config
        {
            get
            {
                if (_Config == null)
                    _Config = Utilities.GetConfigValues();
                return _Config;
            }
        }

        private Constants() { }
    }

    public enum ErrorType
    {
        AlreadyExists,
        System
    }

    public enum MailTemplate
    {
        RegistrationMain,
        RegistrationAlternative,
        Contact
    }
}
