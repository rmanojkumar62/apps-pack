﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using System.IO;
using System.Web;
using System.Drawing.Imaging;
using System.Net.Mail;
using System.Reflection;

namespace Monsanto.Monsanto50
{
    public class Utilities
    {
        public static bool HasAdminPermission()
        {
            try
            {
                SPWeb currentWeb = SPContext.Current.Web;
                return currentWeb.UserIsWebAdmin || currentWeb.UserIsSiteAdmin || currentWeb.DoesUserHavePermissions(SPBasePermissions.FullMask);
            }
            catch (SPException ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}",MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return false;
        }

        public static bool HasContributePermission()
        {
            bool hasPermission = false;
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPWeb currentWeb = SPContext.Current.Web;
                    SPBasePermissions permMask = currentWeb.GetUserEffectivePermissions(SPContext.Current.Web.CurrentUser.LoginName);
                    hasPermission = (permMask & SPBasePermissions.EditListItems) != 0;
                }
            }
            catch (SPException ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return hasPermission;
        }

        public static string GetRandomBarcode()
        {
            Random random = new Random();
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 12; i++)
                sb.Append(random.Next(0, 9).ToString());
            return sb.ToString();
        }

        public static bool CheckRegistrationExists(string email_monsanto)
        {
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPQuery query = new SPQuery();
                    query.Query = string.Format(Constants.Config["CAMLRegistrationExists"], email_monsanto, Constants.Config["Monsanto50mailbox"]);
                    query.RowLimit = 1;
                    SPListItemCollection listitems = web.Lists.TryGetList(Constants.RegistrationList).GetItems(query);
                    if (listitems.Count > 0)
                        return true;
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return false;
        }

        public static List<string> GetRegisteredBarcodes()
        {
            List<string> barcodes = new List<string>();
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPListItemCollection items = web.Lists.TryGetList(Constants.RegistrationList).Items;
                    foreach (SPListItem item in items)
                    {
                        string barcode = Convert.ToString(item[Constants.Registration_Barcode]);
                        if (!string.IsNullOrEmpty(barcode))
                            barcodes.Add(barcode);
                    }
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return barcodes;
        }

        public static System.Drawing.Image RenderBarCode(string barcode)
        {
            BarcodeLib.TYPE type = BarcodeLib.TYPE.CODE128;
            BarcodeLib.Barcode b = new BarcodeLib.Barcode();
            b.IncludeLabel = true;
            b.Alignment = BarcodeLib.AlignmentPositions.CENTER;
            int imageHeight = 150;
            int imageWidth = 300;
            System.Drawing.Image barcodeImage = b.Encode(type, barcode, System.Drawing.Color.Black, System.Drawing.Color.White, imageWidth, imageHeight);
            return barcodeImage;
        }

        public static void SendMail(string firstname,string email_Monsanto, string email_Personal, bool checkPersonal, string barcode, int presenceSelection, int numberpeople)
        {
            MemoryStream barCodeStream = null;
            Stream filestream_audrey = null;
            Stream filestream_monsanto50 = null;
            Stream filestream_parking_NL = null;
            Stream filestream_parking_ENG = null;
            try
            {
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(Constants.Config["Monsanto50mailbox"]);
                if (!string.IsNullOrEmpty(email_Monsanto))
                    mailMessage.To.Add(new MailAddress(email_Monsanto));
                if (checkPersonal)
                    if (!string.IsNullOrEmpty(email_Personal))
                        mailMessage.To.Add(new MailAddress(email_Personal));
                if (mailMessage.To.Count == 0)
                    mailMessage.To.Add(new MailAddress(Constants.Config["SupportGroupEmail"]));
                if (Convert.ToBoolean(Constants.Config["TestPhase"]))
                    mailMessage.CC.Add(new MailAddress(Constants.Config["Monsanto50mailbox"]));
                switch (presenceSelection)
                {
                    case 0:
                        mailMessage.Subject = Constants.Config["Email_Subject_Registration"];
                        break;
                    case 1:
                    case 2:
                        mailMessage.Subject = Constants.Config["Email_Subject_Registration_Alternative"];
                        break;
                }
                //BAR CODE SECTION
                System.Drawing.Image barcodeImage = Utilities.RenderBarCode(barcode);
                barCodeStream = new MemoryStream();
                barcodeImage.Save(barCodeStream, ImageFormat.Jpeg);
                barCodeStream.Position = 0;
                //END BAR CODE SECTION
                SPFile file_audrey = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url,Constants.Config["MailTemplate_Path_Img_Audrey"]));
                SPFile file_monsanto50 = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url,Constants.Config["MailTemplate_Path_Img_Monsanto50"]));
                filestream_audrey = file_audrey.OpenBinaryStream();
                filestream_monsanto50 = file_monsanto50.OpenBinaryStream();
                string body = string.Empty;
                mailMessage.IsBodyHtml = true;
                body = Utilities.FillBody(firstname, presenceSelection, numberpeople);
                AlternateView objHTLMAltView = AlternateView.CreateAlternateViewFromString(body, new System.Net.Mime.ContentType("text/html"));
                if (barCodeStream != null)
                {
                    LinkedResource objLinkedRes_BarCode = new LinkedResource(barCodeStream, Constants.LinkedResourceType_JPEG);
                    objLinkedRes_BarCode.ContentId = "barcode-logo";
                    objHTLMAltView.LinkedResources.Add(objLinkedRes_BarCode);
                }
                if (filestream_audrey != null)
                {
                    LinkedResource objLinkedRes_AudreyLogo = new LinkedResource(filestream_audrey, Constants.LinkedResourceType_JPEG);
                    objLinkedRes_AudreyLogo.ContentId = "audrey-logo";
                    objHTLMAltView.LinkedResources.Add(objLinkedRes_AudreyLogo);
                }
                if (filestream_monsanto50 != null)
                {
                    LinkedResource objLinkedRes_Monsanto50Logo = new LinkedResource(filestream_monsanto50, Constants.LinkedResourceType_JPEG);
                    objLinkedRes_Monsanto50Logo.ContentId = "monsanto50-logo";
                    objHTLMAltView.LinkedResources.Add(objLinkedRes_Monsanto50Logo);
                }
                mailMessage.AlternateViews.Add(objHTLMAltView);
                switch (presenceSelection)
                {
                    case 0:
                        SPFile file_parking_NL = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url, Constants.Config["Event_Main_Path_Img_Parking_NL"]));
                        filestream_parking_NL = file_parking_NL.OpenBinaryStream();
                        mailMessage.Attachments.Add(new System.Net.Mail.Attachment(filestream_parking_NL, "Parking.png"));
                        if (!string.IsNullOrEmpty(Constants.Config["Event_Main_Path_Img_Parking_ENG"]))
                        {
                            SPFile file_parking_ENG = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url, Constants.Config["Event_Main_Path_Img_Parking_ENG"]));
                            filestream_parking_ENG = file_parking_ENG.OpenBinaryStream();
                            mailMessage.Attachments.Add(new System.Net.Mail.Attachment(filestream_parking_ENG, "Parking_ENG.png"));
                        }
                        break;
                    case 1:
                    case 2:
                        SPFile file_parking = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url, Constants.Config["Event_Alternative_Path_Img_Parking_NL"]));
                        filestream_parking_NL = file_parking.OpenBinaryStream();
                        mailMessage.Attachments.Add(new System.Net.Mail.Attachment(filestream_parking_NL, "Parking.png"));
                        break;
                }
                SmtpClient smtpClient = new SmtpClient(Constants.Config["OutboundSMTPServer"]);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            finally
            {
                if (barCodeStream != null)
                    barCodeStream.Close();
                if(filestream_audrey!=null)
                    filestream_audrey.Close();
                if(filestream_monsanto50!=null)
                    filestream_monsanto50.Close();
                if (filestream_parking_NL != null)
                    filestream_parking_NL.Close();
                if (filestream_parking_ENG != null)
                    filestream_parking_ENG.Close();
            }
        }

        public static string FillBody(string firstname, int presenceSelection, int numberpeople)
        {
            string body = string.Empty;
            MailTemplate mt;
            if (presenceSelection == 0)
                mt = MailTemplate.RegistrationMain;
            else
                mt = MailTemplate.RegistrationAlternative;
            body = GetMailTemplate(mt);
            switch (presenceSelection)
            {
                case 0:
                    body = body.Replace("{0}", UppercaseFirst(firstname));
                    body = body.Replace("{00}", UppercaseFirst(firstname));
                    body = body.Replace("{1}", numberpeople.ToString());
                    body = body.Replace("{11}", numberpeople.ToString());
                    if (numberpeople == 1)
                    {
                        body = body.Replace("{2}", "persoon");
                        body = body.Replace("{22}", "person");
                    }
                    else if (numberpeople == 2)
                    {
                        body = body.Replace("{2}", "personen");
                        body = body.Replace("{22}", "people");
                    }
                    body = body.Replace("{3}", Constants.Config["Event_Date_1_NL"]);
                    body = body.Replace("{33}", Constants.Config["Event_Date_1_ENG"]);
                    body = body.Replace("{4}", Constants.Config["Event_Address_1_NL"]);
                    body = body.Replace("{44}", Constants.Config["Event_Address_1_ENG"]);
                    body = body.Replace("{5}", Constants.Config["Event_Parking_1_NL"]);
                    body = body.Replace("{55}", Constants.Config["Event_Parking_1_ENG"]);
                    break;
                case 1:
                case 2:
                    body = body.Replace("{0}", UppercaseFirst(firstname));
                    body = body.Replace("{1}", numberpeople.ToString());
                    if (numberpeople == 1)
                        body = body.Replace("{2}", "persoon");
                    else if (numberpeople == 2)
                        body = body.Replace("{2}", "personen");
                    body = body.Replace("{3}", (presenceSelection == 1) ? Constants.Config["Event_Date_2_NL"] : Constants.Config["Event_Date_3_NL"]);
                    body = body.Replace("{4}", Constants.Config["Event_Address_2_NL"]);
                    body = body.Replace("{5}", Constants.Config["Event_Parking_2_NL"]);
                    break;
            }
            return body;
        }

        public static int GetPresenceSelection(string presence)
        {
            switch (presence)
            {
                case "Zaterdag 21 Mei 2016":
                    return 0;
                case "Zaterdag 28 Mei 2016":
                    return 1;
                case "Zaterdag 11 Juni 2016":
                    return 2;
                case "Niet aanwezig":
                    return 3;
                default:
                    return -1;
            }
        }

        public static Dictionary<string, string> GetConfigValues()
        {
            Dictionary<string, string> configValues = new Dictionary<string, string>();
            try
            {
                SPList config = SPContext.Current.Web.Lists.TryGetList(Constants.ConfigList);
                foreach (SPListItem item in config.GetItems())
                    if (!configValues.ContainsKey(Convert.ToString(item[Constants.Col_Title])))
                        configValues.Add(Convert.ToString(item[Constants.Col_Title]), Convert.ToString(item[Constants.Col_Value]));
            }
            catch (Exception ex) {}
            return configValues;
        }

        public static string GetMailTemplate(MailTemplate mailtemplate)
        {
            string body = string.Empty;
            string mailtemplatepath = string.Empty;
            try
            {
                switch (mailtemplate)
                {
                    case MailTemplate.RegistrationMain:
                        mailtemplatepath = string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Main"]);
                        break;
                    case MailTemplate.RegistrationAlternative:
                        mailtemplatepath = string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Alternative"]);
                        break;
                    case MailTemplate.Contact:
                        mailtemplatepath = string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Contact"]);
                        break;
                }
                SPFile file = SPContext.Current.Web.GetFile(mailtemplatepath);
                using (Stream filestream = file.OpenBinaryStream())
                {
                    using (StreamReader reader = new StreamReader(filestream))
                    {
                        body = reader.ReadToEnd();
                    }
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return body;
        }

        public static string UppercaseFirst(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            return char.ToUpper(s[0]) + s.Substring(1);
        }
    }
}