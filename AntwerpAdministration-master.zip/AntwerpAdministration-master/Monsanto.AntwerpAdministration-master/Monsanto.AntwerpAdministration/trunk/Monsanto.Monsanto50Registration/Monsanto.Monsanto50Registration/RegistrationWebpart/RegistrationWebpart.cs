﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Monsanto.Monsanto50.RegistrationWebpart
{
    [ToolboxItemAttribute(false)]
    public class RegistrationWebpart : WebPart
    {
        // Visual Studio might automatically update this path when you change the Visual Web Part project item.
        private const string _ascxPath = @"~/_CONTROLTEMPLATES/Monsanto.Monsanto50/RegistrationWebpart/RegistrationWebpartUserControl.ascx";

        protected override void CreateChildControls()
        {
            Control control = Page.LoadControl(_ascxPath);
            if (control != null)
            {
                ((RegistrationWebpartUserControl)control).Webpart = this;
            }
            Controls.Add(control);
        }
    }
}
