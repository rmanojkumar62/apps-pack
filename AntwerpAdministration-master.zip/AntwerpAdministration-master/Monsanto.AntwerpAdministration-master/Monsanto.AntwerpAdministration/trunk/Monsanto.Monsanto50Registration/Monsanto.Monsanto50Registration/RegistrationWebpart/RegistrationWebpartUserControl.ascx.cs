﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Net.Mail;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Reflection;

namespace Monsanto.Monsanto50.RegistrationWebpart
{
    public partial class RegistrationWebpartUserControl : UserControl
    {
        public RegistrationWebpart Webpart;

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            btnRegister.OnClientClick = "javascript:RequestSubmitStarted();";
            if (!IsPostBack)
            {
                Constants._Config = null;
                if (!string.IsNullOrEmpty(SPContext.Current.Web.CurrentUser.Email))
                    txtEmail_Monsanto.Text = SPContext.Current.Web.CurrentUser.Email;
                else
                    txtEmail_Monsanto.Text = "michael@netlease.be";
            }
            if (Utilities.HasAdminPermission() || Utilities.HasContributePermission())
            {
                txtEmail_Monsanto.Enabled = true;
                row_create_blank.Visible = true;
            }
            else
                txtEmail_Monsanto.Enabled = false;
            gold_circle_img_form.Src = Constants.Config["IMG_GoldCircle"];
            gold_circle_img_formSummary.Src = Constants.Config["IMG_GoldCircle"];
            gold_circle_img_confirm.Src = Constants.Config["IMG_GoldCircle"];
            gold_circle_img_error.Src = Constants.Config["IMG_GoldCircle"];
        }

        protected void checkCreateBlank_Changed(object sender, EventArgs e)
        {
            if (checkCreateBlank.Checked)
                txtEmail_Monsanto.Text = Constants.Config["Monsanto50mailbox"];
            else
                txtEmail_Monsanto.Text = string.Empty;
        }

        protected void checkPersonalEmail_Changed(object sender, EventArgs e)
        {
            if (checkPersonalEmail.Checked)
                rowPersonalEmail.Visible = true;
            else
                rowPersonalEmail.Visible = false;
        }

        protected void radioCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radioCompany.SelectedValue.Equals(Constants.CompanyTrigger))
            {
                rowDepartment.Visible = true;
                radioPresence.Items[1].Enabled = true;
                radioPresence.Items[2].Enabled = true;
                if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                    rowOtherDepartment.Visible = true;
            }
            else
            {
                rowDepartment.Visible = false;
                rowOtherDepartment.Visible = false;
                dropDepartment.SelectedIndex = -1;
                radioPresence.Items[1].Selected = false;
                radioPresence.Items[2].Selected = false;
                radioPresence.Items[1].Enabled = false;
                radioPresence.Items[2].Enabled = false;
            }
        }
        
        protected void dropDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                rowOtherDepartment.Visible = true;
            else
            {
                rowOtherDepartment.Visible = false;
                txtDepartment.Text = string.Empty;
            }
        }
        
        protected void dropPersons_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropPersons.SelectedValue.Equals(Constants.PersonsTrigger))
            {
                rowPartnerFirstDetails.Visible = true;
                rowPartnerLastDetails.Visible = true;
            }
            else
            {
                rowPartnerFirstDetails.Visible = false;
                rowPartnerLastDetails.Visible = false;
                txtFirstNamePartner.Text = string.Empty;
                txtLastNamePartner.Text = string.Empty;
            }
        }

        protected void radioPresence_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radioPresence.SelectedValue.Equals(Constants.PresenceTrigger))
            {
                dropPersons.Enabled = false;
                checkSpecialties.Enabled = false;
                rowNumberPeople.Visible = false;
                rowSpecialties.Visible = false;
                rowSpecialtiesInfo.Visible = false;
                rowPartnerFirstDetails.Visible = false;
                rowPartnerLastDetails.Visible = false;
                txtFirstNamePartner.Text = string.Empty;
                txtLastNamePartner.Text = string.Empty;
            }
            else
            {
                dropPersons.Enabled = true;
                checkSpecialties.Enabled = true;
                rowNumberPeople.Visible = true;
                rowSpecialties.Visible = true;
                rowSpecialtiesInfo.Visible = true;
                if (dropPersons.SelectedValue.Equals(Constants.PersonsTrigger))
                {
                    rowPartnerFirstDetails.Visible = true;
                    rowPartnerLastDetails.Visible = true;
                }
            }
        }
        
        protected void btnNext_Click(object sender, EventArgs e)
        {
            ResetFormFieldLabels();
            if (CheckFormFields())
            {
                CopyToValueLabels();
                pnlRegistrationFormWrapper.Visible = false;
                pnlRegistrationSummaryWrapper.Visible = true;
                pnlConfirmation.Visible = false;
                pnlError.Visible = false;
            }
            else
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethodValidation, true);
            }
        }
        
        protected void btnBack_Click(object sender, EventArgs e)
        {
            pnlRegistrationFormWrapper.Visible = true;
            pnlRegistrationSummaryWrapper.Visible = false;
            pnlConfirmation.Visible = false;
            pnlError.Visible = false;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethod, true);
        }
        
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string email_Monsanto = this.lbl_Summary_Email_Monsanto_Value.Text;
            if (Utilities.CheckRegistrationExists(email_Monsanto))
            {
                ShowErrorPanel(ErrorType.AlreadyExists);
            }
            else
            {
                int presenceSelection = Convert.ToInt32(hidden_Presence_Selection.Value);
                if (presenceSelection >= 0 && presenceSelection < 3)
                {
                    List<string> barcodes = Utilities.GetRegisteredBarcodes();
                    string barcode = Utilities.GetRandomBarcode();
                    while (barcodes.Contains(barcode))
                    {
                        barcode = Utilities.GetRandomBarcode();
                    }
                    int requestID = SaveRegistration(barcode);
                    Utilities.SendMail(this.txtFirstName.Text,email_Monsanto, this.lbl_Summary_Email_Personal_Value.Text, this.check_Summary_Email_PersonalCheck_Value.Checked, 
                        barcode, presenceSelection,Convert.ToInt32(this.lbl_Summary_Persons_Value.Text));
                }
                else
                {
                    int requestID = SaveRegistration(string.Empty);
                }
                ShowConfirmationPanel(presenceSelection);
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethod, true);
        }
        
        protected void btnClose_Click(object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url, false);
        }

        private int SaveRegistration(string barcode)
        {
            int requestID=-1;
            try
            {
                using (SPSite siteCollection = new SPSite(SPContext.Current.Site.ID, SPContext.Current.Site.SystemAccount.UserToken))
                using (SPWeb web = siteCollection.OpenWeb(SPContext.Current.Web.ID))
                {
                    SPList list = web.Lists.TryGetList(Constants.RegistrationList);
                    SPListItem registration = list.Items.Add();
                    registration.Update();
                    registration[Constants.Registration_Firstname] = this.lbl_Summary_FirstName_Value.Text;
                    registration[Constants.Registration_Lastname] = this.lbl_Summary_LastName_Value.Text;
                    registration[Constants.Registration_Mobile] = this.lbl_Summary_Mobile_Value.Text;
                    registration[Constants.Registration_Email_Monsanto] = this.lbl_Summary_Email_Monsanto_Value.Text;
                    registration[Constants.Registration_Email_Personal] = this.lbl_Summary_Email_Personal_Value.Text;
                    registration[Constants.Registration_Email_Personal_Check] = this.check_Summary_Email_PersonalCheck_Value.Checked;
                    registration[Constants.Registration_Company] = this.lbl_Summary_Company_Value.Text;
                    registration[Constants.Registration_Department] = this.lbl_Summary_Department_Value.Text;
                    registration[Constants.Registration_OtherDepartment] = this.lbl_Summary_OtherDepartment_Value.Text;
                    registration[Constants.Registration_Presence] = this.lbl_Summary_Presence_Value.Text;
                    if(!string.IsNullOrEmpty(this.lbl_Summary_Persons_Value.Text))
                        registration[Constants.Registration_NumberPersons] = Convert.ToInt32(this.lbl_Summary_Persons_Value.Text);
                    registration[Constants.Registration_FirstnamePartner] = this.lbl_Summary_PartnerFirst_Value.Text;
                    registration[Constants.Registration_LastnamePartner] = this.lbl_Summary_PartnerLast_Value.Text;
                    SPFieldMultiChoiceValue specialtyValues = new SPFieldMultiChoiceValue();
                    foreach (ListItem item in check_Summary_Specialties_Value.Items)
                    {
                        if (item.Selected)
                        {
                            specialtyValues.Add(item.Value);
                        }
                    }
                    registration[Constants.Registration_Specialties] = specialtyValues.ToString();
                    registration[Constants.Registration_Barcode] = barcode;
                    registration[Constants.Registration_Status] = "Registered";
                    registration.Update();
                    requestID = registration.ID;
                }
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            return requestID;
        }
        
        private void CopyToValueLabels()
        {
            row_Summary_PersonalEmail.Visible = false;
            row_Summary_Department.Visible = false;
            row_Summary_OtherDepartment.Visible = false;
            row_Summary_PartnerFirst.Visible = false;
            row_Summary_PartnerLast.Visible = false;
            row_Summary_Specialties.Visible = false;
            if (Utilities.HasAdminPermission() || Utilities.HasContributePermission())
                row_create_blank_summary.Visible = true;
            checkCreateBlank_Summary.Checked = checkCreateBlank.Checked;
            lbl_Summary_FirstName_Value.Text = txtFirstName.Text;
            lbl_Summary_LastName_Value.Text = txtLastName.Text;
            lbl_Summary_Mobile_Value.Text = txtMobile.Text;
            lbl_Summary_Email_Monsanto_Value.Text = txtEmail_Monsanto.Text;
            check_Summary_Email_PersonalCheck_Value.Checked = checkPersonalEmail.Checked;
            if (check_Summary_Email_PersonalCheck_Value.Checked)
            {
                row_Summary_PersonalEmail.Visible = true;
                lbl_Summary_Email_Personal_Value.Text = txtEmail_Personal.Text;
            }
            lbl_Summary_Company_Value.Text = radioCompany.SelectedValue;
            if (radioCompany.SelectedValue.Equals(Constants.CompanyTrigger))
            {
                row_Summary_Department.Visible = true;
                lbl_Summary_Department_Value.Text = dropDepartment.SelectedValue;
                if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                {
                    lbl_Summary_OtherDepartment_Value.Text = txtDepartment.Text;
                    row_Summary_OtherDepartment.Visible = true;
                }
            }
            lbl_Summary_Presence_Value.Text = radioPresence.SelectedValue;
            hidden_Presence_Selection.Value = Convert.ToString(radioPresence.SelectedIndex);
            if (radioPresence.SelectedValue.Equals(Constants.PresenceTrigger))
                lbl_Summary_Persons_Value.Text = "0";
            else
                lbl_Summary_Persons_Value.Text = dropPersons.SelectedValue;
            if (!radioPresence.SelectedValue.Equals(Constants.PresenceTrigger))
            {
                row_Summary_Specialties.Visible = true;
                if (dropPersons.SelectedValue.Equals(Constants.PersonsTrigger))
                {
                    lbl_Summary_PartnerFirst_Value.Text = txtFirstNamePartner.Text;
                    lbl_Summary_PartnerLast_Value.Text = txtLastNamePartner.Text;
                    row_Summary_PartnerFirst.Visible = true;
                    row_Summary_PartnerLast.Visible = true;
                }
                foreach (ListItem item in checkSpecialties.Items)
                    if (item.Selected)
                        check_Summary_Specialties_Value.Items[checkSpecialties.Items.IndexOf(item)].Selected = true;
            }
        }

        private void ResetFormFieldLabels()
        {
            lblVoornaam.ForeColor = Color.Empty;
            lblFirstName.ForeColor = Color.Empty;
            lblNaam.ForeColor = Color.Empty;
            lblLastName.ForeColor = Color.Empty;
            lblGSM.ForeColor = Color.Empty;
            lblMobile.ForeColor = Color.Empty;
            lblEmail_Monsanto.ForeColor = Color.Empty;
            lblEmail_Personal_1.ForeColor = Color.Empty;
            lblEmail_Personal_2.ForeColor = Color.Empty;
            lblBedrijf.ForeColor = Color.Empty;
            lblCompany.ForeColor = Color.Empty;
            lblAfdeling.ForeColor = Color.Empty;
            lblDepartment.ForeColor = Color.Empty;
            lblAndereAfdeling.ForeColor = Color.Empty;
            lblOtherDepartment.ForeColor = Color.Empty;
            lblAanwezigheid.ForeColor = Color.Empty;
            lblPresence.ForeColor = Color.Empty;
            lblVoornaamPartner.ForeColor = Color.Empty;
            lblFirstNamePartner.ForeColor = Color.Empty;
            lblNaamPartner.ForeColor = Color.Empty;
            lblLastNamePartner.ForeColor = Color.Empty;
        }

        private bool CheckFormFields()
        {
            bool isOK = true;
            if (string.IsNullOrEmpty(txtFirstName.Text))
            {
                isOK = false;
                lblVoornaam.ForeColor = Color.Red;
                lblFirstName.ForeColor = Color.Red;
            }
            if (string.IsNullOrEmpty(txtLastName.Text))
            {
                isOK = false;
                lblNaam.ForeColor = Color.Red;
                lblLastName.ForeColor = Color.Red;
            }
            if (string.IsNullOrEmpty(txtEmail_Monsanto.Text))
            {
                isOK = false;
                lblEmail_Monsanto.ForeColor = Color.Red;
            }
            else
            {
                string email = txtEmail_Monsanto.Text;
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match = regex.Match(email);
                if (!match.Success)
                {
                    isOK = false;
                    txtEmail_Monsanto.ForeColor = Color.Red;
                }
            }
            if (checkPersonalEmail.Checked)
            {
                if (string.IsNullOrEmpty(txtEmail_Personal.Text))
                {
                    isOK = false;
                    lblEmail_Personal_1.ForeColor = Color.Red;
                    lblEmail_Personal_2.ForeColor = Color.Red;
                }
                else
                {
                    string email = txtEmail_Personal.Text;
                    Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                    Match match = regex.Match(email);
                    if (!match.Success)
                    {
                        isOK = false;
                        lblEmail_Personal_1.ForeColor = Color.Red;
                        lblEmail_Personal_2.ForeColor = Color.Red;
                    }
                }
            }
            if (radioCompany.SelectedIndex < 0)
            {
                isOK = false;
                lblBedrijf.ForeColor = Color.Red;
                lblCompany.ForeColor = Color.Red;
            }
            if (radioCompany.SelectedIndex == 0)
            {
                if (dropDepartment.SelectedIndex < 1)
                {
                    isOK = false;
                    lblAfdeling.ForeColor = Color.Red;
                    lblDepartment.ForeColor = Color.Red;
                }
                if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                {
                    if (string.IsNullOrEmpty(txtDepartment.Text))
                    {
                        isOK = false;
                        lblAndereAfdeling.ForeColor = Color.Red;
                        lblOtherDepartment.ForeColor = Color.Red;
                    }
                }
            }
            if (radioPresence.SelectedIndex < 0)
            {
                isOK = false;
                lblAanwezigheid.ForeColor = Color.Red;
                lblPresence.ForeColor = Color.Red;
            }
            if (radioPresence.SelectedIndex < 3)
            {
                if (dropPersons.SelectedIndex == 1)
                {
                    if (string.IsNullOrEmpty(txtFirstNamePartner.Text))
                    {
                        isOK = false;
                        lblVoornaamPartner.ForeColor = Color.Red;
                        lblFirstNamePartner.ForeColor = Color.Red;
                    }
                    if (string.IsNullOrEmpty(txtLastNamePartner.Text))
                    {
                        isOK = false;
                        lblNaamPartner.ForeColor = Color.Red;
                        lblLastNamePartner.ForeColor = Color.Red;
                    }
                }
            }
            return isOK;
        }

        private void ShowConfirmationPanel(int presenceSelection)
        {
            switch (presenceSelection)
            {
                case 0:
                    confirmationcontent_NL.InnerHtml = "U zal binnenkort een e-mail ontvangen van het registratie platform.<br />" +
                                            "(als je de e-mail niet ziet in je inbox, gelieve dan na te gaan of deze in de map ongewenst staat)<br /><br />" +
                                            "De e-mail bevat uw persoonlijk toegangsticket.<br /><br />" +
                                            "<b>Zorg ervoor dat je zeker uw ticket bij hebt op de dag van het geselecteerde event zelf</b>,<br />" +
                                            "op deze manier kunnen we de wachtrij aan de ingang beperken.";
                    confirmationcontent_ENG.InnerHtml="You'll receive an e-mail from the registration platform shortly.<br />"+
                                            "(if you don't receive an e-mail, please check your spam folder)<br /><br />"+
                                            "In this e-mail you'll find your personal entrance ticket.<br /><br />"+
                                            "<b>Make sure you have your ticket with you on the day of the selected event</b>,<br />"+
                                            "this way we can reduce the waiting queue at the entrance.";
                    break;
                case 1:
                case 2:
                    confirmationcontent_NL.InnerHtml = "U zal binnenkort een e-mail ontvangen van het registratie platform.<br />" +
                                            "(als je de e-mail niet ziet in je inbox, gelieve dan na te gaan of deze in de map ongewenst staat)";
                    confirmationcontent_ENG.InnerHtml="You'll receive an e-mail from the registration platform shortly.<br />"+
                                            "(if you don't receive an e-mail please check your spam folder)";
                    break;
                case 3:
                    break;
            }
            pnlRegistrationFormWrapper.Visible = false;
            pnlRegistrationSummaryWrapper.Visible = false;
            pnlConfirmation.Visible = true;
            pnlError.Visible = false;
        }

        private void ShowErrorPanel(ErrorType type)
        {
            string errormessageNL=string.Empty, errormessageENG=string.Empty;
            switch (type)
            {
                case ErrorType.AlreadyExists:
                    errormessageNL = "U kan zich maar 1 keer registreren voor het event.";
                    errormessageENG = "You can submit only 1 registration for this event.";
                    break;
                case ErrorType.System:
                    errormessageNL = "Systeemfout";
                    errormessageENG = "System error";
                    break;
            }
            errorcontentNL.InnerText = errormessageNL;
            errorcontentENG.InnerText = errormessageENG;
            pnlError.Visible = true;
            pnlRegistrationFormWrapper.Visible = false;
            pnlRegistrationSummaryWrapper.Visible = false;
            pnlConfirmation.Visible = false;
        }
    }
}