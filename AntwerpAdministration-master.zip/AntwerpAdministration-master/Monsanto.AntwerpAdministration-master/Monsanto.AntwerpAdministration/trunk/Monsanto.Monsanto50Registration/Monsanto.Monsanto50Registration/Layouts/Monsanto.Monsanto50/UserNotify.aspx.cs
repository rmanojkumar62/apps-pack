﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Text;
using System.Collections.Generic;

namespace Monsanto.Monsanto50.Layouts.Monsanto.Monsanto50
{
    public partial class UserNotify : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                Constants._Config = null;
            if (Utilities.HasAdminPermission()||Utilities.HasContributePermission())
            {
                pnlNotifyUsersWrapper.Visible = true;
                try
                {
                    List<string> emails_monsanto = new List<string>();
                    List<string> emails_personal = new List<string>();
                    StringBuilder sb_monsanto = new StringBuilder();
                    StringBuilder sb_personal = new StringBuilder();
                    SPQuery query = new SPQuery();
                    query.Query = Constants.Config["CAMLUserNotify"];
                    SPListItemCollection items = SPContext.Current.Web.Lists[Constants.RegistrationList].GetItems(query);
                    foreach (SPListItem item in items)
                    {
                        string email_monsanto = Convert.ToString(item[Constants.Registration_Email_Monsanto]);
                        string email_personal = Convert.ToString(item[Constants.Registration_Email_Personal]);
                        if (!string.IsNullOrEmpty(email_monsanto))
                        {
                            if (!emails_monsanto.Contains(email_monsanto) && !email_monsanto.Equals(Constants.Config["Monsanto50mailbox"]))
                                emails_monsanto.Add(email_monsanto);
                        }
                        if (!string.IsNullOrEmpty(Convert.ToString(item[Constants.Registration_Email_Personal])))
                        {
                            if (!emails_personal.Contains(email_personal) && !email_monsanto.Equals(Constants.Config["Monsanto50mailbox"]))
                                emails_personal.Add(email_personal);
                        }
                    }
                    foreach (string email in emails_monsanto)
                    {
                        sb_monsanto.Append(email);
                        sb_monsanto.Append(";");
                    }
                    foreach (string email in emails_personal)
                    {
                        sb_personal.Append(email);
                        sb_personal.Append(";");
                    }
                    txtMonsanto.Text = sb_monsanto.ToString();
                    txtPersonal.Text = sb_personal.ToString();
                }
                catch (Exception ex) { }
            }
        }
    }
}
