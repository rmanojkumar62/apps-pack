﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Collections.Generic;
using System.Data;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using System.Collections;
using System.Web.UI;
using System.Linq;
using System.IO;
using System.Net.Mail;
using System.Drawing.Imaging;
using System.Reflection;

namespace Monsanto.Monsanto50.Layouts.Monsanto.Monsanto50
{
    public partial class ResendTicket : LayoutsPageBase
    {
        private char[] _sep = { ',' };
        private string[] _ssep = { "AND" };

        string FilterExpression
        {
            get
            {
                if (ViewState["FilterExpression"] == null)
                    ViewState["FilterExpression"] = "";
                return (string)ViewState["FilterExpression"];
            }
            set
            {
                string thisFilterExpression = "(" + value.ToString() + ")";
                List<string> fullFilterExpression = new List<string>();
                if (ViewState["FilterExpression"] != null)
                {
                    string[] fullFilterExp = ViewState["FilterExpression"].ToString().Split(_ssep, StringSplitOptions.RemoveEmptyEntries);
                    fullFilterExpression.AddRange(fullFilterExp);
                    int index = fullFilterExpression.FindIndex(s => s.Contains(thisFilterExpression));
                    if (index == -1)
                        fullFilterExpression.Add(thisFilterExpression);
                }
                else
                {
                    fullFilterExpression.Add(thisFilterExpression);
                }
                string filterExp = string.Empty;
                fullFilterExpression.ForEach(s => filterExp += s + " AND ");
                filterExp = filterExp.Remove(filterExp.LastIndexOf(" AND "));
                if (!filterExp.EndsWith("))") && filterExp.Contains("AND"))
                    filterExp = "(" + filterExp + ")";
                ViewState["FilterExpression"] = filterExp;
            }
        }

        string SortExpression
        {
            get
            {
                if (ViewState["SortExpression"] == null)
                    ViewState["SortExpression"] = "";
                return (string)ViewState["SortExpression"];
            }
            set
            {
                string[] thisSE = value.ToString().Split(' ');
                string thisSortExpression = thisSE[0];
                List<string> fullSortExpression = new List<string>();
                if (ViewState["SortExpression"] != null)
                {
                    string[] fullSortExp = ViewState["SortExpression"].ToString().Split(_sep);
                    fullSortExpression.AddRange(fullSortExp);
                    int index = fullSortExpression.FindIndex(s => s.Contains(thisSortExpression));
                    if (index >= 0)
                    {
                        string s = string.Empty;
                        if (value.ToString().Contains("DESC"))
                        { s = value.ToString(); }
                        else
                        {
                            s = fullSortExpression[index];
                            if (s.Contains("ASC"))
                                s = s.Replace("ASC", "DESC");
                            else
                                s = s.Replace("DESC", "ASC");
                        }
                        fullSortExpression[index] = s;
                    }
                    else
                    {
                        if (value.ToString().Contains("DESC"))
                            fullSortExpression.Add(value.ToString());
                        else
                            fullSortExpression.Add(thisSortExpression + " ASC");
                    }
                }
                else
                {
                    if (value.ToString().Contains("DESC"))
                        fullSortExpression.Add(value.ToString());
                    else
                        fullSortExpression.Add(thisSortExpression + " ASC");
                }
                string sortExp = string.Empty;
                fullSortExpression.ForEach(s => sortExp += s);
                sortExp = sortExp.Replace(" ASC", " ASC,");
                sortExp = sortExp.Replace(" DESC", " DESC,");
                ViewState["SortExpression"] = sortExp.Remove(sortExp.LastIndexOf(','));
            }
        }

        private List<int> ItemIDs
        {
            get
            {
                if (this.ViewState["ItemIDs"] == null)
                {
                    this.ViewState["ItemIDs"] = new List<int>();
                }
                return this.ViewState["ItemIDs"] as List<int>;
            }
        }

        private bool SelectAll
        {
            set
            {
                this.ViewState["SelectAll"] = value;
            }
            get
            {
                if (this.ViewState["SelectAll"] == null)
                {
                    this.ViewState["SelectAll"] = false;
                }
                return (bool)this.ViewState["SelectAll"];
            }
        }

        private string SortImage(DataControlField field)
        {
            string url = string.Empty;
            string[] fullSortExp = SortExpression.Split(_sep);
            List<string> fullSortExpression = new List<string>();
            fullSortExpression.AddRange(fullSortExp);
            int index = fullSortExpression.FindIndex(s => s.Contains(field.SortExpression));
            if (index >= 0)
            {
                string s = fullSortExpression[index];
                if (s.Contains("ASC"))
                { url = "_layouts/images/sortup.gif"; }
                else
                { url = "_layouts/images/sortdown.gif"; }
            }
            return url;
        }
                
        private PlaceHolder HeaderImages(DataControlField field, string imageUrl)
        {
            System.Web.UI.WebControls.Image filterIcon = new System.Web.UI.WebControls.Image();
            filterIcon.ImageUrl = imageUrl;
            filterIcon.Style[HtmlTextWriterStyle.MarginLeft] = "2px";
            Literal headerText = new Literal();
            headerText.Text = field.HeaderText;
            PlaceHolder panel = new PlaceHolder();
            panel.Controls.Add(headerText);
            if (FilterExpression.Contains(field.SortExpression) && SortExpression.Contains(field.SortExpression))
            {
                string url = SortImage(field);
                System.Web.UI.WebControls.Image sortIcon = new System.Web.UI.WebControls.Image();
                sortIcon.ImageUrl = url;
                sortIcon.Style[HtmlTextWriterStyle.MarginLeft] = "1px";
                panel.Controls.Add(sortIcon);
                filterIcon.Style[HtmlTextWriterStyle.MarginLeft] = "1px";
            }
            panel.Controls.Add(filterIcon);
            return panel;
        }
        
        private void BuildFilterView(string filterExp)
        {
            string lastExp = filterExp;
            if (lastExp.Contains("AND"))
            {
                if (lastExp.Length < lastExp.LastIndexOf("AND") + 4)
                    lastExp = lastExp.Substring(lastExp.LastIndexOf("AND") + 4);
                else
                    lastExp = string.Empty;
            }
            if (!string.IsNullOrEmpty(lastExp))
                FilterExpression = lastExp;
            if (!string.IsNullOrEmpty(FilterExpression))
                ODSRegistrations.FilterExpression = FilterExpression;
        }

        private void BindPaging()
        {
            gridRegistrationItems.PagerTemplate = null;
            gridRegistrationItems.PageIndexChanging += new GridViewPageEventHandler(gridRegistrationItems_PageIndexChanging);
        }

        private Dictionary<string, string> GetParameters(ObjectDataSourceMethodEventArgs e)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            foreach (DictionaryEntry entry in e.InputParameters)
            {
                string value = entry.Value == null ? null : entry.Value.ToString();
                data.Add(entry.Key.ToString(), value);
            }
            return data;
        }
        
        protected override void LoadViewState(object savedState)
        {
            base.LoadViewState(savedState);
            if (Context.Request.Form["__EVENTARGUMENT"] != null && Context.Request.Form["__EVENTARGUMENT"].Contains("__ClearFilter__"))
                ViewState.Remove("FilterExpression");
        }

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            try
            {
                BindPaging();
                ODSRegistrations.TypeName = typeof(RegistrationsToSharePoint).AssemblyQualifiedName;
                ODSRegistrations.ObjectCreating += new ObjectDataSourceObjectEventHandler(ODSRegistrations_ObjectCreating);
                ODSRegistrations.FilterExpression = FilterExpression;
            }
            catch (Exception ex) 
            {
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (!Page.IsPostBack)
                this.gridRegistrationItems.DataBind();
            BuildFilterView(ODSRegistrations.FilterExpression);
        }

        protected void Page_Load(object sender, EventArgs e) 
        {
            if (!IsPostBack)
                Constants._Config = null;
            if (Utilities.HasAdminPermission() || Utilities.HasContributePermission())
            {
                btnSend.OnClientClick = "javascript:RequestResendSubmit();";
                gold_circle_img_confirm.Src = Constants.Config["IMG_GoldCircle"];
                gold_circle_img_error.Src = Constants.Config["IMG_GoldCircle"];
                pnlMonsanto50.Visible = true;
            }
        }

        private void ODSRegistrations_ObjectCreating(object sender, ObjectDataSourceEventArgs e)
        {
            e.ObjectInstance = new RegistrationsToSharePoint();
        }

        protected void gridRegistrationItems_Sorting(object sender, GridViewSortEventArgs e)
        {
            string sDir = e.SortDirection.ToString();
            sDir = sDir == "Descending" ? " DESC" : "";
            SortExpression = e.SortExpression + sDir;
            e.SortExpression = SortExpression;
            if (!string.IsNullOrEmpty(FilterExpression))
                ODSRegistrations.FilterExpression = FilterExpression;
        }

        protected void gridRegistrationItems_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)gridRegistrationItems.HeaderRow.FindControl(Constants.chkboxSelectAll);
            ChkBoxHeader.Checked = this.SelectAll;
            foreach (GridViewRow gvr in gridRegistrationItems.Rows)
            {
                CheckBox chkSelect = (CheckBox)gvr.FindControl(Constants.chkBxRegistrationItem);
                if (chkSelect != null)
                {
                    int itemID = Convert.ToInt32(gridRegistrationItems.DataKeys[gvr.RowIndex][Constants.Registration_ID]);
                    if (chkSelect.Checked && !this.ItemIDs.Contains(itemID))
                    {
                        this.ItemIDs.Add(itemID);
                    }
                    else if (!chkSelect.Checked && this.ItemIDs.Contains(itemID))
                    {
                        this.ItemIDs.Remove(itemID);
                    }
                }
            }
        }

        protected void gridRegistrationItems_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            GridViewRow gvr = e.Row;
            if (gvr.RowType == DataControlRowType.DataRow)
            {
                CheckBox ChkBoxHeader = (CheckBox)gridRegistrationItems.HeaderRow.FindControl(Constants.chkboxSelectAll);
                ChkBoxHeader.Checked = this.SelectAll;
            }
            if (gvr.RowType == DataControlRowType.DataRow)
            {
                CheckBox chkSelect = (CheckBox)gvr.FindControl(Constants.chkBxRegistrationItem);
                if (chkSelect != null)
                {
                    int itemID = Convert.ToInt32(gridRegistrationItems.DataKeys[gvr.RowIndex][Constants.Registration_ID]);
                    chkSelect.Checked = this.ItemIDs.Contains(itemID);
                }
            }
        }

        protected void chkboxSelect_CheckedChanged(object sender, EventArgs e)
        {
            gridRegistrationItems.AllowPaging = false;
            gridRegistrationItems.DataBind();
            GridViewRow gvr = ((GridViewRow)((CheckBox)sender).NamingContainer);
            int index = gvr.RowIndex;
            CheckBox chkSelect = (CheckBox)gridRegistrationItems.Rows[index].FindControl(Constants.chkBxRegistrationItem);
            int itemID = Convert.ToInt32(gridRegistrationItems.DataKeys[gvr.RowIndex][Constants.Registration_ID]);
            if (chkSelect.Checked == false && !this.ItemIDs.Contains(itemID))
                this.ItemIDs.Add(itemID);
            else if (chkSelect.Checked == true && this.ItemIDs.Contains(itemID))
                this.ItemIDs.Remove(itemID);
            gridRegistrationItems.AllowPaging = true;
            gridRegistrationItems.DataBind();
        }

        protected void chkboxSelectAll_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox ChkBoxHeader = (CheckBox)gridRegistrationItems.HeaderRow.FindControl(Constants.chkboxSelectAll);
            gridRegistrationItems.AllowPaging = false;
            gridRegistrationItems.DataBind();
            if (ChkBoxHeader.Checked)
                this.SelectAll = true;
            else
                this.SelectAll = false;
            foreach (GridViewRow gvr in gridRegistrationItems.Rows)
            {
                CheckBox chkSelect = (CheckBox)gvr.FindControl(Constants.chkBxRegistrationItem);
                if (chkSelect != null)
                {
                    int itemID = Convert.ToInt32(gridRegistrationItems.DataKeys[gvr.RowIndex][Constants.Registration_ID]);

                    if (ChkBoxHeader.Checked == true)
                    {    
                        chkSelect.Checked = true;
                        if (!this.ItemIDs.Contains(itemID))
                            this.ItemIDs.Add(itemID);
                    }
                    else
                    {
                        chkSelect.Checked = false;
                        if (this.ItemIDs.Contains(itemID))
                            this.ItemIDs.Remove(itemID);
                    }
                }
            }
            gridRegistrationItems.AllowPaging = true;
            gridRegistrationItems.DataBind();
        }

        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            if (ViewState.Keys.Cast<string>().ToList().Contains("FilterExpression"))
            {
                ViewState.Remove("FilterExpression");
                this.ODSRegistrations.FilterExpression = string.Empty;
                this.gridRegistrationItems.Sort(string.Empty, SortDirection.Ascending);
                this.gridRegistrationItems.DataBind();
            }
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            bool isOK = false;
            try
            {
                gridRegistrationItems.AllowPaging = false;
                gridRegistrationItems.DataBind();
                foreach (GridViewRow row in gridRegistrationItems.Rows)
                {
                    if (((CheckBox)row.FindControl(Constants.chkBxRegistrationItem)).Checked)
                    {
                        isOK = true;
                        string registrationID = ((HiddenField)gridRegistrationItems.Rows[row.RowIndex].FindControl("HIDDENRegistrationItemID")).Value;
                        SPListItem registration =  SPContext.Current.Web.Lists.TryGetList(Constants.RegistrationList).GetItemById(Convert.ToInt32(registrationID));
                        Utilities.SendMail(Convert.ToString(registration[Constants.Registration_Firstname]),
                            Convert.ToString(registration[Constants.Registration_Email_Monsanto]), 
                            Convert.ToString(registration[Constants.Registration_Email_Personal]),
                            Convert.ToBoolean(registration[Constants.Registration_Email_Personal_Check]), 
                            Convert.ToString(registration[Constants.Registration_Barcode]), 
                            Utilities.GetPresenceSelection(Convert.ToString(registration[Constants.Registration_Presence])),
                            Convert.ToInt32(registration[Constants.Registration_NumberPersons]));
                    }
                }
                if (isOK)
                {
                    pnlResend.Visible = false;
                    pnlResendConfirmation.Visible = true;
                    pnlError.Visible = false;
                }
            }
            catch (Exception ex) 
            {
                pnlResend.Visible = false;
                pnlResendConfirmation.Visible = false;
                pnlError.Visible = true;
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            finally
            {
                gridRegistrationItems.AllowPaging = true;
                gridRegistrationItems.DataBind();
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethod, true);
                if (!isOK)
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethodNoSelection, true);
            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url, false);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            pnlResend.Visible = true;
            pnlResendConfirmation.Visible = false;
            pnlError.Visible = false;
        }
    }

    public class RegistrationsToSharePoint
    {
        public DataTable Select()
        {
            SPQuery query = new SPQuery();
            query.Query = Constants.Config["CAMLResend"];
            SPListItemCollection items = SPContext.Current.Web.Lists[Constants.RegistrationList].GetItems(query);
            //SPListItemCollection items = SPContext.Current.Web.Lists[Constants.RegistrationList].Items;
            return items.GetDataTable();
        }

        public DataTable Select(string SortExpression)
        {
            SPQuery query = new SPQuery();
            query.Query = Constants.Config["CAMLResend"];
            SPListItemCollection items = SPContext.Current.Web.Lists[Constants.RegistrationList].GetItems(query);
            //SPListItemCollection items = SPContext.Current.Web.Lists[Constants.RegistrationList].Items;
            DataTable dataSource = items.GetDataTable();
            if (SortExpression.ToLowerInvariant().EndsWith("desc desc"))
                SortExpression = SortExpression.Substring(0, SortExpression.Length - 5);
            if (!string.IsNullOrEmpty(SortExpression))
            {
                DataView view = new DataView(dataSource);
                view.Sort = SortExpression;
                DataTable newTable = view.ToTable();
                dataSource.Clear();
                dataSource = newTable;
            }
            return dataSource;
        }
    }
}