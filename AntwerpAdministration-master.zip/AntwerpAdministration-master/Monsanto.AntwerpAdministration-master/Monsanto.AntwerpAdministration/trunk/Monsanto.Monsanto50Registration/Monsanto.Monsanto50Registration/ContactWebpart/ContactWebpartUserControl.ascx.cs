﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;
using System.Drawing;
using System.IO;
using Microsoft.SharePoint;
using System.Reflection;

namespace Monsanto.Monsanto50.ContactWebpart
{
    public partial class ContactWebpartUserControl : UserControl
    {
        public ContactWebpart Webpart;

        protected override void OnInit(EventArgs e)
        {
            if (IsPostBack)
            {
                SPUtility.ValidateFormDigest();
                base.OnInit(e);
            }
        }

        protected void Page_Load(object sender, EventArgs e) 
        {
            if (!IsPostBack)
                Constants._Config = null;
            btnSend.OnClientClick = "javascript:RequestContactSubmit();";
            txtName.Text = SPContext.Current.Web.CurrentUser.Name;
            txtName.Enabled = false;
            if(!string.IsNullOrEmpty(SPContext.Current.Web.CurrentUser.Email))
                txtEmail.Text = SPContext.Current.Web.CurrentUser.Email;
            txtEmail.Enabled = false;
            gold_circle_img_form.Src = Constants.Config["IMG_GoldCircle"];
            gold_circle_img_confirm.Src = Constants.Config["IMG_GoldCircle"];
            gold_circle_img_error.Src = Constants.Config["IMG_GoldCircle"];
        }

        protected void radioCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (radioCompany.SelectedValue.Equals(Constants.CompanyTrigger))
            {
                rowDepartment.Visible = true;
                if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                    rowOtherDepartment.Visible = true;
            }
            else
            {
                rowDepartment.Visible = false;
                rowOtherDepartment.Visible = false;
                dropDepartment.SelectedIndex = -1;
            }
        }

        protected void dropDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                rowOtherDepartment.Visible = true;
            else
            {
                rowOtherDepartment.Visible = false;
                txtDepartment.Text = string.Empty;
            }
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            ResetFormFieldLabels();
            bool isOK = CheckFormFields();
            try
            {
                if (isOK)
                {
                    SendMail();
                    pnlContactForm.Visible = false;
                    pnlContactConfirmation.Visible = true;
                    pnlError.Visible = false;
                }
            }
            catch (Exception ex) 
            {
                pnlContactForm.Visible = false;
                pnlContactConfirmation.Visible = false;
                pnlError.Visible = true;
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            finally
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethod, true);
                if(!isOK)
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), Guid.NewGuid().ToString(), Constants.EndRequestMethodValidation, true);
            }
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            Response.Redirect(SPContext.Current.Web.Url, false);
        }
        
        private void SendMail()
        {
            Stream filestream_monsanto50 = null;
            Stream filestream_monsanto = null;
            try
            {
                string body = string.Empty;
                MailMessage mailMessage = new MailMessage();
                mailMessage.From = new MailAddress(txtEmail.Text);
                mailMessage.To.Add(new MailAddress(Constants.Config["Monsanto50mailbox"]));
                //mailMessage.To.Add(new MailAddress(SPContext.Current.Web.CurrentUser.Email));
                mailMessage.Subject = Constants.Config["Email_Subject_Contact"];
                mailMessage.IsBodyHtml = true;
                body = Utilities.GetMailTemplate(MailTemplate.Contact);
                body = body.Replace("{1}", txtName.Text);
                body = body.Replace("{2}", txtEmail.Text);
                body = body.Replace("{3}", radioCompany.SelectedValue);
                if (radioCompany.SelectedIndex == 1)
                    body = body.Replace("{4}", string.Empty);
                else
                    body = body.Replace("{4}", dropDepartment.SelectedValue);
                body = body.Replace("{5}", txtDescription.Text);
                AlternateView objHTLMAltView = AlternateView.CreateAlternateViewFromString(body, new System.Net.Mime.ContentType("text/html"));
                SPFile file_monsanto50 = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Img_Monsanto50"]));
                SPFile file_monsanto = SPContext.Current.Web.GetFile(string.Concat(SPContext.Current.Web.Url, Constants.Config["MailTemplate_Path_Img_Monsanto"]));
                filestream_monsanto50 = file_monsanto50.OpenBinaryStream();
                filestream_monsanto = file_monsanto.OpenBinaryStream();
                if (filestream_monsanto50 != null)
                {
                    LinkedResource objLinkedRes_Monsanto50Logo = new LinkedResource(filestream_monsanto50, Constants.LinkedResourceType_JPEG);
                    objLinkedRes_Monsanto50Logo.ContentId = "monsanto50-logo";
                    objHTLMAltView.LinkedResources.Add(objLinkedRes_Monsanto50Logo);
                }
                if (filestream_monsanto != null)
                {
                    LinkedResource objLinkedRes_MonsantoLogo = new LinkedResource(filestream_monsanto, Constants.LinkedResourceType_PNG);
                    objLinkedRes_MonsantoLogo.ContentId = "monsanto-logo";
                    objHTLMAltView.LinkedResources.Add(objLinkedRes_MonsantoLogo);
                }
                mailMessage.AlternateViews.Add(objHTLMAltView);
                SmtpClient smtpClient = new SmtpClient(Constants.Config["OutboundSMTPServer"]);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex) 
            {
                pnlContactForm.Visible = false;
                pnlContactConfirmation.Visible = false;
                pnlError.Visible = true;
                Microsoft.Office.Server.Diagnostics.PortalLog.DebugLogString(Microsoft.Office.Server.Diagnostics.PortalLogLevel.Unexpected, "MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
                Microsoft.Office.Server.Diagnostics.PortalLog.LogString("MONSANTO 50 ---- {0}:{1} ---- {2}", MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().ToString(), ex.Message);
            }
            finally
            {
                if (filestream_monsanto50 != null)
                    filestream_monsanto50.Close();
                if (filestream_monsanto != null)
                    filestream_monsanto.Close();
            }
        }

        private void ResetFormFieldLabels()
        {
            lblNaam.ForeColor = Color.Empty;
            lblName.ForeColor = Color.Empty;
            lblEmail.ForeColor = Color.Empty;
            lblBedrijf.ForeColor = Color.Empty;
            lblCompany.ForeColor = Color.Empty;
            lblAfdeling.ForeColor = Color.Empty;
            lblDepartment.ForeColor = Color.Empty;
            lblAndereAfdeling.ForeColor = Color.Empty;
            lblOtherDepartment.ForeColor = Color.Empty;
            lblOmschrijving.ForeColor = Color.Empty;
            lblDescription.ForeColor = Color.Empty;
        }

        private bool CheckFormFields()
        {
            bool isOK = true;
            if (string.IsNullOrEmpty(txtName.Text))
            {
                isOK = false;
                lblNaam.ForeColor = Color.Red;
                lblName.ForeColor = Color.Red;
            }
            if (string.IsNullOrEmpty(txtEmail.Text))
            {
                isOK = false;
                lblEmail.ForeColor = Color.Red;
            }
            if (radioCompany.SelectedIndex < 0)
            {
                isOK = false;
                lblBedrijf.ForeColor = Color.Red;
                lblCompany.ForeColor = Color.Red;
            }
            if (radioCompany.SelectedIndex == 0)
            {
                if (dropDepartment.SelectedIndex < 1)
                {
                    isOK = false;
                    lblAfdeling.ForeColor = Color.Red;
                    lblDepartment.ForeColor = Color.Red;
                }
                if (dropDepartment.SelectedValue.Equals(Constants.DepartmentTrigger))
                {
                    if (string.IsNullOrEmpty(txtDepartment.Text))
                    {
                        isOK = false;
                        lblAndereAfdeling.ForeColor = Color.Red;
                        lblOtherDepartment.ForeColor = Color.Red;
                    }
                }
            }
            if (string.IsNullOrEmpty(txtDescription.Text))
            {
                isOK = false;
                lblOmschrijving.ForeColor = Color.Red;
                lblDescription.ForeColor = Color.Red;
            }
            return isOK;
        }
    }
}